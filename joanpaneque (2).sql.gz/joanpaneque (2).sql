-- Adminer 5.4.1 PostgreSQL 14.19 dump

DROP FUNCTION IF EXISTS "array_to_halfvec";;
CREATE FUNCTION "array_to_halfvec" (IN "1" ARRAY, IN "2" integer, IN "3" boolean) RETURNS halfvec LANGUAGE c AS 'array_to_halfvec';

DROP FUNCTION IF EXISTS "array_to_halfvec";;
CREATE FUNCTION "array_to_halfvec" (IN "1" ARRAY, IN "2" integer, IN "3" boolean) RETURNS halfvec LANGUAGE c AS 'array_to_halfvec';

DROP FUNCTION IF EXISTS "array_to_halfvec";;
CREATE FUNCTION "array_to_halfvec" (IN "1" ARRAY, IN "2" integer, IN "3" boolean) RETURNS halfvec LANGUAGE c AS 'array_to_halfvec';

DROP FUNCTION IF EXISTS "array_to_halfvec";;
CREATE FUNCTION "array_to_halfvec" (IN "1" ARRAY, IN "2" integer, IN "3" boolean) RETURNS halfvec LANGUAGE c AS 'array_to_halfvec';

DROP FUNCTION IF EXISTS "array_to_sparsevec";;
CREATE FUNCTION "array_to_sparsevec" (IN "1" ARRAY, IN "2" integer, IN "3" boolean) RETURNS sparsevec LANGUAGE c AS 'array_to_sparsevec';

DROP FUNCTION IF EXISTS "array_to_sparsevec";;
CREATE FUNCTION "array_to_sparsevec" (IN "1" ARRAY, IN "2" integer, IN "3" boolean) RETURNS sparsevec LANGUAGE c AS 'array_to_sparsevec';

DROP FUNCTION IF EXISTS "array_to_sparsevec";;
CREATE FUNCTION "array_to_sparsevec" (IN "1" ARRAY, IN "2" integer, IN "3" boolean) RETURNS sparsevec LANGUAGE c AS 'array_to_sparsevec';

DROP FUNCTION IF EXISTS "array_to_sparsevec";;
CREATE FUNCTION "array_to_sparsevec" (IN "1" ARRAY, IN "2" integer, IN "3" boolean) RETURNS sparsevec LANGUAGE c AS 'array_to_sparsevec';

DROP FUNCTION IF EXISTS "array_to_vector";;
CREATE FUNCTION "array_to_vector" (IN "1" ARRAY, IN "2" integer, IN "3" boolean) RETURNS vector LANGUAGE c AS 'array_to_vector';

DROP FUNCTION IF EXISTS "array_to_vector";;
CREATE FUNCTION "array_to_vector" (IN "1" ARRAY, IN "2" integer, IN "3" boolean) RETURNS vector LANGUAGE c AS 'array_to_vector';

DROP FUNCTION IF EXISTS "array_to_vector";;
CREATE FUNCTION "array_to_vector" (IN "1" ARRAY, IN "2" integer, IN "3" boolean) RETURNS vector LANGUAGE c AS 'array_to_vector';

DROP FUNCTION IF EXISTS "array_to_vector";;
CREATE FUNCTION "array_to_vector" (IN "1" ARRAY, IN "2" integer, IN "3" boolean) RETURNS vector LANGUAGE c AS 'array_to_vector';

DROP  IF EXISTS "avg";;
CREATE  "avg" (IN "1" USER-DEFINED) LANGUAGE internal AS 'aggregate_dummy';

DROP  IF EXISTS "avg";;
CREATE  "avg" (IN "1" USER-DEFINED) LANGUAGE internal AS 'aggregate_dummy';

DROP FUNCTION IF EXISTS "binary_quantize";;
CREATE FUNCTION "binary_quantize" (IN "1" USER-DEFINED) RETURNS bit LANGUAGE c AS 'binary_quantize';

DROP FUNCTION IF EXISTS "binary_quantize";;
CREATE FUNCTION "binary_quantize" (IN "1" USER-DEFINED) RETURNS bit LANGUAGE c AS 'halfvec_binary_quantize';

DROP FUNCTION IF EXISTS "cosine_distance";;
CREATE FUNCTION "cosine_distance" (IN "1" USER-DEFINED, IN "2" USER-DEFINED) RETURNS float8 LANGUAGE c AS 'cosine_distance';

DROP FUNCTION IF EXISTS "cosine_distance";;
CREATE FUNCTION "cosine_distance" (IN "1" USER-DEFINED, IN "2" USER-DEFINED) RETURNS float8 LANGUAGE c AS 'halfvec_cosine_distance';

DROP FUNCTION IF EXISTS "cosine_distance";;
CREATE FUNCTION "cosine_distance" (IN "1" USER-DEFINED, IN "2" USER-DEFINED) RETURNS float8 LANGUAGE c AS 'sparsevec_cosine_distance';

DROP FUNCTION IF EXISTS "halfvec";;
CREATE FUNCTION "halfvec" (IN "1" USER-DEFINED, IN "2" integer, IN "3" boolean) RETURNS halfvec LANGUAGE c AS 'halfvec';

DROP FUNCTION IF EXISTS "halfvec_accum";;
CREATE FUNCTION "halfvec_accum" (IN "1" ARRAY, IN "2" USER-DEFINED) RETURNS _float8 LANGUAGE c AS 'halfvec_accum';

DROP FUNCTION IF EXISTS "halfvec_add";;
CREATE FUNCTION "halfvec_add" (IN "1" USER-DEFINED, IN "2" USER-DEFINED) RETURNS halfvec LANGUAGE c AS 'halfvec_add';

DROP FUNCTION IF EXISTS "halfvec_avg";;
CREATE FUNCTION "halfvec_avg" (IN "1" ARRAY) RETURNS halfvec LANGUAGE c AS 'halfvec_avg';

DROP FUNCTION IF EXISTS "halfvec_cmp";;
CREATE FUNCTION "halfvec_cmp" (IN "1" USER-DEFINED, IN "2" USER-DEFINED) RETURNS int4 LANGUAGE c AS 'halfvec_cmp';

DROP FUNCTION IF EXISTS "halfvec_combine";;
CREATE FUNCTION "halfvec_combine" (IN "1" ARRAY, IN "2" ARRAY) RETURNS _float8 LANGUAGE c AS 'vector_combine';

DROP FUNCTION IF EXISTS "halfvec_concat";;
CREATE FUNCTION "halfvec_concat" (IN "1" USER-DEFINED, IN "2" USER-DEFINED) RETURNS halfvec LANGUAGE c AS 'halfvec_concat';

DROP FUNCTION IF EXISTS "halfvec_eq";;
CREATE FUNCTION "halfvec_eq" (IN "1" USER-DEFINED, IN "2" USER-DEFINED) RETURNS bool LANGUAGE c AS 'halfvec_eq';

DROP FUNCTION IF EXISTS "halfvec_ge";;
CREATE FUNCTION "halfvec_ge" (IN "1" USER-DEFINED, IN "2" USER-DEFINED) RETURNS bool LANGUAGE c AS 'halfvec_ge';

DROP FUNCTION IF EXISTS "halfvec_gt";;
CREATE FUNCTION "halfvec_gt" (IN "1" USER-DEFINED, IN "2" USER-DEFINED) RETURNS bool LANGUAGE c AS 'halfvec_gt';

DROP FUNCTION IF EXISTS "halfvec_in";;
CREATE FUNCTION "halfvec_in" (IN "1" cstring, IN "2" oid, IN "3" integer) RETURNS halfvec LANGUAGE c AS 'halfvec_in';

DROP FUNCTION IF EXISTS "halfvec_l2_squared_distance";;
CREATE FUNCTION "halfvec_l2_squared_distance" (IN "1" USER-DEFINED, IN "2" USER-DEFINED) RETURNS float8 LANGUAGE c AS 'halfvec_l2_squared_distance';

DROP FUNCTION IF EXISTS "halfvec_le";;
CREATE FUNCTION "halfvec_le" (IN "1" USER-DEFINED, IN "2" USER-DEFINED) RETURNS bool LANGUAGE c AS 'halfvec_le';

DROP FUNCTION IF EXISTS "halfvec_lt";;
CREATE FUNCTION "halfvec_lt" (IN "1" USER-DEFINED, IN "2" USER-DEFINED) RETURNS bool LANGUAGE c AS 'halfvec_lt';

DROP FUNCTION IF EXISTS "halfvec_mul";;
CREATE FUNCTION "halfvec_mul" (IN "1" USER-DEFINED, IN "2" USER-DEFINED) RETURNS halfvec LANGUAGE c AS 'halfvec_mul';

DROP FUNCTION IF EXISTS "halfvec_ne";;
CREATE FUNCTION "halfvec_ne" (IN "1" USER-DEFINED, IN "2" USER-DEFINED) RETURNS bool LANGUAGE c AS 'halfvec_ne';

DROP FUNCTION IF EXISTS "halfvec_negative_inner_product";;
CREATE FUNCTION "halfvec_negative_inner_product" (IN "1" USER-DEFINED, IN "2" USER-DEFINED) RETURNS float8 LANGUAGE c AS 'halfvec_negative_inner_product';

DROP FUNCTION IF EXISTS "halfvec_out";;
CREATE FUNCTION "halfvec_out" (IN "1" USER-DEFINED) RETURNS cstring LANGUAGE c AS 'halfvec_out';

DROP FUNCTION IF EXISTS "halfvec_recv";;
CREATE FUNCTION "halfvec_recv" (IN "1" internal, IN "2" oid, IN "3" integer) RETURNS halfvec LANGUAGE c AS 'halfvec_recv';

DROP FUNCTION IF EXISTS "halfvec_send";;
CREATE FUNCTION "halfvec_send" (IN "1" USER-DEFINED) RETURNS bytea LANGUAGE c AS 'halfvec_send';

DROP FUNCTION IF EXISTS "halfvec_spherical_distance";;
CREATE FUNCTION "halfvec_spherical_distance" (IN "1" USER-DEFINED, IN "2" USER-DEFINED) RETURNS float8 LANGUAGE c AS 'halfvec_spherical_distance';

DROP FUNCTION IF EXISTS "halfvec_sub";;
CREATE FUNCTION "halfvec_sub" (IN "1" USER-DEFINED, IN "2" USER-DEFINED) RETURNS halfvec LANGUAGE c AS 'halfvec_sub';

DROP FUNCTION IF EXISTS "halfvec_to_float4";;
CREATE FUNCTION "halfvec_to_float4" (IN "1" USER-DEFINED, IN "2" integer, IN "3" boolean) RETURNS _float4 LANGUAGE c AS 'halfvec_to_float4';

DROP FUNCTION IF EXISTS "halfvec_to_sparsevec";;
CREATE FUNCTION "halfvec_to_sparsevec" (IN "1" USER-DEFINED, IN "2" integer, IN "3" boolean) RETURNS sparsevec LANGUAGE c AS 'halfvec_to_sparsevec';

DROP FUNCTION IF EXISTS "halfvec_to_vector";;
CREATE FUNCTION "halfvec_to_vector" (IN "1" USER-DEFINED, IN "2" integer, IN "3" boolean) RETURNS vector LANGUAGE c AS 'halfvec_to_vector';

DROP FUNCTION IF EXISTS "halfvec_typmod_in";;
CREATE FUNCTION "halfvec_typmod_in" (IN "1" ARRAY) RETURNS int4 LANGUAGE c AS 'halfvec_typmod_in';

DROP FUNCTION IF EXISTS "hamming_distance";;
CREATE FUNCTION "hamming_distance" (IN "1" bit, IN "2" bit) RETURNS float8 LANGUAGE c AS 'hamming_distance';

DROP FUNCTION IF EXISTS "hnsw_bit_support";;
CREATE FUNCTION "hnsw_bit_support" (IN "1" internal) RETURNS internal LANGUAGE c AS 'hnsw_bit_support';

DROP FUNCTION IF EXISTS "hnsw_halfvec_support";;
CREATE FUNCTION "hnsw_halfvec_support" (IN "1" internal) RETURNS internal LANGUAGE c AS 'hnsw_halfvec_support';

DROP FUNCTION IF EXISTS "hnsw_sparsevec_support";;
CREATE FUNCTION "hnsw_sparsevec_support" (IN "1" internal) RETURNS internal LANGUAGE c AS 'hnsw_sparsevec_support';

DROP FUNCTION IF EXISTS "hnswhandler";;
CREATE FUNCTION "hnswhandler" (IN "1" internal) RETURNS index_am_handler LANGUAGE c AS 'hnswhandler';

DROP FUNCTION IF EXISTS "inner_product";;
CREATE FUNCTION "inner_product" (IN "1" USER-DEFINED, IN "2" USER-DEFINED) RETURNS float8 LANGUAGE c AS 'inner_product';

DROP FUNCTION IF EXISTS "inner_product";;
CREATE FUNCTION "inner_product" (IN "1" USER-DEFINED, IN "2" USER-DEFINED) RETURNS float8 LANGUAGE c AS 'halfvec_inner_product';

DROP FUNCTION IF EXISTS "inner_product";;
CREATE FUNCTION "inner_product" (IN "1" USER-DEFINED, IN "2" USER-DEFINED) RETURNS float8 LANGUAGE c AS 'sparsevec_inner_product';

DROP FUNCTION IF EXISTS "ivfflat_bit_support";;
CREATE FUNCTION "ivfflat_bit_support" (IN "1" internal) RETURNS internal LANGUAGE c AS 'ivfflat_bit_support';

DROP FUNCTION IF EXISTS "ivfflat_halfvec_support";;
CREATE FUNCTION "ivfflat_halfvec_support" (IN "1" internal) RETURNS internal LANGUAGE c AS 'ivfflat_halfvec_support';

DROP FUNCTION IF EXISTS "ivfflathandler";;
CREATE FUNCTION "ivfflathandler" (IN "1" internal) RETURNS index_am_handler LANGUAGE c AS 'ivfflathandler';

DROP FUNCTION IF EXISTS "jaccard_distance";;
CREATE FUNCTION "jaccard_distance" (IN "1" bit, IN "2" bit) RETURNS float8 LANGUAGE c AS 'jaccard_distance';

DROP FUNCTION IF EXISTS "l1_distance";;
CREATE FUNCTION "l1_distance" (IN "1" USER-DEFINED, IN "2" USER-DEFINED) RETURNS float8 LANGUAGE c AS 'l1_distance';

DROP FUNCTION IF EXISTS "l1_distance";;
CREATE FUNCTION "l1_distance" (IN "1" USER-DEFINED, IN "2" USER-DEFINED) RETURNS float8 LANGUAGE c AS 'halfvec_l1_distance';

DROP FUNCTION IF EXISTS "l1_distance";;
CREATE FUNCTION "l1_distance" (IN "1" USER-DEFINED, IN "2" USER-DEFINED) RETURNS float8 LANGUAGE c AS 'sparsevec_l1_distance';

DROP FUNCTION IF EXISTS "l2_distance";;
CREATE FUNCTION "l2_distance" (IN "1" USER-DEFINED, IN "2" USER-DEFINED) RETURNS float8 LANGUAGE c AS 'l2_distance';

DROP FUNCTION IF EXISTS "l2_distance";;
CREATE FUNCTION "l2_distance" (IN "1" USER-DEFINED, IN "2" USER-DEFINED) RETURNS float8 LANGUAGE c AS 'halfvec_l2_distance';

DROP FUNCTION IF EXISTS "l2_distance";;
CREATE FUNCTION "l2_distance" (IN "1" USER-DEFINED, IN "2" USER-DEFINED) RETURNS float8 LANGUAGE c AS 'sparsevec_l2_distance';

DROP FUNCTION IF EXISTS "l2_norm";;
CREATE FUNCTION "l2_norm" (IN "1" USER-DEFINED) RETURNS float8 LANGUAGE c AS 'halfvec_l2_norm';

DROP FUNCTION IF EXISTS "l2_norm";;
CREATE FUNCTION "l2_norm" (IN "1" USER-DEFINED) RETURNS float8 LANGUAGE c AS 'sparsevec_l2_norm';

DROP FUNCTION IF EXISTS "l2_normalize";;
CREATE FUNCTION "l2_normalize" (IN "1" USER-DEFINED) RETURNS vector LANGUAGE c AS 'l2_normalize';

DROP FUNCTION IF EXISTS "l2_normalize";;
CREATE FUNCTION "l2_normalize" (IN "1" USER-DEFINED) RETURNS halfvec LANGUAGE c AS 'halfvec_l2_normalize';

DROP FUNCTION IF EXISTS "l2_normalize";;
CREATE FUNCTION "l2_normalize" (IN "1" USER-DEFINED) RETURNS sparsevec LANGUAGE c AS 'sparsevec_l2_normalize';

DROP FUNCTION IF EXISTS "sparsevec";;
CREATE FUNCTION "sparsevec" (IN "1" USER-DEFINED, IN "2" integer, IN "3" boolean) RETURNS sparsevec LANGUAGE c AS 'sparsevec';

DROP FUNCTION IF EXISTS "sparsevec_cmp";;
CREATE FUNCTION "sparsevec_cmp" (IN "1" USER-DEFINED, IN "2" USER-DEFINED) RETURNS int4 LANGUAGE c AS 'sparsevec_cmp';

DROP FUNCTION IF EXISTS "sparsevec_eq";;
CREATE FUNCTION "sparsevec_eq" (IN "1" USER-DEFINED, IN "2" USER-DEFINED) RETURNS bool LANGUAGE c AS 'sparsevec_eq';

DROP FUNCTION IF EXISTS "sparsevec_ge";;
CREATE FUNCTION "sparsevec_ge" (IN "1" USER-DEFINED, IN "2" USER-DEFINED) RETURNS bool LANGUAGE c AS 'sparsevec_ge';

DROP FUNCTION IF EXISTS "sparsevec_gt";;
CREATE FUNCTION "sparsevec_gt" (IN "1" USER-DEFINED, IN "2" USER-DEFINED) RETURNS bool LANGUAGE c AS 'sparsevec_gt';

DROP FUNCTION IF EXISTS "sparsevec_in";;
CREATE FUNCTION "sparsevec_in" (IN "1" cstring, IN "2" oid, IN "3" integer) RETURNS sparsevec LANGUAGE c AS 'sparsevec_in';

DROP FUNCTION IF EXISTS "sparsevec_l2_squared_distance";;
CREATE FUNCTION "sparsevec_l2_squared_distance" (IN "1" USER-DEFINED, IN "2" USER-DEFINED) RETURNS float8 LANGUAGE c AS 'sparsevec_l2_squared_distance';

DROP FUNCTION IF EXISTS "sparsevec_le";;
CREATE FUNCTION "sparsevec_le" (IN "1" USER-DEFINED, IN "2" USER-DEFINED) RETURNS bool LANGUAGE c AS 'sparsevec_le';

DROP FUNCTION IF EXISTS "sparsevec_lt";;
CREATE FUNCTION "sparsevec_lt" (IN "1" USER-DEFINED, IN "2" USER-DEFINED) RETURNS bool LANGUAGE c AS 'sparsevec_lt';

DROP FUNCTION IF EXISTS "sparsevec_ne";;
CREATE FUNCTION "sparsevec_ne" (IN "1" USER-DEFINED, IN "2" USER-DEFINED) RETURNS bool LANGUAGE c AS 'sparsevec_ne';

DROP FUNCTION IF EXISTS "sparsevec_negative_inner_product";;
CREATE FUNCTION "sparsevec_negative_inner_product" (IN "1" USER-DEFINED, IN "2" USER-DEFINED) RETURNS float8 LANGUAGE c AS 'sparsevec_negative_inner_product';

DROP FUNCTION IF EXISTS "sparsevec_out";;
CREATE FUNCTION "sparsevec_out" (IN "1" USER-DEFINED) RETURNS cstring LANGUAGE c AS 'sparsevec_out';

DROP FUNCTION IF EXISTS "sparsevec_recv";;
CREATE FUNCTION "sparsevec_recv" (IN "1" internal, IN "2" oid, IN "3" integer) RETURNS sparsevec LANGUAGE c AS 'sparsevec_recv';

DROP FUNCTION IF EXISTS "sparsevec_send";;
CREATE FUNCTION "sparsevec_send" (IN "1" USER-DEFINED) RETURNS bytea LANGUAGE c AS 'sparsevec_send';

DROP FUNCTION IF EXISTS "sparsevec_to_halfvec";;
CREATE FUNCTION "sparsevec_to_halfvec" (IN "1" USER-DEFINED, IN "2" integer, IN "3" boolean) RETURNS halfvec LANGUAGE c AS 'sparsevec_to_halfvec';

DROP FUNCTION IF EXISTS "sparsevec_to_vector";;
CREATE FUNCTION "sparsevec_to_vector" (IN "1" USER-DEFINED, IN "2" integer, IN "3" boolean) RETURNS vector LANGUAGE c AS 'sparsevec_to_vector';

DROP FUNCTION IF EXISTS "sparsevec_typmod_in";;
CREATE FUNCTION "sparsevec_typmod_in" (IN "1" ARRAY) RETURNS int4 LANGUAGE c AS 'sparsevec_typmod_in';

DROP FUNCTION IF EXISTS "subvector";;
CREATE FUNCTION "subvector" (IN "1" USER-DEFINED, IN "2" integer, IN "3" integer) RETURNS vector LANGUAGE c AS 'subvector';

DROP FUNCTION IF EXISTS "subvector";;
CREATE FUNCTION "subvector" (IN "1" USER-DEFINED, IN "2" integer, IN "3" integer) RETURNS halfvec LANGUAGE c AS 'halfvec_subvector';

DROP  IF EXISTS "sum";;
CREATE  "sum" (IN "1" USER-DEFINED) LANGUAGE internal AS 'aggregate_dummy';

DROP  IF EXISTS "sum";;
CREATE  "sum" (IN "1" USER-DEFINED) LANGUAGE internal AS 'aggregate_dummy';

DROP FUNCTION IF EXISTS "vector";;
CREATE FUNCTION "vector" (IN "1" USER-DEFINED, IN "2" integer, IN "3" boolean) RETURNS vector LANGUAGE c AS 'vector';

DROP FUNCTION IF EXISTS "vector_accum";;
CREATE FUNCTION "vector_accum" (IN "1" ARRAY, IN "2" USER-DEFINED) RETURNS _float8 LANGUAGE c AS 'vector_accum';

DROP FUNCTION IF EXISTS "vector_add";;
CREATE FUNCTION "vector_add" (IN "1" USER-DEFINED, IN "2" USER-DEFINED) RETURNS vector LANGUAGE c AS 'vector_add';

DROP FUNCTION IF EXISTS "vector_avg";;
CREATE FUNCTION "vector_avg" (IN "1" ARRAY) RETURNS vector LANGUAGE c AS 'vector_avg';

DROP FUNCTION IF EXISTS "vector_cmp";;
CREATE FUNCTION "vector_cmp" (IN "1" USER-DEFINED, IN "2" USER-DEFINED) RETURNS int4 LANGUAGE c AS 'vector_cmp';

DROP FUNCTION IF EXISTS "vector_combine";;
CREATE FUNCTION "vector_combine" (IN "1" ARRAY, IN "2" ARRAY) RETURNS _float8 LANGUAGE c AS 'vector_combine';

DROP FUNCTION IF EXISTS "vector_concat";;
CREATE FUNCTION "vector_concat" (IN "1" USER-DEFINED, IN "2" USER-DEFINED) RETURNS vector LANGUAGE c AS 'vector_concat';

DROP FUNCTION IF EXISTS "vector_dims";;
CREATE FUNCTION "vector_dims" (IN "1" USER-DEFINED) RETURNS int4 LANGUAGE c AS 'vector_dims';

DROP FUNCTION IF EXISTS "vector_dims";;
CREATE FUNCTION "vector_dims" (IN "1" USER-DEFINED) RETURNS int4 LANGUAGE c AS 'halfvec_vector_dims';

DROP FUNCTION IF EXISTS "vector_eq";;
CREATE FUNCTION "vector_eq" (IN "1" USER-DEFINED, IN "2" USER-DEFINED) RETURNS bool LANGUAGE c AS 'vector_eq';

DROP FUNCTION IF EXISTS "vector_ge";;
CREATE FUNCTION "vector_ge" (IN "1" USER-DEFINED, IN "2" USER-DEFINED) RETURNS bool LANGUAGE c AS 'vector_ge';

DROP FUNCTION IF EXISTS "vector_gt";;
CREATE FUNCTION "vector_gt" (IN "1" USER-DEFINED, IN "2" USER-DEFINED) RETURNS bool LANGUAGE c AS 'vector_gt';

DROP FUNCTION IF EXISTS "vector_in";;
CREATE FUNCTION "vector_in" (IN "1" cstring, IN "2" oid, IN "3" integer) RETURNS vector LANGUAGE c AS 'vector_in';

DROP FUNCTION IF EXISTS "vector_l2_squared_distance";;
CREATE FUNCTION "vector_l2_squared_distance" (IN "1" USER-DEFINED, IN "2" USER-DEFINED) RETURNS float8 LANGUAGE c AS 'vector_l2_squared_distance';

DROP FUNCTION IF EXISTS "vector_le";;
CREATE FUNCTION "vector_le" (IN "1" USER-DEFINED, IN "2" USER-DEFINED) RETURNS bool LANGUAGE c AS 'vector_le';

DROP FUNCTION IF EXISTS "vector_lt";;
CREATE FUNCTION "vector_lt" (IN "1" USER-DEFINED, IN "2" USER-DEFINED) RETURNS bool LANGUAGE c AS 'vector_lt';

DROP FUNCTION IF EXISTS "vector_mul";;
CREATE FUNCTION "vector_mul" (IN "1" USER-DEFINED, IN "2" USER-DEFINED) RETURNS vector LANGUAGE c AS 'vector_mul';

DROP FUNCTION IF EXISTS "vector_ne";;
CREATE FUNCTION "vector_ne" (IN "1" USER-DEFINED, IN "2" USER-DEFINED) RETURNS bool LANGUAGE c AS 'vector_ne';

DROP FUNCTION IF EXISTS "vector_negative_inner_product";;
CREATE FUNCTION "vector_negative_inner_product" (IN "1" USER-DEFINED, IN "2" USER-DEFINED) RETURNS float8 LANGUAGE c AS 'vector_negative_inner_product';

DROP FUNCTION IF EXISTS "vector_norm";;
CREATE FUNCTION "vector_norm" (IN "1" USER-DEFINED) RETURNS float8 LANGUAGE c AS 'vector_norm';

DROP FUNCTION IF EXISTS "vector_out";;
CREATE FUNCTION "vector_out" (IN "1" USER-DEFINED) RETURNS cstring LANGUAGE c AS 'vector_out';

DROP FUNCTION IF EXISTS "vector_recv";;
CREATE FUNCTION "vector_recv" (IN "1" internal, IN "2" oid, IN "3" integer) RETURNS vector LANGUAGE c AS 'vector_recv';

DROP FUNCTION IF EXISTS "vector_send";;
CREATE FUNCTION "vector_send" (IN "1" USER-DEFINED) RETURNS bytea LANGUAGE c AS 'vector_send';

DROP FUNCTION IF EXISTS "vector_spherical_distance";;
CREATE FUNCTION "vector_spherical_distance" (IN "1" USER-DEFINED, IN "2" USER-DEFINED) RETURNS float8 LANGUAGE c AS 'vector_spherical_distance';

DROP FUNCTION IF EXISTS "vector_sub";;
CREATE FUNCTION "vector_sub" (IN "1" USER-DEFINED, IN "2" USER-DEFINED) RETURNS vector LANGUAGE c AS 'vector_sub';

DROP FUNCTION IF EXISTS "vector_to_float4";;
CREATE FUNCTION "vector_to_float4" (IN "1" USER-DEFINED, IN "2" integer, IN "3" boolean) RETURNS _float4 LANGUAGE c AS 'vector_to_float4';

DROP FUNCTION IF EXISTS "vector_to_halfvec";;
CREATE FUNCTION "vector_to_halfvec" (IN "1" USER-DEFINED, IN "2" integer, IN "3" boolean) RETURNS halfvec LANGUAGE c AS 'vector_to_halfvec';

DROP FUNCTION IF EXISTS "vector_to_sparsevec";;
CREATE FUNCTION "vector_to_sparsevec" (IN "1" USER-DEFINED, IN "2" integer, IN "3" boolean) RETURNS sparsevec LANGUAGE c AS 'vector_to_sparsevec';

DROP FUNCTION IF EXISTS "vector_typmod_in";;
CREATE FUNCTION "vector_typmod_in" (IN "1" ARRAY) RETURNS int4 LANGUAGE c AS 'vector_typmod_in';

DROP TABLE IF EXISTS "bookings";
DROP SEQUENCE IF EXISTS bookings_id_seq;
CREATE SEQUENCE bookings_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."bookings" (
    "id" bigint DEFAULT nextval('bookings_id_seq') NOT NULL,
    "start" timestamp(0) NOT NULL,
    "end" timestamp(0) NOT NULL,
    "email" character varying(255),
    "event_id" character varying(255) NOT NULL,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "bookings_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);


DROP TABLE IF EXISTS "cache";
CREATE TABLE "public"."cache" (
    "key" character varying(255) NOT NULL,
    "value" text NOT NULL,
    "expiration" integer NOT NULL,
    CONSTRAINT "cache_pkey" PRIMARY KEY ("key")
)
WITH (oids = false);

INSERT INTO "cache" ("key", "value", "expiration") VALUES
('joan-paneque-joanpanequecom-cache-instagram:auto_reply:mid:aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDEzMzEzMjE5MjY3MTA4MDozMjc3MDg0MjU4Mjk3NzY0Mjg2MzI3NTk3MTEwMDgwMzA3MgZDZD',	'i:1;',	1776597337),
('joan-paneque-joanpanequecom-cache-instagram:auto_reply:mid:aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDEyNjI1OTgyNjY5MzM1MDozMjc3MDg0NDA1NjI5NjkwMDU5NzMzNzE4NjA4MDEyOTAyNAZDZD',	'i:1;',	1776597417),
('joan-paneque-joanpanequecom-cache-instagram:auto_reply:mid:aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MDg0NTE5NTQwODkzMjc4MjkzMjIzMzUxNjIyMDQxNgZDZD',	'i:1;',	1776597478),
('joan-paneque-joanpanequecom-cache-instagram:ia_comment:18108993751671582',	'i:1;',	1776598376),
('joan-paneque-joanpanequecom-cache-instagram:ia_comment:18087939653263261',	'i:1;',	1776598434),
('joan-paneque-joanpanequecom-cache-instagram:auto_reply:mid:aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MDkwNTQwNzgxNDAxNDMzODcwOTAzODA3Njc4ODczNgZDZD',	'i:1;',	1776600742),
('joan-paneque-joanpanequecom-cache-instagram:auto_reply:mid:aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MDkwNTU0Mjc4NTY4NjMzMjgwNTIyMjkxNzczNDQwMAZDZD',	'i:1;',	1776600749),
('joan-paneque-joanpanequecom-cache-instagram:ia_comment:18349295530214733',	'i:1;',	1776600830),
('joan-paneque-joanpanequecom-cache-instagram:auto_reply:mid:aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MDkwNzQ1NDE2MTM4MDQ1MTk4MTU3Mjg1MzIwMjk0NAZDZD',	'i:1;',	1776600853),
('joan-paneque-joanpanequecom-cache-instagram:auto_reply:mid:aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MDkwODg4Njk5NzUwNTg3NTYwMDE3NDQwMzgxMzM3NgZDZD',	'i:1;',	1776600931),
('joan-paneque-joanpanequecom-cache-instagram:auto_reply:mid:aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MDkwODkwNDIwNTgyNzc4NTkyMTIzNTI3MjA3MzIxNgZDZD',	'i:1;',	1776600933),
('joan-paneque-joanpanequecom-cache-instagram:auto_reply:mid:aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MDkwODk1MTY2OTAyMzU4NjQxNDgwNTkzNjc2Njk3NgZDZD',	'i:1;',	1776600935),
('joan-paneque-joanpanequecom-cache-instagram:auto_reply:mid:aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MDkwODk3NzQzNzE1MTI1NTc3MTE2MjYyMjI5NjA2NAZDZD',	'i:1;',	1776600936),
('joan-paneque-joanpanequecom-cache-instagram:auto_reply:mid:aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MDkwOTI0OTI1OTExMTY2MDQzMDExMzA0MDc2MDgzMgZDZD',	'i:1;',	1776600950),
('joan-paneque-joanpanequecom-cache-instagram:auto_reply:mid:aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MDkwOTMxMjgyMzYwMzM2NTg5MzI4Njk2MjEzNTA0MAZDZD',	'i:1;',	1776600954),
('joan-paneque-joanpanequecom-cache-instagram:auto_reply:mid:aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MDkwOTU2NTE2MDMwNDg5ODk4MDk4NTQyNzcyMjI0MAZDZD',	'i:1;',	1776600968),
('joan-paneque-joanpanequecom-cache-instagram:auto_reply:mid:aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MDkxMDAwOTgzNTQ4ODM5Nzk3NTMyODYzMjM0MDQ4MAZDZD',	'i:1;',	1776600992),
('joan-paneque-joanpanequecom-cache-instagram:ia_comment:17862594795678855',	'i:1;',	1776602615),
('joan-paneque-joanpanequecom-cache-instagram:auto_reply:mid:aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDExMTE5OTY3MTUyNjQwODozMjc3MDk0MDEwNjExMTI4Mjc4NzQ3ODQwOTkwMTUwNjU2MAZDZD',	'i:1;',	1776602624),
('joan-paneque-joanpanequecom-cache-instagram:ia_comment:17936335422243643',	'i:1;',	1776617376),
('joan-paneque-joanpanequecom-cache-instagram:ia_comment:17944668498179027',	'i:1;',	1776618977),
('joan-paneque-joanpanequecom-cache-instagram:ia_comment:18121697836719810',	'i:1;',	1776635142),
('joan-paneque-joanpanequecom-cache-instagram:ia_comment:18095801945169399',	'i:1;',	1776644187),
('joan-paneque-joanpanequecom-cache-instagram:ia_comment:18050945255737360',	'i:1;',	1776658044),
('joan-paneque-joanpanequecom-cache-instagram:ia_comment:18126618514603418',	'i:1;',	1776693807),
('joan-paneque-joanpanequecom-cache-instagram:ia_comment:18005464577724158',	'i:1;',	1776700260),
('joan-paneque-joanpanequecom-cache-instagram:ia_comment:17934225390249858',	'i:1;',	1776700393),
('joan-paneque-joanpanequecom-cache-instagram:ia_comment:18097135073467052',	'i:1;',	1776706760),
('joan-paneque-joanpanequecom-cache-instagram:ia_comment:18197768269350962',	'i:1;',	1776714573),
('joan-paneque-joanpanequecom-cache-instagram:ia_comment:18054084383717584',	'i:1;',	1776716709),
('joan-paneque-joanpanequecom-cache-instagram:ia_comment:18090789125229567',	'i:1;',	1776717086),
('joan-paneque-joanpanequecom-cache-instagram:ia_comment:18094172186135560',	'i:1;',	1776719575),
('joan-paneque-joanpanequecom-cache-instagram:ia_comment:18022951025652705',	'i:1;',	1776733198),
('joan-paneque-joanpanequecom-cache-instagram:ia_comment:18002459381875067',	'i:1;',	1776747998),
('joan-paneque-joanpanequecom-cache-instagram:ia_comment:18098343755085878',	'i:1;',	1776748728),
('joan-paneque-joanpanequecom-cache-instagram:ia_comment:17982531681003945',	'i:1;',	1776756772),
('joan-paneque-joanpanequecom-cache-instagram:ia_comment:17900640678421163',	'i:1;',	1776766130),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18126207292526225',	'i:1;',	1776773485),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18094760447163330',	'i:1;',	1776774930),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18114684694749030',	'i:1;',	1776775611),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18036464948789812',	'i:1;',	1776776529),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18415210297176992',	'i:1;',	1776777135),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17912674395366497',	'i:1;',	1776777140),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18010047722752385',	'i:1;',	1776777206),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18082880234576065',	'i:1;',	1776777211),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18009526862890760',	'i:1;',	1776777226),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18146837035489908',	'i:1;',	1776777594),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18175169683402090',	'i:1;',	1776777600),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18053603900505782',	'i:1;',	1776778808),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18093020636179774',	'i:1;',	1776778812),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18096416510321976',	'i:1;',	1776778960),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18006314942884437',	'i:1;',	1776778965),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17884341582532011',	'i:1;',	1776779051),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18134195926527297',	'i:1;',	1776779057),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18091391708237676',	'i:1;',	1776779081),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18081321563418439',	'i:1;',	1776779086),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17885032551508840',	'i:1;',	1776779194),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18065055128355027',	'i:1;',	1776779199),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18051324437677720',	'i:1;',	1776779232),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17874721959592701',	'i:1;',	1776779235),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18112933336781587',	'i:1;',	1776779250),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18070992614653317',	'i:1;',	1776779255),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18169455361409121',	'i:1;',	1776779390),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17973902172008123',	'i:1;',	1776779395),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18358071979232491',	'i:1;',	1776779725),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18125277973591960',	'i:1;',	1776779729),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18091646029943816',	'i:1;',	1776779862),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17879157090560664',	'i:1;',	1776779866),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18104746496299991',	'i:1;',	1776781519),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18112707547773993',	'i:1;',	1776781524),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17954246633960219',	'i:1;',	1776782151),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17931483078069396',	'i:1;',	1776783105),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18086154365524782',	'i:1;',	1776783110),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18388867780092913',	'i:1;',	1776783764),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18128934964565752',	'i:1;',	1776783770),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18065319794359603',	'i:1;',	1776784823),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17913166950365962',	'i:1;',	1776784828),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17866611666613106',	'i:1;',	1776784951),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18214004491323495',	'i:1;',	1776784956),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18089168363588511',	'i:1;',	1776785308),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18101028475992126',	'i:1;',	1776785312),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17886086694375442',	'i:1;',	1776787082),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18067268795336885',	'i:1;',	1776787087),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17884610811513983',	'i:1;',	1776787320),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18082508417629185',	'i:1;',	1776791912),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18038603327792564',	'i:1;',	1776791917),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18097334506858395',	'i:1;',	1776791924),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18123890704613358',	'i:1;',	1776791929),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18099767357000717',	'i:1;',	1776792234),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18108639199846043',	'i:1;',	1776794628),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18110962993843403',	'i:1;',	1776794633),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17866961094612849',	'i:1;',	1776794658),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18097624583043958',	'i:1;',	1776794664),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18062074184495443',	'i:1;',	1776795120),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18077740103535147',	'i:1;',	1776795977),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18462224581101435',	'i:1;',	1776795981),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18025731404808592',	'i:1;',	1776796685),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17942363184014993',	'i:1;',	1776796690),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17886342768472757',	'i:1;',	1776797837),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18082620155384855',	'i:1;',	1776797842),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18040528346788995',	'i:1;',	1776797845),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18060652610447126',	'i:1;',	1776797850),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18038776661583413',	'i:1;',	1776798181),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17945899752155563',	'i:1;',	1776798186),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18096611843031527',	'i:1;',	1776798286),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18105788971926222',	'i:1;',	1776798559),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18065023205370549',	'i:1;',	1776799924),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18056258333710241',	'i:1;',	1776799928),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17871050286491685',	'i:1;',	1776801958),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18116799025663284',	'i:1;',	1776801964),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18115487188708679',	'i:1;',	1776802791),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18403164538149183',	'i:1;',	1776802795),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18072275051248790',	'i:1;',	1776803104),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17979365465990957',	'i:1;',	1776803109),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18124269295619121',	'i:1;',	1776804545),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18070321610400336',	'i:1;',	1776804550),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17971708823880173',	'i:1;',	1776805678),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18082363130561067',	'i:1;',	1776805683),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18092314219902484',	'i:1;',	1776806107),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18031334120803071',	'i:1;',	1776806181),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18038602703788609',	'i:1;',	1776806186),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18108756109914356',	'i:1;',	1776808276),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18044947928535875',	'i:1;',	1776808705),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18011093543700570',	'i:1;',	1776808709),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17963250492078270',	'i:1;',	1776810307),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18324559468270312',	'i:1;',	1776810312),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18024442355639808',	'i:1;',	1776810425),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17972994681034084',	'i:1;',	1776810429),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17943575256170757',	'i:1;',	1776810722),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18148066864477323',	'i:1;',	1776810727),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18044907542543130',	'i:1;',	1776810941),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18092150789518723',	'i:1;',	1776810945),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18027315599808797',	'i:1;',	1776812627),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17938508007193963',	'i:1;',	1776812631),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17943672492179634',	'i:1;',	1776813010),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18066364448477187',	'i:1;',	1776813490),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18173027365400510',	'i:1;',	1776813495),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17942960388168455',	'i:1;',	1776813582),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18003534080874676',	'i:1;',	1776813587),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18539604751070802',	'i:1;',	1776813843),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18100863538989581',	'i:1;',	1776813848),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18432496276184384',	'i:1;',	1776814798),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17909454270388747',	'i:1;',	1776814802),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17856439572691286',	'i:1;',	1776814954),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18063539792386220',	'i:1;',	1776814958),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18128848597573499',	'i:1;',	1776815615),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18100723214072985',	'i:1;',	1776815621),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18580861585004439',	'i:1;',	1776815895),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18321147904250478',	'i:1;',	1776815900),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17879641860558965',	'i:1;',	1776816895),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18109503181869097',	'i:1;',	1776816900),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18093029207517881',	'i:1;',	1776817158),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18103336376306127',	'i:1;',	1776817163),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18165452458425956',	'i:1;',	1776818143),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18199036831345836',	'i:1;',	1776818148),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17991309437954851',	'i:1;',	1776818268),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18086247935346402',	'i:1;',	1776818273),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18012344369891657',	'i:1;',	1776818442),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18062865404390223',	'i:1;',	1776818447),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18131937256486168',	'i:1;',	1776818747),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18114408247769895',	'i:1;',	1776818752),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18018615056827987',	'i:1;',	1776819168),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18418731799134138',	'i:1;',	1776819173),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18043973660598463',	'i:1;',	1776822167),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18097422992088733',	'i:1;',	1776822258),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18202384354353688',	'i:1;',	1776822264),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18353898898236683',	'i:1;',	1776823857),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18098201144085345',	'i:1;',	1776824774),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18104332828763045',	'i:1;',	1776824779),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18169998919417011',	'i:1;',	1776825959),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17921976552122649',	'i:1;',	1776827954),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18316446985258817',	'i:1;',	1776827959),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18349884202211852',	'i:1;',	1776827981),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18579609328054059',	'i:1;',	1776827986),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17854336539642561',	'i:1;',	1776828907),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18093969190911171',	'i:1;',	1776828914),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18003874880858077',	'i:1;',	1776830517),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18088811747251475',	'i:1;',	1776830523),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17967422274049381',	'i:1;',	1776831704),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17935585599211275',	'i:1;',	1776831711),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18093191513167004',	'i:1;',	1776831715),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18090580357967618',	'i:1;',	1776832513),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18110417872655216',	'i:1;',	1776832518),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18113509522773019',	'i:1;',	1776833155),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17857789710688216',	'i:1;',	1776834227),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17942609814014711',	'i:1;',	1776834231),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18093383108128866',	'i:1;',	1776834380),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18075262511547612',	'i:1;',	1776835434),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18208118797330834',	'i:1;',	1776835438),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18097105535015987',	'i:1;',	1776836434),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18060700487455588',	'i:1;',	1776836439),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18066805646460088',	'i:1;',	1776839383),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18249140923307104',	'i:1;',	1776839389),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17962988156918511',	'i:1;',	1776839761),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18225110335311710',	'i:1;',	1776839765),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18064733324345666',	'i:1;',	1776841294),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17923504287298427',	'i:1;',	1776841298),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18336873619175958',	'i:1;',	1776842068),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18064996451360812',	'i:1;',	1776842072),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17938440642225859',	'i:1;',	1776843537),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18100777021805490',	'i:1;',	1776843542),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18134361457548450',	'i:1;',	1776845912),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18084411299069814',	'i:1;',	1776846158),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18122900965545516',	'i:1;',	1776846162),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18092941037617759',	'i:1;',	1776846881),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18001815113869998',	'i:1;',	1776846885),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17884663566387225',	'i:1;',	1776848063),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18064650524354861',	'i:1;',	1776848068),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18087648977587132',	'i:1;',	1776849052),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18069831908663994',	'i:1;',	1776849056),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18067234232456069',	'i:1;',	1776853312),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18093763469150967',	'i:1;',	1776853317),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17935387374048953',	'i:1;',	1776856037),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18582340627027325',	'i:1;',	1776856041),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18075378281220826',	'i:1;',	1776858036),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18039868604578954',	'i:1;',	1776858041),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18086550716199248',	'i:1;',	1776859617),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18417931171127044',	'i:1;',	1776859621),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17893622844448696',	'i:1;',	1776859931),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18156962482398699',	'i:1;',	1776863516),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17922966261280121',	'i:1;',	1776863521),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18062028251412294',	'i:1;',	1776864504),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17949454091985089',	'i:1;',	1776864510),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17993947967933580',	'i:1;',	1776867384),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17866692771671600',	'i:1;',	1776867389),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18083686931074642',	'i:1;',	1776868546),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17922048519320122',	'i:1;',	1776870918),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17920867161339451',	'i:1;',	1776870923),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18092291635910976',	'i:1;',	1776871029),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17926604274269471',	'i:1;',	1776871062),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17885708325506768',	'i:1;',	1776874483),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18045232868737239',	'i:1;',	1776875804),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18337615183175057',	'i:1;',	1776877309),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18102569854760469',	'i:1;',	1776878857),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18089965091223818',	'i:1;',	1776878862),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18090420890244014',	'i:1;',	1776881588),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18124301278717555',	'i:1;',	1776884496),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18045298751764528',	'i:1;',	1776885922),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18131726986495398',	'i:1;',	1776885928),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17858879130631021',	'i:1;',	1776889292),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18004451057913538',	'i:1;',	1776889931),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18063052070394769',	'i:1;',	1776890300),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18098522090512710',	'i:1;',	1776890306),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18089392988226002',	'i:1;',	1776892361),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18160686322440597',	'i:1;',	1776896799),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17921426355316445',	'i:1;',	1776896804),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17886704292481522',	'i:1;',	1776897998),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18101582944779204',	'i:1;',	1776899489),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17982797144998434',	'i:1;',	1776899494),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17984804885981944',	'i:1;',	1776899916),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18078656534152046',	'i:1;',	1776899921),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18089470949213747',	'i:1;',	1776900794),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17885928300495328',	'i:1;',	1776900799),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18111073909876954',	'i:1;',	1776904582),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18190353373367270',	'i:1;',	1776904588),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18095672300274945',	'i:1;',	1776909498),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17876808954571765',	'i:1;',	1776909701),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18067951730679699',	'i:1;',	1776910465),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18031846352797231',	'i:1;',	1776910470),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18100029778997094',	'i:1;',	1776910523),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17962875003107001',	'i:1;',	1776910527),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18151053850473922',	'i:1;',	1776910678),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17921480067126174',	'i:1;',	1776919008),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17927035062266413',	'i:1;',	1776919014),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18068946110322241',	'i:1;',	1776925243),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18078844043636072',	'i:1;',	1776925492),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18103430983987545',	'i:1;',	1776926767),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18100645855815086',	'i:1;',	1776938726),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18071134340652919',	'i:1;',	1776938730),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18425302003192509',	'i:1;',	1776941633),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17932087533238653',	'i:1;',	1776943850),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18420764737125202',	'i:1;',	1776943857),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17850211470679863',	'i:1;',	1776944594),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17997107018938179',	'i:1;',	1776944599),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18088699891996144',	'i:1;',	1776946567),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17963099226064342',	'i:1;',	1776949582),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18080424227208817',	'i:1;',	1776953065),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18113188561757111',	'i:1;',	1776953070),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18462248302097373',	'i:1;',	1776955671),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18025493195813040',	'i:1;',	1776955675),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18101299849785204',	'i:1;',	1776955692),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18315900544281302',	'i:1;',	1776955697),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18323747641253866',	'i:1;',	1776955736),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18061773524701758',	'i:1;',	1776955742),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17974249422042069',	'i:1;',	1776964428),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18179516431389201',	'i:1;',	1776965972),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17938693116038164',	'i:1;',	1776976397),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17883792099537714',	'i:1;',	1776976402),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18126320410591524',	'i:1;',	1776978065),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18094829753137551',	'i:1;',	1776978072),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18135125416551716',	'i:1;',	1776980464),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17880364800559617',	'i:1;',	1776983564),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18101137444803771',	'i:1;',	1776983569),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17944314810173328',	'i:1;',	1776989887),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17921637657336379',	'i:1;',	1776993215),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18076560869188712',	'i:1;',	1776994276),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18077454578633726',	'i:1;',	1776994282),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17865405375541743',	'i:1;',	1776999572),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17928073254089004',	'i:1;',	1776999577),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17900998101263679',	'i:1;',	1777001731),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18069846584674546',	'i:1;',	1777002138),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18042008348784365',	'i:1;',	1777002158),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18093230822519689',	'i:1;',	1777005790),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18061033448447283',	'i:1;',	1777005796),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18459597691105827',	'i:1;',	1777007030),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18081839969616221',	'i:1;',	1777007035),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17860059180685448',	'i:1;',	1777010253),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18443679064119091',	'i:1;',	1777010257),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17894364255448721',	'i:1;',	1777013657),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18080106194137113',	'i:1;',	1777013662),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18049583459744999',	'i:1;',	1777014377),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18539128723070015',	'i:1;',	1777021736),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18127593541578426',	'i:1;',	1777023794),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17987823836968475',	'i:1;',	1777023800),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18311131120277846',	'i:1;',	1777029188),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18115157212742563',	'i:1;',	1777029193),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18575352838038556',	'i:1;',	1777030598),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18162320878438822',	'i:1;',	1777030603),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18436364050139879',	'i:1;',	1777031757),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18079361171402064',	'i:1;',	1777031761),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17945781234175997',	'i:1;',	1777038883),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18079936082398838',	'i:1;',	1777040172),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17975026826861445',	'i:1;',	1777040177),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18524280355076407',	'i:1;',	1777043874),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18030597710805021',	'i:1;',	1777043898),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18344166115300664',	'i:1;',	1777047398),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18060989699428365',	'i:1;',	1777051298),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18113318479699544',	'i:1;',	1777051303),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17857307559691341',	'i:1;',	1777058518),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18111305821657266',	'i:1;',	1777062366),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18121785292722388',	'i:1;',	1777064335),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18055149824713529',	'i:1;',	1777066010),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18078151979439504',	'i:1;',	1777067022),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18338392921174280',	'i:1;',	1777067975),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18162788389438276',	'i:1;',	1777069543),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18094898549331437',	'i:1;',	1777076141),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18089054981606647',	'i:1;',	1777077045),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17854698612643211',	'i:1;',	1777083051),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18579143350022474',	'i:1;',	1777083457),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18088906889193315',	'i:1;',	1777099526),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18113068123616416',	'i:1;',	1777101388),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18049322015732947',	'i:1;',	1777108927),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18409323748179862',	'i:1;',	1777128788),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18124130968614903',	'i:1;',	1777132049),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17904268950243531',	'i:1;',	1777132211),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18103885867939461',	'i:1;',	1777133600),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17873754753470610',	'i:1;',	1777141174),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17944791114168584',	'i:1;',	1777148274),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17858191791689663',	'i:1;',	1777148276),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18127443604582323',	'i:1;',	1777148293),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17925853893288119',	'i:1;',	1777148294),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17853218052660930',	'i:1;',	1777160508),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18110201533866947',	'i:1;',	1777173997),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18171071473405778',	'i:1;',	1777177514),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17971553960881399',	'i:1;',	1777177789),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18088602350243801',	'i:1;',	1777193340),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18114295372756101',	'i:1;',	1777198908),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18092108816237809',	'i:1;',	1777202438),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18102176648052050',	'i:1;',	1777210520),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17876527041583627',	'i:1;',	1777212952),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18075766946242080',	'i:1;',	1777216576),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17987789738977409',	'i:1;',	1777229629),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17891106537465954',	'i:1;',	1777230229),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18348923188243933',	'i:1;',	1777236804),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18096587285037411',	'i:1;',	1777240536),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18180161236349495',	'i:1;',	1777243779),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18556236160067563',	'i:1;',	1777245905),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18111405739891668',	'i:1;',	1777247730),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18144486427496591',	'i:1;',	1777248701),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17871067881606704',	'i:1;',	1777255139),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18101829454799115',	'i:1;',	1777259988),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18080753651536259',	'i:1;',	1777271016),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18124493566611531',	'i:1;',	1777278397),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18100512317050550',	'i:1;',	1777292105),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18389931412086905',	'i:1;',	1777294177),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17887425039474104',	'i:1;',	1777301897),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17886314490378941',	'i:1;',	1777306358),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18117386512669438',	'i:1;',	1777307892),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18389079982082447',	'i:1;',	1777309526),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18110592889866640',	'i:1;',	1777313915),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18178140451381729',	'i:1;',	1777315071),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18086285528615373',	'i:1;',	1777316721),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18099809321090599',	'i:1;',	1777317825),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17946372735174884',	'i:1;',	1777318820),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18120100231567440',	'i:1;',	1777326004),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18097027222873778',	'i:1;',	1777326545),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17932029816071057',	'i:1;',	1777326550),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18089143042999016',	'i:1;',	1777326553),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17936140830208308',	'i:1;',	1777331620),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18105033583933063',	'i:1;',	1777331625),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17870639583607324',	'i:1;',	1777332235),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18453952711105147',	'i:1;',	1777332646),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18181682545387173',	'i:1;',	1777349760),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18037921790792441',	'i:1;',	1777349764),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18388811413090797',	'i:1;',	1777353670),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17886229788489919',	'i:1;',	1777363030),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17884148343517953',	'i:1;',	1777363036),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18113762419749748',	'i:1;',	1777376672),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18060849167708217',	'i:1;',	1777384290),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18166742929423000',	'i:1;',	1777385840),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18093980264470069',	'i:1;',	1777385841),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18079443443256149',	'i:1;',	1777387690),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18418644574123753',	'i:1;',	1777387695),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17945615520168867',	'i:1;',	1777387702),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18048798770738476',	'i:1;',	1777393925),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18006911936883398',	'i:1;',	1777394068),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18208318351333175',	'i:1;',	1777394073),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18083935862457077',	'i:1;',	1777399081),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18108358459895552',	'i:1;',	1777403144),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17951789463127462',	'i:1;',	1777410824),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18179697763382589',	'i:1;',	1777413128),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17898497154281763',	'i:1;',	1777413132),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17994056549775505',	'i:1;',	1777413793),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18088366970018304',	'i:1;',	1777414168),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18013852850847543',	'i:1;',	1777432735),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18129770071603354',	'i:1;',	1777432742),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18101086199279300',	'i:1;',	1777433697),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18090495485189834',	'i:1;',	1777435808),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17858036004691341',	'i:1;',	1777435814),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17864867784546313',	'i:1;',	1777439398),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17867795397612101',	'i:1;',	1777442136),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18072849629275859',	'i:1;',	1777447951),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17971848774047855',	'i:1;',	1777450607),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18123325237716539',	'i:1;',	1777450612),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18004652144874713',	'i:1;',	1777470111),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17962842411079445',	'i:1;',	1777470887),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18008361008890923',	'i:1;',	1777470894),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17885747208533007',	'i:1;',	1777473999),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18094628840125227',	'i:1;',	1777474004),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17875830120597653',	'i:1;',	1777477418),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18137500999523380',	'i:1;',	1777485046),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18088586525363871',	'i:1;',	1777485682),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17878802262568612',	'i:1;',	1777485687),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18087172610580214',	'i:1;',	1777489451),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18412974196181843',	'i:1;',	1777489458),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17910851172196385',	'i:1;',	1777489490),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17922083490319510',	'i:1;',	1777494831),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17936103081218975',	'i:1;',	1777495560),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17895262542307613',	'i:1;',	1777495565),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18140674036506727',	'i:1;',	1777500595),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18090960788266949',	'i:1;',	1777501893),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18090872501222129',	'i:1;',	1777501898),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18108451922506895',	'i:1;',	1777501907),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18175923823397579',	'i:1;',	1777504098),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18012374489841914',	'i:1;',	1777518741),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18102887533981527',	'i:1;',	1777520219),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17967101640060522',	'i:1;',	1777522233),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18127556398608053',	'i:1;',	1777527076),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18093468121935802',	'i:1;',	1777527083),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18049999115745250',	'i:1;',	1777545218),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18070628483309531',	'i:1;',	1777545224),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17958969437942878',	'i:1;',	1777547661),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18133869778552902',	'i:1;',	1777548209),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18032698049613942',	'i:1;',	1777550838),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18209906524328294',	'i:1;',	1777558368),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18129154090585496',	'i:1;',	1777558374),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17904958470407540',	'i:1;',	1777560477),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18044509193545992',	'i:1;',	1777560508),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18123284464620777',	'i:1;',	1777565906),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18117031441669195',	'i:1;',	1777575661),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17877029778447722',	'i:1;',	1777576793),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18533207044073348',	'i:1;',	1777577532),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18095454134471135',	'i:1;',	1777585846),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17897383179434187',	'i:1;',	1777591260),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17882251146412866',	'i:1;',	1777592681),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18423888499193894',	'i:1;',	1777594039),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17885381418387271',	'i:1;',	1777596111),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17962322271082129',	'i:1;',	1777608174),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18127150939588128',	'i:1;',	1777611951),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17991895208985492',	'i:1;',	1777615818),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18323483773254730',	'i:1;',	1777615823),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17954209179070675',	'i:1;',	1777622500),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18334614478222091',	'i:1;',	1777627004),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18457556908104479',	'i:1;',	1777636439),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18087500237599219',	'i:1;',	1777644296),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18307963519302555',	'i:1;',	1777644301),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18104012359756630',	'i:1;',	1777662685),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18451873534116101',	'i:1;',	1777666235),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18029228270803076',	'i:1;',	1777666311),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18002674292927586',	'i:1;',	1777666317),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18102654184803476',	'i:1;',	1777678188),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17895693840306421',	'i:1;',	1777681825),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18089760461593048',	'i:1;',	1777691460),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18115628938739968',	'i:1;',	1777691466),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18129297910572688',	'i:1;',	1777695838),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18211143235335280',	'i:1;',	1777695844),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17968546434052141',	'i:1;',	1777700827),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18088240652601318',	'i:1;',	1777706425),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18325624465253645',	'i:1;',	1777706633),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17957602998120274',	'i:1;',	1777708159),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18419597257127945',	'i:1;',	1777728212),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18099110164856311',	'i:1;',	1777738189),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17950146221981568',	'i:1;',	1777740328),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18361316323228232',	'i:1;',	1777740334),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18110811910882327',	'i:1;',	1777740920),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18223272817314778',	'i:1;',	1777740927),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18088392974615072',	'i:1;',	1777745266),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18105655240933129',	'i:1;',	1777745272),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18080885234143942',	'i:1;',	1777745382),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18188584336372894',	'i:1;',	1777745383),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18114561820755992',	'i:1;',	1777745584),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18068384711661519',	'i:1;',	1777754075),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17875966518595901',	'i:1;',	1777767323),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18040693535583080',	'i:1;',	1777773294),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18450110722115107',	'i:1;',	1777773301),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18129996634564594',	'i:1;',	1777779277),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18580395982048075',	'i:1;',	1777790665),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17999680475928327',	'i:1;',	1777802299),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17974387908010540',	'i:1;',	1777807365),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17890097403352108',	'i:1;',	1777809604),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18346936141208819',	'i:1;',	1777815190),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18068745548663438',	'i:1;',	1777817215),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18414292006133172',	'i:1;',	1777823303),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18029531084630503',	'i:1;',	1777832797),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18107131840928801',	'i:1;',	1777841780),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18411022342177559',	'i:1;',	1777842154),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18160762333445833',	'i:1;',	1777842426),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18040438694586499',	'i:1;',	1777848181),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17987372687987582',	'i:1;',	1777851684),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18022371866655566',	'i:1;',	1777857445),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17876890998449555',	'i:1;',	1777857837),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18072815366644366',	'i:1;',	1777858259),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17949997464136676',	'i:1;',	1777875752),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18463420495100435',	'i:1;',	1777882459),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18180679147390547',	'i:1;',	1777889833),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18054719339503219',	'i:1;',	1777894898),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18118399300673178',	'i:1;',	1777898576),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18126697906522298',	'i:1;',	1777898822),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17994876371958289',	'i:1;',	1777898827),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18349288717211891',	'i:1;',	1777912065),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18063519689418769',	'i:1;',	1777931293),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18094162961006274',	'i:1;',	1777936943),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17959708386110670',	'i:1;',	1777938524),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18005663663871529',	'i:1;',	1777938529),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18073471064273779',	'i:1;',	1777938890),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17857448010638612',	'i:1;',	1777938899),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17913745437181302',	'i:1;',	1777939907),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17949225078138911',	'i:1;',	1777941867),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18126103339588236',	'i:1;',	1777941873),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17920199610346684',	'i:1;',	1777941917),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17924419905318159',	'i:1;',	1777947223),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18162773968381979',	'i:1;',	1777948570),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17976232832859278',	'i:1;',	1777948576),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17859796164688206',	'i:1;',	1777953356),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17999935964755605',	'i:1;',	1777954043),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17931339528255556',	'i:1;',	1777963851),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18112198018798753',	'i:1;',	1777969202),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18119619904635903',	'i:1;',	1777974790),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18069045158690711',	'i:1;',	1777984215),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18083772446100285',	'i:1;',	1777984222),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17992147280953882',	'i:1;',	1778004018),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18102643466286234',	'i:1;',	1778005110),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17931307032266540',	'i:1;',	1778005332),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17888594760477589',	'i:1;',	1778018188),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18142506865451818',	'i:1;',	1778020493),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18089877926605427',	'i:1;',	1778022361),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18578805256055084',	'i:1;',	1778022366),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18011452922704770',	'i:1;',	1778040313),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18054306596535038',	'i:1;',	1778040318),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17985634748989007',	'i:1;',	1778042875),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17884399578537033',	'i:1;',	1778042881),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18034372469796891',	'i:1;',	1778046542),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18087844463200321',	'i:1;',	1778049883),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18007440845893148',	'i:1;',	1778049888),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18079838156303859',	'i:1;',	1778052015),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18105274748492388',	'i:1;',	1778057395),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17995772987955731',	'i:1;',	1778057401),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17983368143998183',	'i:1;',	1778057542),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18120284578635337',	'i:1;',	1778074869),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18096891197331776',	'i:1;',	1778076199),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18025339826643244',	'i:1;',	1778076206),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18079546889172799',	'i:1;',	1778080853),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17876320098455844',	'i:1;',	1778082511),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18111085315798631',	'i:1;',	1778092222),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18137072743543521',	'i:1;',	1778148459),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18112074610878356',	'i:1;',	1778148467),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18004977911863967',	'i:1;',	1778168026),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18128034367610560',	'i:1;',	1778168032),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18434624896186895',	'i:1;',	1778168151),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17960062632093111',	'i:1;',	1778168157),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18128479828514255',	'i:1;',	1778168317),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18091209743590436',	'i:1;',	1778168326),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18108984778884855',	'i:1;',	1778168462),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18141605749503032',	'i:1;',	1778168471),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18065871110357119',	'i:1;',	1778169051),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18014046617896552',	'i:1;',	1778169056),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17991284291793261',	'i:1;',	1778169716),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17886178182535524',	'i:1;',	1778170294),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18079327235156377',	'i:1;',	1778171811),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18575596819062707',	'i:1;',	1778173824),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18124417189618723',	'i:1;',	1778173830),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17904871734245558',	'i:1;',	1778174011),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18046415039775851',	'i:1;',	1778176007),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18588217159046388',	'i:1;',	1778176073),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17972487561040504',	'i:1;',	1778176080),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18132042826559615',	'i:1;',	1778179667),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17961120795081100',	'i:1;',	1778185266),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17925915435289516',	'i:1;',	1778187011),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17887668708485108',	'i:1;',	1778187017),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18126027853722241',	'i:1;',	1778209340),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17914045191182778',	'i:1;',	1778216621),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18100526402078319',	'i:1;',	1778216633),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17994206024957627',	'i:1;',	1778221100),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18197904586348424',	'i:1;',	1778250879),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18104784146317051',	'i:1;',	1778255955),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18107299663898015',	'i:1;',	1778261174),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18421881460130729',	'i:1;',	1778265212),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18065699912378358',	'i:1;',	1778271381),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18356668033300074',	'i:1;',	1778271389),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18082847432454674',	'i:1;',	1778276398),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18012504428698805',	'i:1;',	1778278106),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18089703302349854',	'i:1;',	1778283350),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18093290204588182',	'i:1;',	1778283599),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18008854295908538',	'i:1;',	1778292440),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18156202558456298',	'i:1;',	1778292446),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17869040181613606',	'i:1;',	1778330703),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17887697217513488',	'i:1;',	1778340812),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18095762237151299',	'i:1;',	1778340823),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17968625057902381',	'i:1;',	1778340845),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18108638008911630',	'i:1;',	1778340850),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18105824366483734',	'i:1;',	1778344075),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18357297475232523',	'i:1;',	1778344083),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17878170321584574',	'i:1;',	1778347322),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18091572401351098',	'i:1;',	1778347328),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18295068802303018',	'i:1;',	1778347782),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17900631738429569',	'i:1;',	1778347788),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18124380532558317',	'i:1;',	1778349384),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17879121546437984',	'i:1;',	1778349390),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18102535160478644',	'i:1;',	1778349800),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18103643504061641',	'i:1;',	1778349805),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18023439761652696',	'i:1;',	1778353265),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17952782034131687',	'i:1;',	1778353277),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17871063099506370',	'i:1;',	1778355709),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17933151504068996',	'i:1;',	1778355715),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17881453896561291',	'i:1;',	1778358987),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18520866313078002',	'i:1;',	1778358997),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18121783360724479',	'i:1;',	1778362006),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17913292044383350',	'i:1;',	1778362012),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18588039184043438',	'i:1;',	1778365338),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18101970835980498',	'i:1;',	1778365345),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17926287228277665',	'i:1;',	1778365442),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18128040940579601',	'i:1;',	1778365450),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18322297159248317',	'i:1;',	1778365463),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18084675290093251',	'i:1;',	1778365471),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17877062799596716',	'i:1;',	1778368794),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18088796195193827',	'i:1;',	1778385943),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17970739698026071',	'i:1;',	1778415288),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18117972994708039',	'i:1;',	1778415294),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18353238055211904',	'i:1;',	1778426240),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17899658955441033',	'i:1;',	1778427985),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18548450098069304',	'i:1;',	1778428727),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18063503171425520',	'i:1;',	1778428735),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18289605205305141',	'i:1;',	1778428779),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17905069491423037',	'i:1;',	1778429167),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18100159109071777',	'i:1;',	1778431189),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17965558077101200',	'i:1;',	1778432388),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18111400393865143',	'i:1;',	1778432395),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17863901340565021',	'i:1;',	1778437608),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18014725241692468',	'i:1;',	1778437892),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18024526667821747',	'i:1;',	1778437901),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18088816808020072',	'i:1;',	1778448128),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17975648972867770',	'i:1;',	1778448834),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18104924209744387',	'i:1;',	1778452212),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18083395892106210',	'i:1;',	1778458202),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17973444735031477',	'i:1;',	1778458209),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17859666678691745',	'i:1;',	1778463261),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17895713625448374',	'i:1;',	1778463429),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17888557995498976',	'i:1;',	1778463437),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17913461829378722',	'i:1;',	1778464728),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18089246276603069',	'i:1;',	1778464972),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18070210607663459',	'i:1;',	1778485296),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18086824706594665',	'i:1;',	1778490153),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18318826450281720',	'i:1;',	1778492428),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17919655749145679',	'i:1;',	1778492670),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18101565215042340',	'i:1;',	1778496014),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18434445637141961',	'i:1;',	1778518585),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18349606699215285',	'i:1;',	1778523627),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18098968927861080',	'i:1;',	1778525320),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17999489681927573',	'i:1;',	1778531663),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18030541523662260',	'i:1;',	1778541977),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18602459953032641',	'i:1;',	1778555620),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18140217643518026',	'i:1;',	1778562310),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17964501278915670',	'i:1;',	1778563046),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18410217763181909',	'i:1;',	1778563893),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17979831086868239',	'i:1;',	1778565118),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17951350802982683',	'i:1;',	1778565403),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18053353205718857',	'i:1;',	1778566888),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18009700097906888',	'i:1;',	1778573816),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18110446303930197',	'i:1;',	1778581840),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18097681643274707',	'i:1;',	1778591731),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18056526065713556',	'i:1;',	1778598689),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17915328573365115',	'i:1;',	1778601035),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17856422985642232',	'i:1;',	1778603845),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18096230093142214',	'i:1;',	1778607498),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18116769805693499',	'i:1;',	1778610396),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17940384918207205',	'i:1;',	1778615256),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18088646405033927',	'i:1;',	1778620767),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18221749393316211',	'i:1;',	1778623653),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17869063161527540',	'i:1;',	1778641334),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17940260172035733',	'i:1;',	1778675017),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17936960301053397',	'i:1;',	1778675060),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18087143309053586',	'i:1;',	1778677520),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17963229447115225',	'i:1;',	1778677864),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17970385083047431',	'i:1;',	1778678839),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18389124331094425',	'i:1;',	1778707527),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18088394054197793',	'i:1;',	1778720669),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18011898113904098',	'i:1;',	1778762371),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18111493450867375',	'i:1;',	1778765247),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18111706747846809',	'i:1;',	1778773636),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18099194255087886',	'i:1;',	1778774161),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17888680095532460',	'i:1;',	1778775175),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17909913486402969',	'i:1;',	1778776667),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17975091207013927',	'i:1;',	1778786016),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17953149147133827',	'i:1;',	1778791611),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18080104169155322',	'i:1;',	1778791916),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18206751577339342',	'i:1;',	1778793777),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17865394836623858',	'i:1;',	1778809881),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17849792040695873',	'i:1;',	1778819530),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18179044831354879',	'i:1;',	1778825307),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18074833628667828',	'i:1;',	1778835996),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18075052592256250',	'i:1;',	1778838034),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17888330826503291',	'i:1;',	1778844347),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18100926884013899',	'i:1;',	1778844369),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18099748793015615',	'i:1;',	1778848565),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18152260957468953',	'i:1;',	1778854309),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18593674489012322',	'i:1;',	1778867551),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17938959573218748',	'i:1;',	1778867559),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18102834583990931',	'i:1;',	1778869592),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18590024440025751',	'i:1;',	1778870564),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17888789817481727',	'i:1;',	1778875287),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18402552754151268',	'i:1;',	1778883333),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18120203458583034',	'i:1;',	1778894277),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18326165071264797',	'i:1;',	1778928175),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18111574045850205',	'i:1;',	1778935775),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17877124242460608',	'i:1;',	1778952040),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17909110584224329',	'i:1;',	1778952580),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18119495314739623',	'i:1;',	1778958399),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17866639128548706',	'i:1;',	1778965137),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18392746795086419',	'i:1;',	1778967385),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18064926773409413',	'i:1;',	1778967802),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17889580239482827',	'i:1;',	1778973105),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18054947195509867',	'i:1;',	1778981407),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17894654277454787',	'i:1;',	1778989937),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18424479973125138',	'i:1;',	1779007144),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18214017016330362',	'i:1;',	1779013913),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18170556721414009',	'i:1;',	1779048292),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18127857520587671',	'i:1;',	1779048299),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17901944793431582',	'i:1;',	1779051054),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18046129973782677',	'i:1;',	1779089360),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18435074959184513',	'i:1;',	1779103899),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18115794322768424',	'i:1;',	1779119275),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18106538062823975',	'i:1;',	1779164155),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17977434359990594',	'i:1;',	1779164159),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18085780706611084',	'i:1;',	1779185776),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18314456734277259',	'i:1;',	1779190582),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17951958300140285',	'i:1;',	1779205012),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18137296117479559',	'i:1;',	1779205077),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17981586317843653',	'i:1;',	1779213878),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17914508850183378',	'i:1;',	1779224484),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18098305370137905',	'i:1;',	1779318170),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18081532799411213',	'i:1;',	1779338743),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18313736713279506',	'i:1;',	1779361888),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18589437460044254',	'i:1;',	1779388653),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17916108264380123',	'i:1;',	1779390744),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18103893373994101',	'i:1;',	1779422555),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18114481774874533',	'i:1;',	1779531668),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18090244937613656',	'i:1;',	1779554169),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17973493785044549',	'i:1;',	1779608626),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18171375232373993',	'i:1;',	1779611298),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17964138599931200',	'i:1;',	1779814729),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18101954585040588',	'i:1;',	1779899119),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18160835335446307',	'i:1;',	1779899122),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17984591616006406',	'i:1;',	1780002157),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18319052605277363',	'i:1;',	1780007336),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17891007225482028',	'i:1;',	1780093896),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18321248416287530',	'i:1;',	1780108471),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17858294439640658',	'i:1;',	1780112620),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17990032373800383',	'i:1;',	1780210887),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18589140562021215',	'i:1;',	1780257888),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18110802004713111',	'i:1;',	1780400137),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18081740909403452',	'i:1;',	1780500061),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18095490172961191',	'i:1;',	1780553984),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18100798859035916',	'i:1;',	1780643345),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18426502648132593',	'i:1;',	1780673555),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18079313210220033',	'i:1;',	1780883001),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18068840669464902',	'i:1;',	1785002164),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18110668991076592',	'i:1;',	1785002610),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18059191274590713',	'i:1;',	1785003042),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18080503913289501',	'i:1;',	1785003045),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17912860056244158',	'i:1;',	1785003664),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18109333979042206',	'i:1;',	1785003864),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17999777276969251',	'i:1;',	1785003868),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18091743236634385',	'i:1;',	1785003929),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18069180515427477',	'i:1;',	1785004374),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17893078146579836',	'i:1;',	1785004377),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17957988276159753',	'i:1;',	1785004775),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17897601075484672',	'i:1;',	1785004779),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17986930578033442',	'i:1;',	1785006112),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18079156409675504',	'i:1;',	1785006116),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17944448484254244',	'i:1;',	1785007093),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17973584163110117',	'i:1;',	1785007097),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18017825222880187',	'i:1;',	1785007204),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18098792966250808',	'i:1;',	1785007208),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17870146083631109',	'i:1;',	1785008643),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17923691049165357',	'i:1;',	1785008647),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17940479625268095',	'i:1;',	1785010513),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17948963364232468',	'i:1;',	1785010516),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17959855134175179',	'i:1;',	1785012404),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18346951135175390',	'i:1;',	1785012407),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18102280154337255',	'i:1;',	1785013891),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18421071481198365',	'i:1;',	1785013895),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18099462521258850',	'i:1;',	1785014043),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17971030424924768',	'i:1;',	1785014047),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18009676562944194',	'i:1;',	1785014695),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17984425205856199',	'i:1;',	1785014700),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18126651997733070',	'i:1;',	1785017704),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18109358728815092',	'i:1;',	1785017707),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17980004462878011',	'i:1;',	1785018485),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18201835666367648',	'i:1;',	1785018488),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18125751817668610',	'i:1;',	1785019369),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18121734550817007',	'i:1;',	1785019372),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18082125923244588',	'i:1;',	1785023833),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18078220610314750',	'i:1;',	1785023837),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18093773795384857',	'i:1;',	1785025295),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18098303096208087',	'i:1;',	1785025299),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17973749247084930',	'i:1;',	1785025325),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18095278457036506',	'i:1;',	1785025327),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18150156193505989',	'i:1;',	1785025641),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18017206217911337',	'i:1;',	1785025644),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18096855386627015',	'i:1;',	1785026209),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18573850933068045',	'i:1;',	1785026210),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17901069525494987',	'i:1;',	1785026212),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17896578234560667',	'i:1;',	1785026213),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18330931843286582',	'i:1;',	1785028572),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18134339914613969',	'i:1;',	1785028577),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18072099944470704',	'i:1;',	1785034518),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18110331179087361',	'i:1;',	1785034522),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18101753219184037',	'i:1;',	1785035660),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18127211659675960',	'i:1;',	1785035664),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18100170425612716',	'i:1;',	1785038106),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18188441599384455',	'i:1;',	1785038112),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18131239939540760',	'i:1;',	1785039065),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18100042043590966',	'i:1;',	1785039068),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17898884364474387',	'i:1;',	1785040705),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18608951077062753',	'i:1;',	1785040708),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18120153667629965',	'i:1;',	1785045303),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18110007310787690',	'i:1;',	1785045307),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18106325513043680',	'i:1;',	1785046461),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17981948700027986',	'i:1;',	1785046464),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18129288610711521',	'i:1;',	1785047541),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18109945832294834',	'i:1;',	1785047545),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17908031952451028',	'i:1;',	1785050593),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18074001239356488',	'i:1;',	1785050597),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17904369912465069',	'i:1;',	1785054334),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18024221120845398',	'i:1;',	1785054338),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17998610162987077',	'i:1;',	1785066487),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17950505232226556',	'i:1;',	1785066491),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18131484241713717',	'i:1;',	1785076470),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17899483476509750',	'i:1;',	1785076475),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18059238815743904',	'i:1;',	1785084490),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17950223001229935',	'i:1;',	1785084493),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18337190605264976',	'i:1;',	1785086423),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18091715981381857',	'i:1;',	1785086427),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18101290685225806',	'i:1;',	1785086488),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18608430955057729',	'i:1;',	1785086492),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18360399004211057',	'i:1;',	1785089171),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17891135166396742',	'i:1;',	1785089176),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18072364280703240',	'i:1;',	1785089837),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18137816113565814',	'i:1;',	1785099423),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18119994937633220',	'i:1;',	1785099426),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18105762704111125',	'i:1;',	1785100078),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18113624422734790',	'i:1;',	1785100081),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17944321167255858',	'i:1;',	1785111097),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18104880167038412',	'i:1;',	1785111101),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18083738687215198',	'i:1;',	1785111156),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18104816569888925',	'i:1;',	1785111160),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17920049925406751',	'i:1;',	1785111326),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18427604857133444',	'i:1;',	1785111331),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18211071394352090',	'i:1;',	1785124913),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18109839307961382',	'i:1;',	1785124917),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18142340434558534',	'i:1;',	1785166837),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18084357542423479',	'i:1;',	1785166841),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:18120836489506793',	'i:1;',	1785192925),
('joan-paneque-joanpanequecom-cache-instagram:comment_rule:17938408509292664',	'i:1;',	1785192930);

DROP TABLE IF EXISTS "cache_locks";
CREATE TABLE "public"."cache_locks" (
    "key" character varying(255) NOT NULL,
    "owner" character varying(255) NOT NULL,
    "expiration" integer NOT NULL,
    CONSTRAINT "cache_locks_pkey" PRIMARY KEY ("key")
)
WITH (oids = false);


DROP TABLE IF EXISTS "calendar_chat_messages";
DROP SEQUENCE IF EXISTS calendar_chat_messages_id_seq;
CREATE SEQUENCE calendar_chat_messages_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."calendar_chat_messages" (
    "id" bigint DEFAULT nextval('calendar_chat_messages_id_seq') NOT NULL,
    "calendar_chat_id" bigint NOT NULL,
    "role" character varying(20) NOT NULL,
    "content" text NOT NULL,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "calendar_chat_messages_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE INDEX calendar_chat_messages_calendar_chat_id_created_at_index ON public.calendar_chat_messages USING btree (calendar_chat_id, created_at);


DROP TABLE IF EXISTS "calendar_chats";
DROP SEQUENCE IF EXISTS calendar_chats_id_seq;
CREATE SEQUENCE calendar_chats_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."calendar_chats" (
    "id" bigint DEFAULT nextval('calendar_chats_id_seq') NOT NULL,
    "user_id" bigint NOT NULL,
    "title" character varying(255) DEFAULT 'Nuevo chat' NOT NULL,
    "last_message_at" timestamp(0),
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "calendar_chats_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE INDEX calendar_chats_user_id_last_message_at_index ON public.calendar_chats USING btree (user_id, last_message_at);

CREATE INDEX calendar_chats_last_message_at_index ON public.calendar_chats USING btree (last_message_at);


DROP TABLE IF EXISTS "calendar_event_indexes";
DROP SEQUENCE IF EXISTS calendar_event_indexes_id_seq;
CREATE SEQUENCE calendar_event_indexes_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."calendar_event_indexes" (
    "id" bigint DEFAULT nextval('calendar_event_indexes_id_seq') NOT NULL,
    "user_id" bigint NOT NULL,
    "google_event_id" character varying(255) NOT NULL,
    "google_recurring_event_id" character varying(255),
    "title" character varying(255),
    "start_date" date,
    "end_date" date,
    "start_time" time(0) without time zone,
    "end_time" time(0) without time zone,
    "color" character varying(255),
    "is_all_day" boolean DEFAULT false NOT NULL,
    "is_recurring" boolean DEFAULT false NOT NULL,
    "recurrence" json,
    "recurrence_rule" character varying(255),
    "recurrence_frequency" character varying(255),
    "recurrence_interval" integer,
    "recurrence_by_day" json,
    "recurrence_until" timestamptz(0),
    "recurrence_count" integer,
    "embedding_input" text,
    "embedding_model" character varying(255),
    "embedding_fingerprint" character varying(64),
    "embedding_generated_at" timestamptz(0),
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    "embedding" vector(1024),
    CONSTRAINT "calendar_event_indexes_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE UNIQUE INDEX calendar_event_indexes_user_id_google_event_id_unique ON public.calendar_event_indexes USING btree (user_id, google_event_id);

CREATE INDEX calendar_event_indexes_user_id_start_date_index ON public.calendar_event_indexes USING btree (user_id, start_date);

CREATE INDEX calendar_event_indexes_user_id_google_recurring_event_id_index ON public.calendar_event_indexes USING btree (user_id, google_recurring_event_id);


DROP TABLE IF EXISTS "calendar_message_change_logs";
DROP SEQUENCE IF EXISTS calendar_message_change_logs_id_seq;
CREATE SEQUENCE calendar_message_change_logs_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."calendar_message_change_logs" (
    "id" bigint DEFAULT nextval('calendar_message_change_logs_id_seq') NOT NULL,
    "calendar_chat_message_id" bigint NOT NULL,
    "changes" json NOT NULL,
    "reverted_at" timestamp(0),
    "revert_result" json,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "calendar_message_change_logs_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE INDEX calendar_message_change_logs_calendar_chat_message_id_reverted_ ON public.calendar_message_change_logs USING btree (calendar_chat_message_id, reverted_at);


DROP TABLE IF EXISTS "failed_jobs";
DROP SEQUENCE IF EXISTS failed_jobs_id_seq;
CREATE SEQUENCE failed_jobs_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."failed_jobs" (
    "id" bigint DEFAULT nextval('failed_jobs_id_seq') NOT NULL,
    "uuid" character varying(255) NOT NULL,
    "connection" text NOT NULL,
    "queue" text NOT NULL,
    "payload" text NOT NULL,
    "exception" text NOT NULL,
    "failed_at" timestamp(0) DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT "failed_jobs_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE UNIQUE INDEX failed_jobs_uuid_unique ON public.failed_jobs USING btree (uuid);


DROP TABLE IF EXISTS "instagram_direct_messages";
DROP SEQUENCE IF EXISTS instagram_direct_messages_id_seq;
CREATE SEQUENCE instagram_direct_messages_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."instagram_direct_messages" (
    "id" bigint DEFAULT nextval('instagram_direct_messages_id_seq') NOT NULL,
    "peer_ig_user_id" character varying(255) NOT NULL,
    "direction" character varying(16) NOT NULL,
    "body" text NOT NULL,
    "meta_message_id" character varying(255),
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "instagram_direct_messages_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE INDEX instagram_direct_messages_peer_ig_user_id_index ON public.instagram_direct_messages USING btree (peer_ig_user_id);

CREATE UNIQUE INDEX instagram_direct_messages_meta_message_id_unique ON public.instagram_direct_messages USING btree (meta_message_id);

INSERT INTO "instagram_direct_messages" ("id", "peer_ig_user_id", "direction", "body", "meta_message_id", "created_at", "updated_at") VALUES
(1,	'1326558189317534',	'inbound',	'hola buenas',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDEzMzEzMjE5MjY3MTA4MDozMjc3MDk2MTUxNTk3ODE5NjA2NDA2ODU2NDI0NjU5MzUzNgZDZD',	'2026-04-18 13:03:04',	'2026-04-18 13:03:04'),
(2,	'1326558189317534',	'inbound',	'hola buenas',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDEzMzEzMjE5MjY3MTA4MDozMjc3MDk2MjI0MjYyOTA5MTk4ODY3ODI0ODYyMjk4MTEyMAZDZD',	'2026-04-18 13:03:43',	'2026-04-18 13:03:43'),
(3,	'1326558189317534',	'outbound',	'¡Hola! ¿En qué puedo ayudarte hoy?',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDEzMzEzMjE5MjY3MTA4MDozMjc3MDk2MjI5NTMwOTY5MTA5NjAwMzUzNDAyODUzNzg1NgZDZD',	'2026-04-18 13:03:45',	'2026-04-18 13:03:45'),
(4,	'1326558189317534',	'inbound',	'no lo se, dime en que me puedes ayudar',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDEzMzEzMjE5MjY3MTA4MDozMjc3MDk2Mjk5NDA1MDQ0MTg3NjE2MTc4MjI5NTI5ODA0OAZDZD',	'2026-04-18 13:04:24',	'2026-04-18 13:04:24'),
(5,	'1326558189317534',	'outbound',	'Claro, puedo ayudarte con:

- Información sobre nuestros productos o servicios.  
- Consultas sobre pedidos, envíos y devoluciones.  
- Soporte técnico o dudas sobre el uso de la plataforma.  
- Horarios, ubicaciones y contacto de nuestras sucursales.  
- Cualquier otra pregunta que tengas sobre la marca.

¡Solo dime qué necesitas!',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDEzMzEzMjE5MjY3MTA4MDozMjc3MDk2MzAyOTA1MzU4MTQ3Nzg4MzQyNTUxNTg5NjgzMgZDZD',	'2026-04-18 13:04:25',	'2026-04-18 13:04:25'),
(6,	'2124250091644267',	'outbound',	'holaaa',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MDk2NDA0MjU1Nzc0ODc2ODg3MDIxNDczNTQ5NTE2OAZDZD',	'2026-04-18 13:05:21',	'2026-04-18 13:05:21'),
(7,	'2124250091644267',	'outbound',	'escribemeee',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MDk2NDA4MDY0MzgwMDQ3MzkxMDU2Njc2OTkxNzk1MgZDZD',	'2026-04-18 13:05:23',	'2026-04-18 13:05:23'),
(8,	'2124250091644267',	'outbound',	'ya verasss',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MDk2NDE1MDM1ODY5NDkwNzk2NTUzNzEzMzc4OTE4NAZDZD',	'2026-04-18 13:05:26',	'2026-04-18 13:05:26'),
(9,	'2124250091644267',	'inbound',	'holaa',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MDk2NDM5MTA2MzExOTQzNTg0NDk1MDU3NDQ5Nzc5MgZDZD',	'2026-04-18 13:05:40',	'2026-04-18 13:05:40'),
(10,	'2124250091644267',	'outbound',	'¡Hola! ¿En qué te puedo ayudar hoy?',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MDk2NDQzODY4NzUwMjg4NjA1NDU5NTMwMTIxMjE2MAZDZD',	'2026-04-18 13:05:42',	'2026-04-18 13:05:42'),
(11,	'2124250091644267',	'inbound',	'vaya indirecta hagahahahaha',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MDk2NDc3ODg4NTIxNjMzODczNzU3MTE4Mzk4NDY0MAZDZD',	'2026-04-18 13:06:01',	'2026-04-18 13:06:01'),
(12,	'2124250091644267',	'outbound',	'Jajaja, ¿qué te cuenta? 😄',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MDk2NDgxMTkwNDc0MDY1NjcyNTA3ODkwMDIxMTcxMgZDZD',	'2026-04-18 13:06:02',	'2026-04-18 13:06:02'),
(13,	'2124250091644267',	'inbound',	'ehat',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MDk2NDkzMDE3MzU2ODQyMTYwNzk5MjAwNjI3OTE2OAZDZD',	'2026-04-18 13:06:09',	'2026-04-18 13:06:09'),
(14,	'2124250091644267',	'outbound',	'¡Qué curioso! ¿Quieres compartir algo? 😆',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MDk2NDk3MzE1NTUxNTEzMTAxOTM3NTAwNjQ0OTY2NAZDZD',	'2026-04-18 13:06:11',	'2026-04-18 13:06:11'),
(15,	'2124250091644267',	'inbound',	'regalame flores y te regalo un cubo de tungsteno',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MDk2NTM2MTc4OTEyMTE5OTIwMjYyNjIxMDYyNzU4NAZDZD',	'2026-04-18 13:06:32',	'2026-04-18 13:06:32'),
(16,	'2124250091644267',	'outbound',	'🌸🌼🌺 ¡Flores virtuales para ti! Y el cubo de tungsteno suena súper pesado... ¿para qué lo usarías? 😄',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MDk2NTQxNjExMzE5NjA3NjI4NjkxNjY5ODMwODYwOAZDZD',	'2026-04-18 13:06:35',	'2026-04-18 13:06:35'),
(17,	'2124250091644267',	'inbound',	'lo hisiste con IA',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MDk2NTYzNTQxOTA0Njk5MDUyNTg0OTc4Mjk3NjUxMgZDZD',	'2026-04-18 13:06:47',	'2026-04-18 13:06:47'),
(18,	'2124250091644267',	'outbound',	'Sí, soy IA 😊. ¿Hay algo más en lo que pueda ayudarte?',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MDk2NTY3MTk2NjYyMTc5MzA3NDc1MTUwMzA3MzI4MAZDZD',	'2026-04-18 13:06:49',	'2026-04-18 13:06:49'),
(19,	'2124250091644267',	'outbound',	'xddd',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MDk2NTc1ODE3Nzc5MzgxNjIwNTU5NDA0MjgyNjc1MgZDZD',	'2026-04-18 13:06:54',	'2026-04-18 13:06:54'),
(20,	'2124250091644267',	'inbound',	'que guay la automatizacion',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MDk2Njc1MTM2OTA1MjE2OTI2NjAwNDg1NzE5MjQ0OAZDZD',	'2026-04-18 13:07:48',	'2026-04-18 13:07:48'),
(21,	'2124250091644267',	'outbound',	'¡Me alegra que te guste! 🚀 Si necesitas algo más, aquí estoy.',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MDk2NjkzMjkyMTE1MTAyNjIwODM4OTc3MDI0ODE5MgZDZD',	'2026-04-18 13:07:57',	'2026-04-18 13:07:57'),
(22,	'2124250091644267',	'outbound',	'graciasss :)))',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MDk2NzAxNjMyMzk5MDczMTU1NzY5MDE3MTk4MTgyNAZDZD',	'2026-04-18 13:08:02',	'2026-04-18 13:08:02'),
(23,	'2124250091644267',	'inbound',	'quieres un tungsten cube?',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MDk2NzE1OTA5MTc3MzI4MDAzNzU5NTM5MzI5NDMzNgZDZD',	'2026-04-18 13:08:10',	'2026-04-18 13:08:10'),
(24,	'2124250091644267',	'outbound',	'¡Jajaja, suena interesante! No lo necesito, pero agradezco la oferta. 😄',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MDk2NzE5NTk0MjE1MTM4NjU1NjQzOTQwMzE2Nzc0NAZDZD',	'2026-04-18 13:08:11',	'2026-04-18 13:08:11'),
(25,	'2124250091644267',	'outbound',	'pero era una prueba',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MDk2NzIyMDE5Mzk3NTEzOTc5Nzk0NDY1NTQxMzI0OAZDZD',	'2026-04-18 13:08:13',	'2026-04-18 13:08:13'),
(26,	'2124250091644267',	'outbound',	'que va era una tonteria no era para que me lo regalases',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MDk2NzYzNDIyODEwMjE2MTQzNjY2ODYwMDUxNjYwOAZDZD',	'2026-04-18 13:08:35',	'2026-04-18 13:08:35'),
(27,	'2124250091644267',	'inbound',	'au vale pensaba que te gustaba',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MDk2NzgwNDIwOTIyMjU0MzcyNzcwNTMyODcxMzcyOAZDZD',	'2026-04-18 13:08:45',	'2026-04-18 13:08:45'),
(28,	'2124250091644267',	'outbound',	'¡No hay problema! 😊 Si tienes otra idea o simplemente quieres charlar, aquí estoy.',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MDk2Nzg1MTQ5NzIyOTYxNTc1MzI1NjM4MTcxMDMzNgZDZD',	'2026-04-18 13:08:47',	'2026-04-18 13:08:47'),
(29,	'2124250091644267',	'outbound',	'en plan es muy real, prefiero cien veces mas un cubo de tungsteno que unas flores',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MDk2ODM0Nzg4OTc2MDE0MDAzMTkxOTYyNTYwMTAyNAZDZD',	'2026-04-18 13:09:14',	'2026-04-18 13:09:14'),
(30,	'2124250091644267',	'outbound',	'las flores son muy tipicas',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MDk2ODYyNTcxMTY5MDA3NTM2MTU2NTA5MzEzNDMzNgZDZD',	'2026-04-18 13:09:29',	'2026-04-18 13:09:29'),
(31,	'2124250091644267',	'inbound',	'ah vale',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MDk2ODg3NDI0MTQ0NDgwMDIzNzQ1NDg0Mzk2OTUzNgZDZD',	'2026-04-18 13:09:43',	'2026-04-18 13:09:43'),
(32,	'2124250091644267',	'outbound',	'¡Genial! Si necesitas algo o simplemente quieres charlar, aquí estoy. 😊',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MDk2ODkzNzQ2NTM3MjcxNjYxMTgwMzAyMzQwOTE1MgZDZD',	'2026-04-18 13:09:46',	'2026-04-18 13:09:46'),
(33,	'2124250091644267',	'inbound',	'entonces te lo regalo?',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MDk2ODk0Nzc0NDg1Nzc0NTE3NDU5ODA4MDUyODM4NAZDZD',	'2026-04-18 13:09:47',	'2026-04-18 13:09:47'),
(34,	'2124250091644267',	'outbound',	'¡Qué detalle! 😂 Un cubo de tungsteno sería todo un lujo. Si algún día lo tienes, me avisas y lo admiramos (aunque sea en foto). ¡Gracias por la intención!',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MDk2OTA1ODcxMjY0ODY3MzEyNDAwNzc1MjQ5OTIwMAZDZD',	'2026-04-18 13:09:52',	'2026-04-18 13:09:52'),
(35,	'2124250091644267',	'outbound',	'noo no hace falta jeje',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MDk2OTM0NDA0NTY4Njk2Njg5ODU2MTAyNzkzMjE2MAZDZD',	'2026-04-18 13:10:08',	'2026-04-18 13:10:08'),
(36,	'2124250091644267',	'inbound',	'ahh vale',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MDk3MDM2Njk2MzQzMDY3Mjg4NDE0NTI0MjI0MzA3MgZDZD',	'2026-04-18 13:11:04',	'2026-04-18 13:11:04'),
(37,	'2124250091644267',	'outbound',	'¡De acuerdo! Cuando quieras, aquí estoy. 😉',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MDk3MDQwNDQ2ODIyNTQ3MjE2MTkwOTMwNTI0NTY5NgZDZD',	'2026-04-18 13:11:05',	'2026-04-18 13:11:05'),
(38,	'2124250091644267',	'inbound',	'oue mola',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MDk3MDQwNjU0NTc3MTU3NjcxOTM3Mzg0NjQ0NjA4MAZDZD',	'2026-04-18 13:11:06',	'2026-04-18 13:11:06'),
(39,	'2124250091644267',	'outbound',	'¡Qué bueno que te guste! 🎉 If you need anything, just hit me up.',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MDk3MDQ4MTI3OTMyNDA5Njk1NTkxMjI0MjA2OTUwNAZDZD',	'2026-04-18 13:11:09',	'2026-04-18 13:11:09'),
(40,	'2124250091644267',	'inbound',	'hostia en ingles ahora que nivel',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MDk3MzY5NTU2NjE2ODc4MjgyODI4NTQzNzQxMTMyOAZDZD',	'2026-04-18 13:14:05',	'2026-04-18 13:14:05'),
(41,	'2124250091644267',	'outbound',	'**«Hostia» en inglés**  

- **Traducción literal**: *host* (el pan consagrado en la Eucaristía).  
- **Uso coloquial / vulgar**: es una **grosería** que suele traducirse como **“damn”, “fuck”, “shit”** o **“bloody”**, según el contexto y la intensidad que quieras darle.

**Nivel de fuerza**  
- En español es una palabrota bastante fuerte, aunque en algunos contextos informales se usa casi como un “¡vaya!” o “¡caramba!”.  
- En inglés, palabras como **“fuck”** o **“shit”** son igualmente fuertes y pueden resultar ofensivas si se usan en entornos formales o con desconocidos.  

**Ejemplos**  

| Español | Inglés (equivalente) |
|---|---|
| “¡Hostia, qué fuerte!” | “Damn, that''s intense!” |
| “¡Hostia! Se me olvidó el examen.” | “Fuck! I forgot the exam.” |
| “¡Hostia, qué rápido!” | “Bloody hell, that''s fast!” |

**Consejo**: Utiliza estas expresiones solo en conversaciones informales y con gente con la que tengas confianza, y evita usarlas en entornos profesionales o con personas que puedan sentirse ofendidas.',	NULL,	'2026-04-18 13:14:15',	'2026-04-18 13:14:15'),
(42,	'2124250091644267',	'outbound',	'jajaja es que he usado un modelo open source',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MDk3NDE2Njg5NDkwNTIxOTk3Mjk3MDA5NTU3NTA0MAZDZD',	'2026-04-18 13:14:29',	'2026-04-18 13:14:29'),
(43,	'2124250091644267',	'inbound',	'mola!! se tiene que ir perfeccionando pero mola',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MDk3NDQ0NTM4OTM0ODEwMzk5Nzg0NDY4NjM3Mjg2NAZDZD',	'2026-04-18 13:14:45',	'2026-04-18 13:14:45'),
(44,	'2124250091644267',	'outbound',	'¡Me alegra que te guste! 👍 Seguiremos puliéndolo para que sea aún mejor. 🚀',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MDk3NDQ5NDkwNTg1MDk4NzMzNjAyNTU0MTQ0MzU4NAZDZD',	'2026-04-18 13:14:47',	'2026-04-18 13:14:47'),
(45,	'2124250091644267',	'outbound',	'no si no lo voy a poner',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MDk3NDgwNDEwNDQzODIxMzQ0ODYwNjA1ODI4MzAwOAZDZD',	'2026-04-18 13:15:04',	'2026-04-18 13:15:04'),
(46,	'2124250091644267',	'outbound',	'era solo un experimento',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MDk3NDg5ODI3MTk0OTIwOTk4NzQxMDE0MzczOTkwNAZDZD',	'2026-04-18 13:15:09',	'2026-04-18 13:15:09'),
(47,	'2124250091644267',	'outbound',	'chatgpt en instagram',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MDk3NTA3NTgwNjQ3NjMzNDg4NDM3MDY4MTY5MjE2MAZDZD',	'2026-04-18 13:15:19',	'2026-04-18 13:15:19'),
(48,	'2124250091644267',	'inbound',	'ahh valee',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MTAzMTgzMDA5MTI5NjYwNjg5NDU1MzMzMjQ0OTI4MAZDZD',	'2026-04-18 14:06:36',	'2026-04-18 14:06:36'),
(49,	'2124250091644267',	'outbound',	'¡De nada! Si necesitas algo más, aquí estoy. 😊',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MTAzMTg3NTEzODg1NDM3NzQ0NzcxMDc5MzkyNDYwOAZDZD',	'2026-04-18 14:06:37',	'2026-04-18 14:06:37'),
(50,	'2124250091644267',	'inbound',	'pues mola',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MTAzMTkyMzgwMjY3NDk2MjcyMjc0MTMzNTA5NzM0NAZDZD',	'2026-04-18 14:06:41',	'2026-04-18 14:06:41'),
(51,	'2124250091644267',	'outbound',	'¡Qué bueno! 😎 Si tienes alguna idea o pregunta, avísame. 🚀',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3MTAzMTk2MDE2Mjk0MTUyNTk0NzE5NjI2ODA4NTI0OAZDZD',	'2026-04-18 14:06:42',	'2026-04-18 14:06:42'),
(52,	'1499029485211561',	'outbound',	'Hola mundo',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4ODE3ODM5MzgzMzEyNjozMjc3MTIxMjMxNjc2MTUwMDc0MzgwNDY3MjU3NDIyNjQzMgZDZD',	'2026-04-18 16:49:39',	'2026-04-18 16:49:39'),
(53,	'1271909941180053',	'outbound',	'Hola mundo',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4ODE5Njg1MzgzMTI4MDozMjc3MTI0MTg1MzAxMzA1Mjk2ODE2MTMxOTA3MjAzODkxMgZDZD',	'2026-04-18 17:16:20',	'2026-04-18 17:16:20'),
(54,	'26444258818518491',	'outbound',	'Hola mundo',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE0ODU5MDkxNzc4OTg1MTozMjc3MTU0MDA0OTg4MDI2NTMxNjkxMDIwMjg0ODU0MjcyMAZDZD',	'2026-04-18 21:45:46',	'2026-04-18 21:45:46'),
(55,	'916221654746303',	'outbound',	'Hola mundo',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4ODQyMTM1MzgwODgzMDozMjc3MTcwNjg4MDAzOTMxNzA1ODA2MjgyNDUzMDUwOTgyNAZDZD',	'2026-04-19 00:16:30',	'2026-04-19 00:16:30'),
(56,	'2186888728794914',	'outbound',	'Hola mundo',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4ODU0NTg2NzEyOTcxMjozMjc3MTk2MjQ5NDkwMDEzNjQ4MjY2MzM0NDQ4OTEwMzM2MAZDZD',	'2026-04-19 04:07:27',	'2026-04-19 04:07:27'),
(57,	'1585290139200072',	'outbound',	'Hola mundo',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4ODkwOTY2Mzc1OTk5OTozMjc3MjYyMjIxNDIzMDA0NzMwOTc5Mjg1MTM1MzY2NTUzNgZDZD',	'2026-04-19 14:03:30',	'2026-04-19 14:03:30'),
(58,	'2121906318654065',	'outbound',	'Hola mundo',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4ODk4OTQ1NzA4NTM1MzozMjc3Mjc0MTI4MDg5NzY0NDk3NjgxMjU5NTAxMTkxMTY4MAZDZD',	'2026-04-19 15:51:05',	'2026-04-19 15:51:05'),
(59,	'1349365540359993',	'outbound',	'Hola mundo',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4ODk5MDk1Mzc1MTg3MDozMjc3Mjc0MzY5MTI4NDgwOTIxNjY0NDM3NDM2Mjg0OTI4MAZDZD',	'2026-04-19 15:53:15',	'2026-04-19 15:53:15'),
(60,	'1491310312570554',	'outbound',	'Hola mundo',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDAyMDAxMzQzMzk5MjAyMDozMjc3Mjg2MTE1NDA5NDA2MzczNTcyMjQ2MDA2ODE4NDA2NAZDZD',	'2026-04-19 17:39:23',	'2026-04-19 17:39:23'),
(61,	'1491310312570554',	'inbound',	'Bienvenid@s al Chat de TodoPORTEROS.es🧤⚽️🥅

Este Chat es de uso exclusivo para clientes que tengan dudas o consultas sobre nuestros productos.


🔴 Importante:
Para todo lo relacionado con ser EMBAJADOR de TP, seguid las indicaciones del Post de Instagram.


Mucha suerte a tod@s',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDAyMDAxMzQzMzk5MjAyMDozMjc3Mjg2MTIyMDg3ODUwODQwNjIyNzkzMTA2MjMzNzUzNgZDZD',	'2026-04-19 17:39:27',	'2026-04-19 17:39:27'),
(62,	'1491310312570554',	'outbound',	'¡Hola! Bienvenidos al chat de TodoPORTEROS.es. Si tenéis alguna duda o consulta sobre nuestros productos, estamos aquí para ayudar. ⚽️🥅🧤',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDAyMDAxMzQzMzk5MjAyMDozMjc3Mjg2MTMwNjU5MDYwMzc2ODQ0NDU2MTY4MzEyMDEyOAZDZD',	'2026-04-19 17:39:31',	'2026-04-19 17:39:31'),
(63,	'1583122336091975',	'outbound',	'Hola mundo',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4OTE0Njg3NzA2OTYxMTozMjc3MzAwNTI4OTA5MjA0MjcxMjExODkyNjQxOTk1MTYxNgZDZD',	'2026-04-19 19:49:36',	'2026-04-19 19:49:36'),
(64,	'26460940703599138',	'outbound',	'Hola mundo',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDEyNzYyNzcwNjU1MTU1MjozMjc3MzA0NDY2ODM0MTYzNjA5OTk0NjcwMzczMjM0Mjc4NAZDZD',	'2026-04-19 20:25:11',	'2026-04-19 20:25:11'),
(65,	'731319353305758',	'outbound',	'Hola mundo',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4OTE2OTA0NzA2NzM5NDozMjc3MzA1MTYyMzM0MTE4NDQ4OTgxNzM3MTQ0ODQ0Mjg4MAZDZD',	'2026-04-19 20:31:28',	'2026-04-19 20:31:28'),
(66,	'1415298093952557',	'outbound',	'Hola mundo',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5ODgzMDMzNjEwMTY4ODozMjc3MzA5NzU2Mjk5ODk5MzcxMjU5MDY2NTA5Njg4ODMyMAZDZD',	'2026-04-19 21:12:59',	'2026-04-19 21:12:59'),
(67,	'1275356714574795',	'outbound',	'Hola mundo',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4OTMxNjQwMzcxOTMyNTozMjc3MzM0ODg1NzgwNTE5NzA2NjM4NDg1NTA4NjkyMzc3NgZDZD',	'2026-04-20 01:00:01',	'2026-04-20 01:00:01'),
(68,	'1495738162150540',	'outbound',	'Hola mundo',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIwODY4NDA1NTExOTczNTozMjc3MzYyMTg2MTE0ODQ0MDE4OTU1NjEyNzA2MzYwNTI0OAZDZD',	'2026-04-20 05:06:41',	'2026-04-20 05:06:41'),
(69,	'1294752116188337',	'outbound',	'Hola mundo',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4OTQ2NDYxMDM3MTE3MTozMjc3MzYzNTMyMjgzNTYzMzIxNjQwMzUwMjMxODc0NzY0OAZDZD',	'2026-04-20 05:18:51',	'2026-04-20 05:18:51'),
(70,	'1452349799361195',	'outbound',	'Hola mundo',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDEyNTkwNjUyMzM5MDE0NDozMjc3Mzc4MzcwNDI3OTA3ODU4MTYzODY1MjI1MjY1MTUyMAZDZD',	'2026-04-20 07:32:54',	'2026-04-20 07:32:54'),
(71,	'4441801509481215',	'outbound',	'Hola mundo',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDA3MTM5MjM4ODgzODg0NjozMjc3Mzk1NjM0NTI1NDM3ODMyNjc4NzEwNjU0MTY2NjMwNAZDZD',	'2026-04-20 10:08:53',	'2026-04-20 10:08:53'),
(72,	'1326558189317534',	'outbound',	'[Fase 1] HolaHola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDEzMzEzMjE5MjY3MTA4MDozMjc3NDA5MjAwNDU1MDQ2OTU4ODI3MDI0MDExNTk4MjMzNgZDZD',	'2026-04-20 12:11:27',	'2026-04-20 12:11:27'),
(73,	'1326558189317534',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDEzMzEzMjE5MjY3MTA4MDozMjc3NDA5MjM1NTc5MTQ5MjQwMTM3NjEwMjQ1OTYzNzc2MAZDZD',	'2026-04-20 12:11:47',	'2026-04-20 12:11:47'),
(74,	'1326558189317534',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDEzMzEzMjE5MjY3MTA4MDozMjc3NDA5MjQyMjEwMDE3NzA5NTQ3NjUzMDQwODA2Mjk3NgZDZD',	'2026-04-20 12:11:50',	'2026-04-20 12:11:50'),
(75,	'961738426412310',	'outbound',	'Muchísimas gracias Joset!! me alegra un montón que te guste :)',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE3ODY3NTU4ODExNjc0MDozMjc3NDExMTMwMjc5OTQ3NzkyMDQ2NzY1Nzg4MjA3NTEzNgZDZD',	'2026-04-20 12:28:54',	'2026-04-20 12:28:54'),
(76,	'1412300813412003',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4OTcyNjQzMDM0NDk4OTozMjc3NDExODY1ODM0MDkwOTU2ODU2MDcwNDEzODUxMDMzNgZDZD',	'2026-04-20 12:35:32',	'2026-04-20 12:35:32'),
(77,	'1412300813412003',	'inbound',	'Olá outcrease ! Agradecemos o contato e seu interesse. Esta é uma confirmação de que recebemos sua mensagem. Assim que possível, retornaremos o contato. Siga nosso perfil @agronews',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4OTcyNjQzMDM0NDk4OTozMjc3NDExODY5NzE5NzQwNzk4NjU4MzYwOTMwNTcyNjk3NgZDZD',	'2026-04-20 12:35:35',	'2026-04-20 12:35:35'),
(78,	'1412300813412003',	'outbound',	'Olá! ✅ Recebemos sua mensagem. Em breve retornamos o contato. Enquanto isso, siga nosso perfil @agronews para ficar por dentro das novidades. Até já!',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4OTcyNjQzMDM0NDk4OTozMjc3NDExODc2MTAxODE4MDMwNzQ2MjgzMDAyNzcwMjI3MgZDZD',	'2026-04-20 12:35:38',	'2026-04-20 12:35:38'),
(79,	'961738426412310',	'inbound',	'Feliz inicio de semana, hermano. Te comparto por aqui el mensaje que le dejé a Amulet Voice.',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE3ODY3NTU4ODExNjc0MDozMjc3NDEyMTI4OTA0NjE1MjkxMDE4ODA4MDc5OTk0MDYwOAZDZD',	'2026-04-20 12:37:55',	'2026-04-20 12:37:55'),
(80,	'961738426412310',	'outbound',	'¡Feliz semana! 🙌 Gracias por compartirlo, lo revisaré en cuanto pueda. ¿Hay algo específico que quieras que le pase o comentemos?',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE3ODY3NTU4ODExNjc0MDozMjc3NDEyMTMzNjY2NTYyOTUyNjQ3NDExODc4NTkyNTEyMAZDZD',	'2026-04-20 12:37:57',	'2026-04-20 12:37:57'),
(81,	'961738426412310',	'inbound',	'☺️',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE3ODY3NTU4ODExNjc0MDozMjc3NDEyMTc4Nzg3NzgyMjYxNjM1NzA2MzIxNTgwODUxMgZDZD',	'2026-04-20 12:38:22',	'2026-04-20 12:38:22'),
(82,	'961738426412310',	'outbound',	'😊 ¡Listo! Si necesitas algo más, aquí estoy.',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE3ODY3NTU4ODExNjc0MDozMjc3NDEyMTgyNDU3ODQzMTYwNzc0MTQ1OTM3NjExMTYxNgZDZD',	'2026-04-20 12:38:24',	'2026-04-20 12:38:24'),
(83,	'731319353305758',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4OTE2OTA0NzA2NzM5NDozMjc3NDEzMTIxMzg1OTEzODA0OTE0MzU5MzgxMzE0NzY0OAZDZD',	'2026-04-20 12:46:53',	'2026-04-20 12:46:53'),
(84,	'1653698519139762',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIyNTAxODgyMDE1MjM4NDozMjc3NDE0ODE1MTE4MzI3MDA0NDAxNDc4MDcxMTE3NDE0NAZDZD',	'2026-04-20 13:02:11',	'2026-04-20 13:02:11'),
(85,	'4431849600430028',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDEzOTYzNTQwODY4NzQyNTozMjc3NDE1OTM1MTM4MDc0OTk2Nzc2MzIyODc0MzE3MjA5NgZDZD',	'2026-04-20 13:12:18',	'2026-04-20 13:12:18'),
(86,	'4431849600430028',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDEzOTYzNTQwODY4NzQyNTozMjc3NDE1OTY4NjkxNDg4NjcxMDkzOTQ3MTc1MzI0ODc2OAZDZD',	'2026-04-20 13:12:37',	'2026-04-20 13:12:37'),
(87,	'4431849600430028',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDEzOTYzNTQwODY4NzQyNTozMjc3NDE1OTcyMTI1NzQyOTk2MDYzNzUwMjIyMDkyNjk3NgZDZD',	'2026-04-20 13:12:38',	'2026-04-20 13:12:38'),
(88,	'4431849600430028',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDEzOTYzNTQwODY4NzQyNTozMjc3NDE2MDY1NTQ1OTgwMDc5NTI1Mzk1MTEzNDk1NzU2OAZDZD',	'2026-04-20 13:13:29',	'2026-04-20 13:13:29'),
(89,	'1435605851194174',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4OTc1NzgzMDM0MTg0OTozMjc3NDE2Nzg0NjU4ODA3NzI5MjI2NDQ1MTcyMjk2OTA4OAZDZD',	'2026-04-20 13:19:59',	'2026-04-20 13:19:59'),
(90,	'1323163696531913',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE3NzU0MzQyODIyOTk1NjozMjc3NDE5MDIwNDE3MDU2MDY2ODE1NTEzNDQzNzQ5MDY4OAZDZD',	'2026-04-20 13:40:11',	'2026-04-20 13:40:11'),
(91,	'731319353305758',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4OTE2OTA0NzA2NzM5NDozMjc3NDE5MzAxMTY0ODI1OTI0MzUwNjM4MjY0MDUxMzAyNAZDZD',	'2026-04-20 13:42:43',	'2026-04-20 13:42:43'),
(92,	'1550224673779941',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MTUwMTk1NjgzNTMxMTozMjc3NDE5NDczMjY1NzA0MDk1NjYzMDA5MTAwNDExNjk5MgZDZD',	'2026-04-20 13:44:16',	'2026-04-20 13:44:16'),
(93,	'1300599672116994',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4MDA1MzA2Nzk4MjIxODozMjc3NDE5NTI2Mzk3ODg4NzIxMjg0NzQxMTg0MzAzOTIzMgZDZD',	'2026-04-20 13:44:45',	'2026-04-20 13:44:45'),
(94,	'1311014657532802',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDEyNDY4Mzc2MDE4MjU5MDozMjc3NDE5NzMzODQ5NjI1Nzc1NDMzNzcyOTE4MjY5NTQyNAZDZD',	'2026-04-20 13:46:38',	'2026-04-20 13:46:38'),
(95,	'1311014657532802',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDEyNDY4Mzc2MDE4MjU5MDozMjc3NDE5NzQxNzUyMjc1NTAwMjE1MjAyODEzOTk0NTk4NAZDZD',	'2026-04-20 13:46:42',	'2026-04-20 13:46:42'),
(96,	'1311014657532802',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDEyNDY4Mzc2MDE4MjU5MDozMjc3NDE5NzQ0MjY2Mzc4NTYwNjcyMjYyODYxODI4OTE1MgZDZD',	'2026-04-20 13:46:43',	'2026-04-20 13:46:43'),
(97,	'1311014657532802',	'inbound',	'Gracias!',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDEyNDY4Mzc2MDE4MjU5MDozMjc3NDE5NzY1MTE0NjUyNTk0NDU0NjU0NjE1OTcxNDMwNAZDZD',	'2026-04-20 13:46:55',	'2026-04-20 13:46:55'),
(98,	'1311014657532802',	'outbound',	'¡De nada! Si tienes alguna duda o necesitas ayuda, aquí estoy. 🚀',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDEyNDY4Mzc2MDE4MjU5MDozMjc3NDE5NzY4NzgwMjA2OTU0MDE1ODg2OTg4NTQxOTUyMAZDZD',	'2026-04-20 13:46:56',	'2026-04-20 13:46:56'),
(99,	'1311014657532802',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDEyNDY4Mzc2MDE4MjU5MDozMjc3NDE5ODAxNTkxNzcxOTAyNjg4NDMwMDc0NjI2MDQ4MAZDZD',	'2026-04-20 13:47:14',	'2026-04-20 13:47:14'),
(100,	'2124250091644267',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3NDE5ODM4MDE2ODc1MDgxOTgzMTU5MzM5NjMzODY4OAZDZD',	'2026-04-20 13:47:34',	'2026-04-20 13:47:34'),
(101,	'1644558656439539',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTk0Njk0NzE0Nzk2NTc3NjozMjc3NDIwMDk1NTQ3ODI1NTY4NzQxMjUyMzE2ODk1NjQxNgZDZD',	'2026-04-20 13:49:54',	'2026-04-20 13:49:54'),
(102,	'26163014456699106',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4OTc4MzYwMDMzOTI3MjozMjc3NDIwNzE2NTQxMzAxNzczMDE1OTIzMTYwNDA5NzAyNAZDZD',	'2026-04-20 13:55:30',	'2026-04-20 13:55:30'),
(103,	'1671990437379547',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4OTc4NTQ0NzAwNTc1NDozMjc3NDIwOTY2NzU2MjUxNDI0MDQ3OTE5NTE1MzAzOTM2MAZDZD',	'2026-04-20 13:57:46',	'2026-04-20 13:57:46'),
(104,	'1967388964153557',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDEyNzc3NDExNjU0MDIyMTozMjc3NDI0MDIzNzMwNTM1NDc0NjY2MzIyNDg4NDU5MjY0MAZDZD',	'2026-04-20 14:25:23',	'2026-04-20 14:25:23'),
(105,	'1967388964153557',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDEyNzc3NDExNjU0MDIyMTozMjc3NDI0Nzc2MjUwMzAwNDI3MzY3NzA2MTUzNjYxMjM1MgZDZD',	'2026-04-20 14:32:12',	'2026-04-20 14:32:12'),
(106,	'1967388964153557',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDEyNzc3NDExNjU0MDIyMTozMjc3NDI0Nzc5NDk0MTQ1NjE1MzM0MjcxODM3NjkzNTQyNAZDZD',	'2026-04-20 14:32:13',	'2026-04-20 14:32:13'),
(107,	'1435605851194174',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4OTc1NzgzMDM0MTg0OTozMjc3NDI2NTA4MDA3OTk0Mzc4MjE4NzQ4MTMxMDQyOTE4NAZDZD',	'2026-04-20 14:47:51',	'2026-04-20 14:47:51'),
(108,	'1435605851194174',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4OTc1NzgzMDM0MTg0OTozMjc3NDI2NTExMzE0NjQxNTA2Mzg0MjU3OTgzNTUxODk3NgZDZD',	'2026-04-20 14:47:52',	'2026-04-20 14:47:52'),
(109,	'2357210468111520',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4OTgyMzI4MDMzNTMwNDozMjc3NDI2OTQ5MTY2ODExNTYwMzQ3OTg0OTYxNzg1MDM2OAZDZD',	'2026-04-20 14:51:49',	'2026-04-20 14:51:49'),
(110,	'26163014456699106',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4OTc4MzYwMDMzOTI3MjozMjc3NDI3MzY1ODUwNjIxNTIyMDM2NzE5NDE3MTg5OTkwNAZDZD',	'2026-04-20 14:55:36',	'2026-04-20 14:55:36'),
(111,	'26163014456699106',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4OTc4MzYwMDMzOTI3MjozMjc3NDI3MzcwOTUzNzc2NzY0MTIyMzIxNDIxMDc0NDMyMAZDZD',	'2026-04-20 14:55:38',	'2026-04-20 14:55:38'),
(112,	'972929065242544',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIxNzMyMzc3NDI1NjQ5NTozMjc3NDI4MTY4MjQxMTI5NTYzMjIxMzU3OTQwOTY1Mzc2MAZDZD',	'2026-04-20 15:02:50',	'2026-04-20 15:02:50'),
(113,	'1602615097660826',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4OTg0NDM4MDMzMzE5NDozMjc3NDMwMTIwNDU1OTc5OTk4MTM3MzIzMDIyMjkzNDAxNgZDZD',	'2026-04-20 15:20:28',	'2026-04-20 15:20:28'),
(114,	'1602615097660826',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4OTg0NDM4MDMzMzE5NDozMjc3NDMwMTY2NjYzMzgwNDkxNjczNzgzMjgzNTM1MDUyOAZDZD',	'2026-04-20 15:20:54',	'2026-04-20 15:20:54'),
(115,	'1602615097660826',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4OTg0NDM4MDMzMzE5NDozMjc3NDMwMTY5OTk4MDQ2Mzc5NDEyODUwNTczOTkzNTc0NAZDZD',	'2026-04-20 15:20:55',	'2026-04-20 15:20:55'),
(116,	'985310847792008',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4OTg0NTkxMDMzMzA0MTozMjc3NDMwMzU0OTg3MDI0NTMzMDA2NzI3NDAzMDEyMDk2MAZDZD',	'2026-04-20 15:22:35',	'2026-04-20 15:22:35'),
(117,	'4135045710070575',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4OTg1MDMzNjk5OTI2NTozMjc3NDMxMDEzNTkzNjcwMTU3OTkyMjA1OTI1MjcyNzgwOAZDZD',	'2026-04-20 15:28:32',	'2026-04-20 15:28:32'),
(118,	'4135045710070575',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4OTg1MDMzNjk5OTI2NTozMjc3NDMxMTYwODM2MDUzNTkwOTkwMTMzODg4NzA2MTUwNAZDZD',	'2026-04-20 15:29:53',	'2026-04-20 15:29:53'),
(119,	'4135045710070575',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4OTg1MDMzNjk5OTI2NTozMjc3NDMxMTY0MDQ3NjA1OTA4NzgxMjYzNjMxNjc5NDg4MAZDZD',	'2026-04-20 15:29:54',	'2026-04-20 15:29:54'),
(120,	'985310847792008',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4OTg0NTkxMDMzMzA0MTozMjc3NDMzMTg3NDUxNTE0OTUxNzA1MDY4NDEwNDUwNzM5MgZDZD',	'2026-04-20 15:48:12',	'2026-04-20 15:48:12'),
(121,	'985310847792008',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4OTg0NTkxMDMzMzA0MTozMjc3NDMzMTkwNzE2NzA0ODY3MjM5MzIzNDE2NjU3OTIwMAZDZD',	'2026-04-20 15:48:12',	'2026-04-20 15:48:12'),
(122,	'1490313725836347',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4OTg3MTgwNjk5NzExODozMjc3NDM0Mjg1Mzc0NTUwMTY0ODc3MDA2NDI1MjQwMzcxMgZDZD',	'2026-04-20 15:58:06',	'2026-04-20 15:58:06'),
(123,	'1275601714524986',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4OTkyODU4Njk5MTQ0MDozMjc3NDQzMTk1MjU3MTU0MzA1NDM4MDYxNDkzNzQ3NzEyMAZDZD',	'2026-04-20 17:18:36',	'2026-04-20 17:18:36'),
(124,	'1303611215121271',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIyODgyNzQ4OTc3MjA2NTozMjc3NDQzMjE3MzQ0MTY3Nzg2NjA3MDExNzk5OTE4MTgyNAZDZD',	'2026-04-20 17:18:48',	'2026-04-20 17:18:48'),
(125,	'1303611215121271',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIyODgyNzQ4OTc3MjA2NTozMjc3NDQzMjQyOTUzNzAzMjYzMTM4NDY1MzU3MzM5MDMzNgZDZD',	'2026-04-20 17:19:03',	'2026-04-20 17:19:03'),
(126,	'1303611215121271',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIyODgyNzQ4OTc3MjA2NTozMjc3NDQzMjQ3Njk1MDA1MzI4Nzk5NzczNDI1NzY4ODU3NgZDZD',	'2026-04-20 17:19:04',	'2026-04-20 17:19:04'),
(127,	'1185485903664118',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4OTk2MDA0MzY1NDk2MTozMjc3NDQ4MjA4ODYyNTg2ODk2MTcxMDg1ODgxNTE0MzkzNgZDZD',	'2026-04-20 18:03:54',	'2026-04-20 18:03:54'),
(128,	'1274891218084277',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE1MDI3NDA1NzYyOTYxODozMjc3NDQ4MjYyODg5NTAxMzI4Mjk3NTgxODMxMjU4MTEyMAZDZD',	'2026-04-20 18:04:23',	'2026-04-20 18:04:23'),
(129,	'1248857179934226',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4OTk3NTM3Njk4Njc2MTozMjc3NDUwNjkyNjc1OTQ5Njk5NTk2Mjc1MDI3ODU2NTg4OAZDZD',	'2026-04-20 18:26:20',	'2026-04-20 18:26:20'),
(130,	'1365010178956962',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4OTk4MjczMDMxOTM1OTozMjc3NDUyMDA1NjA4NTA0Mjc3MjE3NDUyNDkyMDEwMjkxMgZDZD',	'2026-04-20 18:38:12',	'2026-04-20 18:38:12'),
(131,	'1604474077332132',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4OTk5NDM4Njk4NDg2MDozMjc3NDU0MTI1NzQ1ODc1NjQwNzA1MDk2ODQwNzk5ODQ2NAZDZD',	'2026-04-20 18:57:22',	'2026-04-20 18:57:22'),
(132,	'1604474077332132',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4OTk5NDM4Njk4NDg2MDozMjc3NDU0MzE4OTM1Mzc5Njk3NzA4MjU4MDM0MDgzNDMwNAZDZD',	'2026-04-20 18:59:07',	'2026-04-20 18:59:07'),
(133,	'1604474077332132',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4OTk5NDM4Njk4NDg2MDozMjc3NDU0MzIyMTM5MTI5MDQyNzU2MjA4NjM2NzIzMjAwMAZDZD',	'2026-04-20 18:59:08',	'2026-04-20 18:59:08'),
(134,	'841261688325984',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4OTk5ODEzNjk4NDQ4NTozMjc3NDU0NzU5MDMwMzU2NTQ3MDM2OTk4Njg0NTM0Mzc0NAZDZD',	'2026-04-20 19:03:05',	'2026-04-20 19:03:05'),
(135,	'1952155892841355',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDAxNTQyMzY0OTQyMzozMjc3NDU3OTc0MTYzNDI1MzI1ODcyMzE2NDc5NzUzNDIwOAZDZD',	'2026-04-20 19:32:08',	'2026-04-20 19:32:08'),
(136,	'1952155892841355',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDAxNTQyMzY0OTQyMzozMjc3NDU3OTkyOTk3NjgwMTUyMzM4Mjg0NjQ2NTUwNzMyOAZDZD',	'2026-04-20 19:32:19',	'2026-04-20 19:32:19'),
(137,	'1952155892841355',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDAxNTQyMzY0OTQyMzozMjc3NDU3OTk2MTc1NTE5MjAwNjYwMzAyODEyOTkwNjY4OAZDZD',	'2026-04-20 19:32:20',	'2026-04-20 19:32:20'),
(138,	'841261688325984',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4OTk5ODEzNjk4NDQ4NTozMjc3NDU4MzczMzg1NTYwMjYwMTA4NDQwOTcyMTM4OTA1NgZDZD',	'2026-04-20 19:35:45',	'2026-04-20 19:35:45'),
(139,	'841261688325984',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4OTk5ODEzNjk4NDQ4NTozMjc3NDU4Mzc3NTY5NjkxMzMzNzQ0MjAzNjMwNjkzNTgwOAZDZD',	'2026-04-20 19:35:46',	'2026-04-20 19:35:46'),
(140,	'4332236760354761',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDAzNDE3Njk4MDg4MTozMjc3NDYxNzI2NTc3MDc0MDM5ODkzMjc5ODMxMjgwODQ0OAZDZD',	'2026-04-20 20:06:02',	'2026-04-20 20:06:02'),
(141,	'4332236760354761',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDAzNDE3Njk4MDg4MTozMjc3NDYxNzQ2MjQ2MzE3MDQ3NTA2ODk2MTEwMDY2MDczNgZDZD',	'2026-04-20 20:06:13',	'2026-04-20 20:06:13'),
(142,	'4332236760354761',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDAzNDE3Njk4MDg4MTozMjc3NDYxNzQ5NjEyNzQ4MjI4NTQwODkxMjQ4NDA3MzQ3MgZDZD',	'2026-04-20 20:06:14',	'2026-04-20 20:06:14'),
(143,	'2337910950064402',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE0NDc5NTAyNDgzNTM0OTozMjc3NDYzMjYyNTQ0ODc0MzgzMjA0OTE2NzY4OTA1NjI1NgZDZD',	'2026-04-20 20:19:55',	'2026-04-20 20:19:55'),
(144,	'1619191255998784',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDA0NDc4MzY0NjQ4NzozMjc3NDYzODQxNDMzNTU1NzgyMTQ1MTMwNjQ2MzY1Nzk4NAZDZD',	'2026-04-20 20:25:08',	'2026-04-20 20:25:08'),
(145,	'1472448387597720',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDA1OTQ5Njk3ODM0OTozMjc3NDY2NDk5MzI0MjU4MzkzMjY1MDQxNTY5MzIzNDE3NgZDZD',	'2026-04-20 20:49:09',	'2026-04-20 20:49:09'),
(146,	'1472448387597720',	'inbound',	'gracias!',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDA1OTQ5Njk3ODM0OTozMjc3NDY2Njk2MTYwOTIzNTYxMzEzNTM5MzQxMjYxMjA5NgZDZD',	'2026-04-20 20:50:57',	'2026-04-20 20:50:57'),
(147,	'4514873552089558',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIyMjI2Nzk2NzA5NjA2MTozMjc3NDY4NTg4MjYxMTM4ODcxODczNjc3MDg2NzM5NjYwOAZDZD',	'2026-04-20 21:08:02',	'2026-04-20 21:08:02'),
(148,	'1327662249213339',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDA3Mzk1MzY0MzU3MDozMjc3NDY5NTE2Mzc4MjEyOTE2NDMyMDgwMDQ5NzQ2NzM5MgZDZD',	'2026-04-20 21:16:25',	'2026-04-20 21:16:25'),
(149,	'3049791801872573',	'inbound',	'Buenas crack, estoy viendo tus vídeos y tal sobre mailerfind, muy top. Ahora bien, lo que quiero preguntar es. Cómo lo oriento todo a empresas, es decir, para captar empresas que estén dispuestas a implementar IA( o el sistema que yo vendo) y que pues me puedan pagar bien',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDA4MTQzMDMwOTQ4OTozMjc3NDcxMTkyODc1NzMxNjcwNzU5OTU5MjYyMTg2NzAwOAZDZD',	'2026-04-20 21:31:36',	'2026-04-20 21:31:36'),
(150,	'34909932248620036',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDA5NDI1MDMwODIwNzozMjc3NDc0MTcyOTIyMTM5OTgzMjI1NzQwOTgyMDEzMTMyOAZDZD',	'2026-04-20 21:58:29',	'2026-04-20 21:58:29'),
(151,	'34909932248620036',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDA5NDI1MDMwODIwNzozMjc3NDc0MTk3MTU3MTcxNjY1MzM2OTQ4NDI5NDIyNTkyMAZDZD',	'2026-04-20 21:58:43',	'2026-04-20 21:58:43'),
(152,	'34909932248620036',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDA5NDI1MDMwODIwNzozMjc3NDc0MjAxMTQyOTI2NDUzMjA0MDM4NTY5ODk4ODAzMgZDZD',	'2026-04-20 21:58:44',	'2026-04-20 21:58:44'),
(153,	'1119349400378868',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDEwNjIyMDMwNzAxMDozMjc3NDc3MTI3NjM4MTAyODMzNjIzMjU3ODA1NTkyOTg1NgZDZD',	'2026-04-20 22:25:11',	'2026-04-20 22:25:11'),
(154,	'1644241373366893',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDEwNzA0Njk3MzU5NDozMjc3NDc3MzQ0MTUzMzgzNzk5OTQ5MjIzNjc5NDkyMDk2MAZDZD',	'2026-04-20 22:27:08',	'2026-04-20 22:27:08'),
(155,	'1323428729666215',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDEwOTMyNjk3MzM2NjozMjc3NDc3ODk1MzE3NjQzNzE4NDQ2NTE2NTgzOTQ5OTI2NAZDZD',	'2026-04-20 22:32:07',	'2026-04-20 22:32:07'),
(156,	'1491338965668259',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MTI3MDI1MzUyNjU2NTozMjc3NDc4Mjk4MTY5MzYxODYxMzAwMTM5ODIzMjU0NzMyOAZDZD',	'2026-04-20 22:35:45',	'2026-04-20 22:35:45'),
(157,	'1459830149208984',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDEyMDk5MzcxNzIyNDc2MTozMjc3NDgxNDEwMzAyMzY3NzA1Mzg1MTE3NzY5Mzc0MTA1NgZDZD',	'2026-04-20 23:03:52',	'2026-04-20 23:03:52'),
(158,	'891218957296715',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDEzMzY2MzYzNzU5OTozMjc3NDgzMDAyMDMyNjM1MTczNjI2MTc2OTY1NzU4MTU2OAZDZD',	'2026-04-20 23:18:15',	'2026-04-20 23:18:15'),
(159,	'1700360387990632',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4NTI0MTU1NzQ2MDk0MDozMjc3NDgzMTcwMjU5NTMxMDY4NzYyODc4NTc2Nzk0MDA5NgZDZD',	'2026-04-20 23:19:46',	'2026-04-20 23:19:46'),
(160,	'1743595040382759',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDEzNjI1MDMwNDAwNzozMjc3NDgzNjUwMTU3NTk5MTYzNTgyNTIyNjY0NjgxNDcyMAZDZD',	'2026-04-20 23:24:07',	'2026-04-20 23:24:07'),
(161,	'2198926097311445',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE0NDM2Nzk4MTU0NzUwMTozMjc3NDg1NDExMzM1NjYzOTcyODI3NTY0ODg3NzE2NjU5MgZDZD',	'2026-04-20 23:40:01',	'2026-04-20 23:40:01'),
(162,	'851595184636339',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDE0NDk5Njk2OTc5OTozMjc3NDg1NzAxMDM4OTA5MzM3MDU4MjAzODEwNzY1MjA5NgZDZD',	'2026-04-20 23:42:38',	'2026-04-20 23:42:38'),
(163,	'1435961061338713',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE0MDg3Nzk4NTIyOTgzNDozMjc3NDg2OTIwOTc5MjYzMjM2MDI5Njg1NDQ4MjU4MzU1MgZDZD',	'2026-04-20 23:53:40',	'2026-04-20 23:53:40'),
(164,	'1987065675530622',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDE1Mjg2MzYzNTY3OTozMjc3NDg3NDM0OTY3NTI0OTY2MjkzNDIwNzA4NjcyMzA3MgZDZD',	'2026-04-20 23:58:18',	'2026-04-20 23:58:18'),
(165,	'1254923056791321',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDE2MTU1MDMwMTQ3NzozMjc3NDg5MjgxMjIwMTYwMTI4NTQ0NDY5MzM1Nzc1NjQxNgZDZD',	'2026-04-21 00:14:59',	'2026-04-21 00:14:59'),
(166,	'1160479332830447',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIzOTIwNDE0MjA2OTkxNzozMjc3NDg5NzY4ODY1MzA1NDg3MzI1NTA2NDQ0ODc5NDYyNAZDZD',	'2026-04-21 00:19:24',	'2026-04-21 00:19:24'),
(167,	'961354383149031',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDE3MTE5MzYzMzg0NjozMjc3NDkxNTgzOTQyOTA0NDI2ODQ0ODU4MDUwODg0NDAzMgZDZD',	'2026-04-21 00:35:48',	'2026-04-21 00:35:48'),
(168,	'1862083831169211',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDE3MjI1MDMwMDQwNzozMjc3NDkxODE0NDc0MDE2MDA2MzUyMTE5MTI5NzU0ODI4OAZDZD',	'2026-04-21 00:37:53',	'2026-04-21 00:37:53'),
(169,	'2337209663471435',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE3NzA0NDA4NDk1MTU4NjozMjc3NDkyMTM1MDg0MDYzNDg3NzM4NjQ0NDgzODUzNTE2OAZDZD',	'2026-04-21 00:40:46',	'2026-04-21 00:40:46'),
(170,	'1516680173386172',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDE3NjA3MzYzMzM1ODozMjc3NDkyNjk3MjE3NTUyNDg3MTMzMjEzNjYwODU5NTk2OAZDZD',	'2026-04-21 00:45:51',	'2026-04-21 00:45:51'),
(171,	'26672209452377290',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDEzODQ3OTY0NTQ2OTQ2NzozMjc3NDkzNDc0MTQ1ODQ0NDM5MzA3ODU3ODQ4MzI5ODMwNAZDZD',	'2026-04-21 00:52:52',	'2026-04-21 00:52:52'),
(172,	'1254923056791321',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDE2MTU1MDMwMTQ3NzozMjc3NDk0NzU0MTMwMTczMjA5NDYwODIyMzg0MjA3NDYyNAZDZD',	'2026-04-21 01:04:27',	'2026-04-21 01:04:27'),
(173,	'1254923056791321',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDE2MTU1MDMwMTQ3NzozMjc3NDk0NzYxOTYyNzQ3NDQyODU1MDQ0NDM1MjUzNjU3NgZDZD',	'2026-04-21 01:04:30',	'2026-04-21 01:04:30'),
(174,	'26524947393863803',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDIwODExMDI5NjgyMTozMjc3NDk5MTc3ODQ0OTQxMjgxNTc5MDc3OTQyMTE2MzUyMAZDZD',	'2026-04-21 01:44:24',	'2026-04-21 01:44:24'),
(175,	'26524947393863803',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDIwODExMDI5NjgyMTozMjc3NDk5MzE1NDg4MjIzODYwNDA1NjkxODM3MzY5NTQ4OAZDZD',	'2026-04-21 01:45:39',	'2026-04-21 01:45:39'),
(176,	'26524947393863803',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDIwODExMDI5NjgyMTozMjc3NDk5MzIyNDI5NDcxNzExNTc2NzQ5NDM0ODM3NDAxNgZDZD',	'2026-04-21 01:45:43',	'2026-04-21 01:45:43'),
(177,	'26308137098814840',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDEzNDIxMzEwOTIyNTI2MzozMjc3NTAzODE0ODgwNzY2ODczNjE1MDEyMzgzNzM5MDg0OAZDZD',	'2026-04-21 02:26:18',	'2026-04-21 02:26:18'),
(178,	'1642412797070751',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDI2Mjg5Njk1ODAwOTozMjc3NTA5NjgxNTQ3Njc1ODg1OTU2NjcyNjE1ODIyMTMxMgZDZD',	'2026-04-21 03:19:18',	'2026-04-21 03:19:18'),
(179,	'1316689190327415',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTY1OTU1ODA1MzQ2MDk1MzozMjc3NTA5NzMwNzAwMDIzNDM5MjEwMTYwNTgzMzk2NTU2OAZDZD',	'2026-04-21 03:19:45',	'2026-04-21 03:19:45'),
(180,	'1316689190327415',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTY1OTU1ODA1MzQ2MDk1MzozMjc3NTA5NzU5OTU5NTczNzM4MDk1MTUzNTg3MTA2NjExMgZDZD',	'2026-04-21 03:20:02',	'2026-04-21 03:20:02'),
(181,	'1316689190327415',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTY1OTU1ODA1MzQ2MDk1MzozMjc3NTA5NzYzNjY2ODY1NzAwNzk3NTYxMTkxMTYzNDk0NAZDZD',	'2026-04-21 03:20:03',	'2026-04-21 03:20:03'),
(182,	'1261001356206431',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDI3MjEwNjk1NzA4ODozMjc3NTExNDQyOTQ2MDYxMjI3NzIwNDcyMjM5NTM4MTc2MAZDZD',	'2026-04-21 03:35:13',	'2026-04-21 03:35:13'),
(183,	'1491338965668259',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MTI3MDI1MzUyNjU2NTozMjc3NTEyMTA4MDczNjUxMTc0MTgwNzU4MzM4NTYxNjM4NAZDZD',	'2026-04-21 03:41:15',	'2026-04-21 03:41:15'),
(184,	'1491338965668259',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MTI3MDI1MzUyNjU2NTozMjc3NTEyMTEyMTg4OTY4NTEzNzIzOTU0ODg1NzY3OTg3MgZDZD',	'2026-04-21 03:41:16',	'2026-04-21 03:41:16'),
(185,	'811151328731252',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDI4NzUyMzYyMjIxMzozMjc3NTE0NDEwMDU2NzA1MDE1ODkyNjg5ODU2Mjg1OTAwOAZDZD',	'2026-04-21 04:02:02',	'2026-04-21 04:02:02'),
(186,	'1490313725836347',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4OTg3MTgwNjk5NzExODozMjc3NTE1Nzg4NTgwODc4NzYyNjMyMjQyODM2NTM3MzQ0MAZDZD',	'2026-04-21 04:14:30',	'2026-04-21 04:14:30'),
(187,	'1490313725836347',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4OTg3MTgwNjk5NzExODozMjc3NTE1NzkyMTY3NzE1MzMxMjA3NzM0NDM5NDk2OTA4OAZDZD',	'2026-04-21 04:14:31',	'2026-04-21 04:14:31'),
(188,	'1481510246721086',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDI5ODg4MDI4Nzc0NDozMjc3NTE2NjEwNTk1NzEzODM0Mjg1NDIyMjUxODY4MTYwMAZDZD',	'2026-04-21 04:21:55',	'2026-04-21 04:21:55'),
(189,	'1481510246721086',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDI5ODg4MDI4Nzc0NDozMjc3NTE2NjQwMDU0ODE3MzIxMjEwOTkwNDQzMDQ5Nzc5MgZDZD',	'2026-04-21 04:22:11',	'2026-04-21 04:22:11'),
(190,	'1481510246721086',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDI5ODg4MDI4Nzc0NDozMjc3NTE2NjQzMTgzMDQzODUxMzQ2NzY2NzcwNDE4NDgzMgZDZD',	'2026-04-21 04:22:12',	'2026-04-21 04:22:12'),
(191,	'2028288748087680',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDI4Mzc0MzIxMDk0ODc5NTozMjc3NTE4MDkwNTYzNzQ0NDQ3NTU0NjIyNTE2ODM1MTIzMgZDZD',	'2026-04-21 04:35:17',	'2026-04-21 04:35:17'),
(192,	'2028288748087680',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDI4Mzc0MzIxMDk0ODc5NTozMjc3NTE4MjEyNjg5NTg3MTczNDE0MjA2ODAyNjUwNzI2NAZDZD',	'2026-04-21 04:36:24',	'2026-04-21 04:36:24'),
(193,	'2028288748087680',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDI4Mzc0MzIxMDk0ODc5NTozMjc3NTE4MjE2MTE1NjY3NzQ2MDg0OTQ5MTQ3MDk3NDk3NgZDZD',	'2026-04-21 04:36:25',	'2026-04-21 04:36:25'),
(194,	'1913946072596003',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDMyMzQyNjk1MTk1NjozMjc3NTIxMjUxNTU1Nzg1MzkwNzQ5MDY5NzA1MDU4NzEzNgZDZD',	'2026-04-21 05:03:51',	'2026-04-21 05:03:51'),
(195,	'937409722424959',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE1NzMyMTAwMDI1Nzk1MzozMjc3NTIzNDc5MTM3MDI1NTc4OTQ4NDI1OTE5NjAxMDQ5NgZDZD',	'2026-04-21 05:23:58',	'2026-04-21 05:23:58'),
(196,	'937409722424959',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE1NzMyMTAwMDI1Nzk1MzozMjc3NTIzNTA0MjkyMDI0MDU4MTMxNjM5MjcwNDI3ODUyOAZDZD',	'2026-04-21 05:24:12',	'2026-04-21 05:24:12'),
(197,	'937409722424959',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE1NzMyMTAwMDI1Nzk1MzozMjc3NTIzNTA3NTgxOTkzNDg0OTgwMTA4MzE3MzIwODA2NAZDZD',	'2026-04-21 05:24:13',	'2026-04-21 05:24:13'),
(198,	'804902252303499',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDM0NDAyMzYxNjU2MzozMjc3NTI1MzIzNjg3NTIwNjM1OTM3MjU4MzQ4NTMwODkyOAZDZD',	'2026-04-21 05:40:38',	'2026-04-21 05:40:38'),
(199,	'26927479393524470',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTk2Nzc0NTc2MjUzMzcxMTozMjc3NTMwNzY3NTY4OTE4MjA3MDI3Mzg4MjY5OTMzMzYzMgZDZD',	'2026-04-21 06:29:49',	'2026-04-21 06:29:49'),
(200,	'2192110201613939',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDI0NTAxMzQzMTQ4NDAwODozMjc3NTMxNDU5NjgyMjY0ODE2MzEyNjM2Mzk1NjQ0NTE4NAZDZD',	'2026-04-21 06:36:04',	'2026-04-21 06:36:04'),
(201,	'2192110201613939',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDI0NTAxMzQzMTQ4NDAwODozMjc3NTMxNDY5MjY2NTg0Mjk0NDU3Njg3MDAwMTE0NzkwNAZDZD',	'2026-04-21 06:36:10',	'2026-04-21 06:36:10'),
(202,	'2192110201613939',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDI0NTAxMzQzMTQ4NDAwODozMjc3NTMxNDcyNjAzODI3MTkyMzQzODUxNTE0OTM0MDY3MgZDZD',	'2026-04-21 06:36:11',	'2026-04-21 06:36:11'),
(242,	'1847407949271625',	'inbound',	'Holaa! Soy Carlos de @mentor.millonario',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDc4NTc1MDIzOTA1NzozMjc3NjAwODExMDUwMzIxNTkzODI5Njg0MTU4NjYwNjA4MAZDZD',	'2026-04-21 17:02:42',	'2026-04-21 17:02:42'),
(203,	'4281623722111526',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDM4ODc1MzYxMjA5MDozMjc3NTM0Mjg5MDY4NDE2MDc5NTQ4MTQxMTg3MTA0NzY4MAZDZD',	'2026-04-21 07:01:38',	'2026-04-21 07:01:38'),
(204,	'2330579507431913',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDM5NjQyNjk0NDY1NjozMjc3NTM1NzE3ODY5Nzk5NTQxNzM3NTA5NTExOTY3NTM5MgZDZD',	'2026-04-21 07:14:33',	'2026-04-21 07:14:33'),
(205,	'909966855383474',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDQxMDc2MzYwOTg4OTozMjc3NTM4NDI3NTU0NjIwODM3NjI3NzA0ODg2MTEzMDc1MgZDZD',	'2026-04-21 07:39:02',	'2026-04-21 07:39:02'),
(206,	'1311014657532802',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDEyNDY4Mzc2MDE4MjU5MDozMjc3NTM4NDg0MTIyMzY5NTA3MDQ4NDczMzk0OTM3ODU2MAZDZD',	'2026-04-21 07:39:33',	'2026-04-21 07:39:33'),
(207,	'1311014657532802',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDEyNDY4Mzc2MDE4MjU5MDozMjc3NTM4NDg2ODE4MTM2MTAzMTQzNDI1MTA3MDg2NTQwOAZDZD',	'2026-04-21 07:39:34',	'2026-04-21 07:39:34'),
(208,	'1419092145915032',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDQzNzQ0Njk0MDU1NDozMjc3NTQzMjYwOTgyMTQ0NzcxMTg5MzM3NDA4NDU3OTMyOAZDZD',	'2026-04-21 08:22:42',	'2026-04-21 08:22:42'),
(209,	'935565589307106',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE0NDYyMjM3MTUyODczNDozMjc3NTQ0NTk1NDMyMTgwNjc0NzUwMTI2OTk4MzY5MDc1MgZDZD',	'2026-04-21 08:34:45',	'2026-04-21 08:34:45'),
(210,	'969669795548377',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDQ1NjE5MzYwNTM0NjozMjc3NTQ2Nzc4ODU2MDkxODkzMzQ3MTA0NDg2NjkzMjczNgZDZD',	'2026-04-21 08:54:29',	'2026-04-21 08:54:29'),
(211,	'820580497717647',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIwMjA5NzIzNTc3NzI5NTozMjc3NTQ4NjAxNzcwNDQ4Nzg3ODE2NTk1NDcwMDUwOTE4NAZDZD',	'2026-04-21 09:10:57',	'2026-04-21 09:10:57'),
(212,	'820580497717647',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIwMjA5NzIzNTc3NzI5NTozMjc3NTQ4NjE5MTgxODYxOTcxNjkxNTY5MDE3NzgyMjcyMAZDZD',	'2026-04-21 09:11:07',	'2026-04-21 09:11:07'),
(213,	'820580497717647',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIwMjA5NzIzNTc3NzI5NTozMjc3NTQ4NjIyNTA0MDYxNTQ5Nzg1NjIzMzkzMjU4NzAwOAZDZD',	'2026-04-21 09:11:08',	'2026-04-21 09:11:08'),
(214,	'2079601662620676',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDUwODEzMzYwMDE1MjozMjc3NTU2NDU5NDg5NTg2NjAyODY0NzI2MDAwNDI4NjQ2NAZDZD',	'2026-04-21 10:21:57',	'2026-04-21 10:21:57'),
(215,	'2079601662620676',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDUwODEzMzYwMDE1MjozMjc3NTU2NDc0MTU2NTExNjUwMTk3MjY2MTY4MjgzMTM2MAZDZD',	'2026-04-21 10:22:05',	'2026-04-21 10:22:05'),
(216,	'2079601662620676',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDUwODEzMzYwMDE1MjozMjc3NTU2NDc3ODI0Njg3MjkyMDkxMzcyNjY4MTM4MjkxMgZDZD',	'2026-04-21 10:22:07',	'2026-04-21 10:22:07'),
(217,	'1680263373219746',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDA0MTE0NzE3NTE5NDU0OTozMjc3NTYxNDg0MzM4MjcwOTY4MzYxMTY3MzA4MDg4OTM0NAZDZD',	'2026-04-21 11:07:21',	'2026-04-21 11:07:21'),
(218,	'1680263373219746',	'inbound',	'Escribeme Gratis a https://wa.me/50767226611. Y te ayudaremos enseguida.',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDA0MTE0NzE3NTE5NDU0OTozMjc3NTYxNDkyOTczMTkzNzEzOTM5MDE1NzkwNDkzNjk2MAZDZD',	'2026-04-21 11:07:26',	'2026-04-21 11:07:26'),
(219,	'1680263373219746',	'inbound',	'?',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDA0MTE0NzE3NTE5NDU0OTozMjc3NTYyMjM3NzE3ODI1NzQ5NjE3MzAxNTc3NDI2NTM0NAZDZD',	'2026-04-21 11:14:10',	'2026-04-21 11:14:10'),
(220,	'1680263373219746',	'inbound',	'Que botón?',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDA0MTE0NzE3NTE5NDU0OTozMjc3NTYyMjc0NDY5MTI0NTQ5MDQxODQ0MjE0NjE1MjQ0OAZDZD',	'2026-04-21 11:14:30',	'2026-04-21 11:14:30'),
(337,	'1889273125048182',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE1ODkxNjMyMzQzMTMxNDozMjc4MDcwOTUwNjEwNzE2OTI2Nzc1Nzg1MDU1NDI2OTY5NgZDZD',	'2026-04-24 15:50:23',	'2026-04-24 15:50:23'),
(221,	'912737488186409',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTk4Mzk2ODU0NzU3Njk1NjozMjc3NTY1MTcyMjQ5OTcxODIxNzkwNjY2ODA4OTM3Njc2OAZDZD',	'2026-04-21 11:40:40',	'2026-04-21 11:40:40'),
(222,	'1680263373219746',	'outbound',	'escribe "Obtener enlace"',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDA0MTE0NzE3NTE5NDU0OTozMjc3NTY2NzA2NDAwNTUwMjAyMjYxODQzMTM5Njc3Mzg4OAZDZD',	'2026-04-21 11:54:32',	'2026-04-21 11:54:32'),
(223,	'1680263373219746',	'inbound',	'Hola outcrease . Gracias por contactarte con Fumigadora Multiservicios J&4, para una respuesta mas rápida, te invitamos a escribirnos por Whastapp haciendo clip al siguiente enlace wa.link/md7m05, sera un gusto poder atenderle.

Estaremos enviandole toda la informacion de nuestros servicios.',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDA0MTE0NzE3NTE5NDU0OTozMjc3NTY2NzA3ODg3NTg4MzU4OTAzNzU0MzY5MzIyMTg4OAZDZD',	'2026-04-21 11:54:33',	'2026-04-21 11:54:33'),
(224,	'1680263373219746',	'outbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDA0MTE0NzE3NTE5NDU0OTozMjc3NTY2NzQ3NTYwMzE0NjE5MzUxMzQ1MDM0NTMzMjczNgZDZD',	'2026-04-21 11:54:54',	'2026-04-21 11:54:54'),
(225,	'1680263373219746',	'outbound',	'escribe esto, es porque tu ia se respondio automatico',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDA0MTE0NzE3NTE5NDU0OTozMjc3NTY2NzcwMzQ2MDQyODA0NDk3ODIxNTExMDgzNjIyNAZDZD',	'2026-04-21 11:55:07',	'2026-04-21 11:55:07'),
(226,	'2447380512349925',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDU3NDUxMzU5MzUxNDozMjc3NTY4MDkxNzg5NjM1NDgzODQ2NjI4ODUwODk5MzUzNgZDZD',	'2026-04-21 12:07:03',	'2026-04-21 12:07:03'),
(227,	'2447380512349925',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDU3NDUxMzU5MzUxNDozMjc3NTY4MTI2NDIzNjM3Mjg5OTA5MjcwMjM0MTEwMzYxNgZDZD',	'2026-04-21 12:07:22',	'2026-04-21 12:07:22'),
(228,	'2447380512349925',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDU3NDUxMzU5MzUxNDozMjc3NTY4MTI5NzE2OTczMjQ3NTUxMTkxMjc0MTczMjM1MgZDZD',	'2026-04-21 12:07:23',	'2026-04-21 12:07:23'),
(229,	'1680263373219746',	'inbound',	'Obtener acceso',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDA0MTE0NzE3NTE5NDU0OTozMjc3NTcyMTc3OTMwNDg2NzI3MzczMjgyNDIyNTU0NjI0MAZDZD',	'2026-04-21 12:43:58',	'2026-04-21 12:43:58'),
(230,	'1680263373219746',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDA0MTE0NzE3NTE5NDU0OTozMjc3NTcyMTgwNDM2MjM3MTAyMTEzNzY2Nzg1NDE3MjE2MAZDZD',	'2026-04-21 12:43:59',	'2026-04-21 12:43:59'),
(231,	'1644241373366893',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDEwNzA0Njk3MzU5NDozMjc3NTc1MjI3MDUzMDc0NjQ5NjkwNjU2MDIzNDU4NjExMgZDZD',	'2026-04-21 13:11:31',	'2026-04-21 13:11:31'),
(232,	'1644241373366893',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDEwNzA0Njk3MzU5NDozMjc3NTc1MjI5OTcxMzc3MjMyMjY3NjE3NjUzNDM3MjM1MgZDZD',	'2026-04-21 13:11:32',	'2026-04-21 13:11:32'),
(233,	'1940626496562549',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDYyMDQ1MDI1NTU4NzozMjc3NTc1Mjc5ODY3MzAzODE1NzYwMzAwNzkxODc2ODEyOAZDZD',	'2026-04-21 13:11:59',	'2026-04-21 13:11:59'),
(234,	'1940626496562549',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDYyMDQ1MDI1NTU4NzozMjc3NTc1MjkyOTU0MjI0NjUwMzQyNjU1NzAyODA3MzQ3MgZDZD',	'2026-04-21 13:12:07',	'2026-04-21 13:12:07'),
(235,	'1940626496562549',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDYyMDQ1MDI1NTU4NzozMjc3NTc1Mjk2NDQ0MTU2NzgyOTUwMTM2Mjg5MjE3NzQwOAZDZD',	'2026-04-21 13:12:08',	'2026-04-21 13:12:08'),
(236,	'1632478608042309',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDI4MjA0NzQzNDQ1MTcyMTozMjc3NTc3MTAzNDY2ODY2ODYzNTIyMTQwNDQwOTY1OTM5MgZDZD',	'2026-04-21 13:28:28',	'2026-04-21 13:28:28'),
(237,	'1632478608042309',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDI4MjA0NzQzNDQ1MTcyMTozMjc3NTc3MzU2NjAxMDM3NzQ0OTg1OTY5MTYxNTA5MjczNgZDZD',	'2026-04-21 13:30:46',	'2026-04-21 13:30:46'),
(238,	'1632478608042309',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDI4MjA0NzQzNDQ1MTcyMTozMjc3NTc3MzYwMjkwNzc3NjMwNzAyMjQyMTI3MjAzNTMyOAZDZD',	'2026-04-21 13:30:47',	'2026-04-21 13:30:47'),
(239,	'1437400525066531',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDY2ODIxMzU4NDE0NDozMjc3NTgyNDE4MzExMzYxOTU0MjU4MjU0MTYwMzA0NTM3NgZDZD',	'2026-04-21 14:16:29',	'2026-04-21 14:16:29'),
(240,	'2004281416850343',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE2MDUyNjExOTkyOTQ5NjozMjc3NTg4OTM2NjExODc3NjIxNjc3NzA0Mjc1OTI1NDAxNgZDZD',	'2026-04-21 15:15:23',	'2026-04-21 15:15:23'),
(241,	'26291129823911405',	'inbound',	'Hola! Y como recomiendas contactar con bases tan grandes de contactos de manera eficiente y funcional?',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE0MDM1MDcwNTI4MjU2MjozMjc3NTk4NDQ4ODM1NTM2Mzg1NzMwODMxODEzMzM4NzI2NAZDZD',	'2026-04-21 16:41:21',	'2026-04-21 16:41:21'),
(434,	'1621503702496640',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5OTE0ODQ0Mjc0MDg2MTozMjc4Nzk5MzYwOTU0OTIwMTA1MDk5NzE4OTYyODY1NzY2NAZDZD',	'2026-04-29 05:31:36',	'2026-04-29 05:31:36'),
(243,	'1847407949271625',	'inbound',	'Trabajo con varias comunidades grandes de Instagram que actualmente están en venta tienen entre 100k a 900k de seguidores crecidas 100% de manera orgánica. Son audiencias reales, activas y bien segmentadas, listas para alguien que quiera aprovecharlas para crecer, monetizar o sumar alcance sin empezar desde cero.',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDc4NTc1MDIzOTA1NzozMjc3NjAwODIwMzQwMjAzMzY2NDQyMjE5NzU1MDEyMDk2MAZDZD',	'2026-04-21 17:02:48',	'2026-04-21 17:02:48'),
(244,	'1847407949271625',	'inbound',	'Si te interesa saber más info me dices, gracias por tu tiempo.',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDc4NTc1MDIzOTA1NzozMjc3NjAwODMwMjUzNzQwMDQxMzk2MzU3MzU2MjE3OTU4NAZDZD',	'2026-04-21 17:02:52',	'2026-04-21 17:02:52'),
(245,	'1767132208005807',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE0MjYxNDE5ODM4OTU0NjozMjc3NjAzNTc5MjA5MDc2NjM0NjI1Mzg3NzAzMDk0NDc2OAZDZD',	'2026-04-21 17:27:40',	'2026-04-21 17:27:40'),
(246,	'945640054880613',	'inbound',	'Muy interesante lo que publiques. Me gusta',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDg0NjgyMDIzMjk1MDozMjc3NjA5NTYzOTYwMzgyODY0NjAxMDEyOTQ0MTg4MjExMgZDZD',	'2026-04-21 18:21:47',	'2026-04-21 18:21:47'),
(247,	'986876053780396',	'inbound',	'Hola amigo vi que utilizaste en un video mailerfind, yo tengo una app que es lo mismo pero mucho más barata, si quieres te la paso y la pruebas, y si te interesa también te puedo dar un link de afiliado y podemos fijar una comisión, 30/40%',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDg0OTM4MDIzMjY5NDozMjc3NjEwMDIyNTk0Mzk4MzgyMjYzMjk2MjEwMjM5NDg4MAZDZD',	'2026-04-21 18:25:56',	'2026-04-21 18:25:56'),
(248,	'1478798540543750',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDg4NjQxMzU2MjMyNDozMjc3NjE2NjEzNTE1MTk0NjU2MTE0MjY2ODkxNjY4Njg0OAZDZD',	'2026-04-21 19:25:26',	'2026-04-21 19:25:26'),
(249,	'1478798540543750',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDg4NjQxMzU2MjMyNDozMjc3NjE2OTI1NTE2NzgxMjQ2Mjk2NjgwMTE1MTU1NzYzMgZDZD',	'2026-04-21 19:28:16',	'2026-04-21 19:28:16'),
(250,	'1478798540543750',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDg4NjQxMzU2MjMyNDozMjc3NjE2OTI4NjE5MzQwOTc2NzI4Mjk2OTcyNDA1OTY0OAZDZD',	'2026-04-21 19:28:17',	'2026-04-21 19:28:17'),
(251,	'2877377335934360',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDA2MDA2NjM5NjY1MjA4NDozMjc3NjI0NjkxMDUwNjA4NDgzMjY5Njg4NTQxODM5MzYwMAZDZD',	'2026-04-21 20:38:25',	'2026-04-21 20:38:25'),
(252,	'1017442037279665',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDI0ODgxMTk5MTEwMjU1ODozMjc3NjM2Njc5MDU2OTU4MDc3NDIwNjIzNjcwNjk5NjIyNAZDZD',	'2026-04-21 22:26:44',	'2026-04-21 22:26:44'),
(253,	'1589422195657610',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MTAxOTM0MDIxNTY5ODozMjc3NjQxNjQxNDM4NDYwODQyNzAxNzI1ODQ3NzI4OTQ3MgZDZD',	'2026-04-21 23:11:34',	'2026-04-21 23:11:34'),
(254,	'933344782834939',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTY2MzQ0MjAzNjUyMzgzNDozMjc3NjQyNDI3NTQ5MDYwNTM0NzQ4NjYxMDEwMzQ2ODAzMgZDZD',	'2026-04-21 23:18:40',	'2026-04-21 23:18:40'),
(255,	'933344782834939',	'inbound',	'Hola qué tal',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTY2MzQ0MjAzNjUyMzgzNDozMjc3NjQzMzk5ODczNDE5MTc2NTM1NDU1NTM2MzAzMzA4OAZDZD',	'2026-04-21 23:27:28',	'2026-04-21 23:27:28'),
(256,	'933344782834939',	'inbound',	'Aún no recibo la plataforma para conseguir clientes potenciales',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTY2MzQ0MjAzNjUyMzgzNDozMjc3NjQzNDI2MTI2ODE3OTYzNTQxMjU5OTEyMzczODYyNAZDZD',	'2026-04-21 23:27:42',	'2026-04-21 23:27:42'),
(257,	'2100641667446248',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MTAzMDY4MDIxNDU2NDozMjc3NjQ0MDUwODA2MjUwNjI2MzIyNjg1ODkyNTQ1NzQwOAZDZD',	'2026-04-21 23:33:20',	'2026-04-21 23:33:20'),
(258,	'1644214749911832',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE0MjQ1MjU1ODQwNTcxMDozMjc3NjUxMDM0NDE3NDQ0MzIyOTc3NDQ2MDMwOTQ3MTIzMgZDZD',	'2026-04-22 00:36:26',	'2026-04-22 00:36:26'),
(259,	'1644214749911832',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE0MjQ1MjU1ODQwNTcxMDozMjc3NjUxMDU1NDM0NTEzNDQzNzMxOTA5NjY2MTk2Njg0OAZDZD',	'2026-04-22 00:36:38',	'2026-04-22 00:36:38'),
(260,	'1644214749911832',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE0MjQ1MjU1ODQwNTcxMDozMjc3NjUxMDU4ODA4Mzc2ODE3OTUzMjAyMzgyODg0MDQ0OAZDZD',	'2026-04-22 00:36:39',	'2026-04-22 00:36:39'),
(261,	'4428288237493548',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MTExNTgyNjg3MjcxNjozMjc3NjYxODg2OTQxODg1NDI5NzUyMTkyMTYwNDk3NjY0MAZDZD',	'2026-04-22 02:14:29',	'2026-04-22 02:14:29'),
(262,	'945851951423147',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE2MjMyNjAyMzA5MTM0MzozMjc3NjYxOTk1MDc1NDIyNjc1MTQ3NjgzMDMyNTE3ODM2OAZDZD',	'2026-04-22 02:15:28',	'2026-04-22 02:15:28'),
(263,	'945851951423147',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE2MjMyNjAyMzA5MTM0MzozMjc3NjYyMDc3MTU2OTgxMTMyMDc4MjA0MTIyNTYyNTYwMAZDZD',	'2026-04-22 02:16:13',	'2026-04-22 02:16:13'),
(264,	'945851951423147',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE2MjMyNjAyMzA5MTM0MzozMjc3NjYyMDgwMzAxNjE3ODg1NzQxOTUyNDY3MDQ4ODU3NgZDZD',	'2026-04-22 02:16:14',	'2026-04-22 02:16:14'),
(265,	'2491770797946377',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTY3ODI1MjAzMTczMjMxMzozMjc3Njc3NjQ3NTc3MjIwNDY3NzQ2OTg5NzQzODAwMzIwMAZDZD',	'2026-04-22 04:36:53',	'2026-04-22 04:36:53'),
(266,	'2491770797946377',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTY3ODI1MjAzMTczMjMxMzozMjc3Njc3Njg2ODg2NTE0NTEwNDc3NTc2OTM1OTM4NDU3NgZDZD',	'2026-04-22 04:37:16',	'2026-04-22 04:37:16'),
(267,	'2491770797946377',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTY3ODI1MjAzMTczMjMxMzozMjc3Njc3Njk1MDk2MzI2NTA0ODUzNTY2Njg4NDg3MDE0NAZDZD',	'2026-04-22 04:37:19',	'2026-04-22 04:37:19'),
(268,	'2491770797946377',	'inbound',	'Graciass',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTY3ODI1MjAzMTczMjMxMzozMjc3Njc3NzA2NjIxNDM3MTUwMzY1NjM2MDczMjUyNDU0NAZDZD',	'2026-04-22 04:37:26',	'2026-04-22 04:37:26'),
(269,	'2124250091644267',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3Njg1MDMxNjQ2OTI3MzYyNzgyOTk4MTA0MDA4Mjk0NAZDZD',	'2026-04-22 05:43:37',	'2026-04-22 05:43:37'),
(270,	'2124250091644267',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3Njg1MDM1NDI4NDkzMjk1ODIzNzg5ODQ2NjkxODQwMAZDZD',	'2026-04-22 05:43:38',	'2026-04-22 05:43:38'),
(271,	'947695278006026',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIxMjYxMDk1NDcyNzA1NDozMjc3NzE0MDE4ODM5NzEwNzQ1Nzk3MDc4ODM4MzA2NDA2NAZDZD',	'2026-04-22 10:05:30',	'2026-04-22 10:05:30'),
(272,	'1311014657532802',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDEyNDY4Mzc2MDE4MjU5MDozMjc3NzIzNDcyNTUzNDI0MDMxMTY0MDAyNDE4NzY2NjQzMgZDZD',	'2026-04-22 11:30:55',	'2026-04-22 11:30:55'),
(273,	'1626518015266934',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDI4MzMzNDc1MDk4NzIyMTozMjc3NzI0ODQ1MTY1NTkxNTQ2MzQ4MzQ0MzQ2ODMwNDM4NAZDZD',	'2026-04-22 11:43:19',	'2026-04-22 11:43:19'),
(274,	'2017160459150806',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDI5NDEyMzU2MzI0NjE4MzozMjc3NzM0MDQ1NjI2NTY1NjU4MDQzMjYzNjkyNzgwMzM5MgZDZD',	'2026-04-22 13:06:27',	'2026-04-22 13:06:27'),
(275,	'2101511390419863',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MTU0Nzg5MDE2Mjg0MzozMjc3NzQwNDY5MDM3MDk0MzczOTA1MDM4Mjc5MTI3ODU5MgZDZD',	'2026-04-22 14:04:29',	'2026-04-22 14:04:29'),
(276,	'1304906585112208',	'inbound',	'Hello, I recently came across your post and was genuinely impressed by the value and quality of your content. I am currently exploring opportunities to connect with more business owners for my services, and I believe a collaboration with you could be mutually beneficial. If you’re open to it, I would appreciate the opportunity to discuss this further at your convenience.',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIxNDU0MzcwNDUzMzQ5OTozMjc3NzQxMzU3NjAzNDAwOTYxNzg0NzczOTA2NDc3ODc1MgZDZD',	'2026-04-22 14:12:32',	'2026-04-22 14:12:32'),
(277,	'766056946333038',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MTU3ODUwNjgyNjQ0ODozMjc3NzQ1Mjc2MzgwNjQzNjQxNDA1ODUxODAyMjE5MzE1MgZDZD',	'2026-04-22 14:47:55',	'2026-04-22 14:47:55'),
(394,	'1886372735360477',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5NTM3NjY2OTc3OTk2NTozMjc4NTIwNTgzNjM1ODIzNzA2NTU4NzY2Nzc5Njc1NDQzMgZDZD',	'2026-04-27 11:32:49',	'2026-04-27 11:32:49'),
(278,	'766056946333038',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MTU3ODUwNjgyNjQ0ODozMjc3NzQ1MzE0NjcyMDA5NDUyNjYwOTk4NTE3MDgzMzQwOAZDZD',	'2026-04-22 14:48:15',	'2026-04-22 14:48:15'),
(279,	'1473378667524401',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MTU3OTM5MzQ5MzAyNjozMjc3NzQ1Mzk4Njg2MDU0MzUyNzc2NTU0MzQ3Mjg1NzA4OAZDZD',	'2026-04-22 14:49:01',	'2026-04-22 14:49:01'),
(280,	'974384752208786',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MTY4NzkyMzQ4MjE3MzozMjc3NzYxNDMxNzcxOTI2Mjg5MDkwNzcwMDYyMjc4NjU2MAZDZD',	'2026-04-22 17:13:52',	'2026-04-22 17:13:52'),
(281,	'974384752208786',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MTY4NzkyMzQ4MjE3MzozMjc3NzYxNDY2ODMzNjc0ODg2MDgzNDAzMjcwMjcxNzk1MgZDZD',	'2026-04-22 17:14:12',	'2026-04-22 17:14:12'),
(282,	'974384752208786',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MTY4NzkyMzQ4MjE3MzozMjc3NzYxNDc0MTIwNjIzOTQ0NTY3ODE0NzE5Nzk5Mjk2MAZDZD',	'2026-04-22 17:14:15',	'2026-04-22 17:14:15'),
(283,	'2124250091644267',	'outbound',	'yo si viviese solo',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3Nzc5NzA3MzA1NzYzODM1MzQ4MDQ1MDU1MTMxNjQ4MAZDZD',	'2026-04-22 19:59:01',	'2026-04-22 19:59:01'),
(284,	'2124250091644267',	'inbound',	'me parece top',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3Nzc5NzQ2NjUxNTEyMzMzNzE3MDk3MDYzMTczMzI0OAZDZD',	'2026-04-22 19:59:21',	'2026-04-22 19:59:21'),
(285,	'766056946333038',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MTU3ODUwNjgyNjQ0ODozMjc3NzgzMzc0NTY4Mjc3MTQwNDEwNjYzMTM3NjUzNTU1MgZDZD',	'2026-04-22 20:32:09',	'2026-04-22 20:32:09'),
(286,	'766056946333038',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MTU3ODUwNjgyNjQ0ODozMjc3NzgzMzc3OTc5MzkwMDI0OTM5OTk3NTUxOTE5MTA0MAZDZD',	'2026-04-22 20:32:09',	'2026-04-22 20:32:09'),
(287,	'927622099897399',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5OTc0MjE0MjY4MTc4MjozMjc3NzgzNTExNDY3NzY2NzA2NzY2ODI2ODMxMjQyODU0NAZDZD',	'2026-04-22 20:33:22',	'2026-04-22 20:33:22'),
(288,	'927622099897399',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5OTc0MjE0MjY4MTc4MjozMjc3NzgzNTM2MDUwNjE1NDM3NzM2NjQyNjE2MjgyMzE2OAZDZD',	'2026-04-22 20:33:36',	'2026-04-22 20:33:36'),
(289,	'927622099897399',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5OTc0MjE0MjY4MTc4MjozMjc3NzgzNTM5NzQ1NTc3NTk2NzAwMTgyNzU2MDM5MDY1NgZDZD',	'2026-04-22 20:33:37',	'2026-04-22 20:33:37'),
(290,	'841261688325984',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4OTk5ODEzNjk4NDQ4NTozMjc3Nzg2NTg4OTY4NzQ2MzkxMDc5NDU3Njg3MTI5MjkyOAZDZD',	'2026-04-22 21:01:10',	'2026-04-22 21:01:10'),
(291,	'841261688325984',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4OTk5ODEzNjk4NDQ4NTozMjc3Nzg5OTI0MzI0NDY0ODgyMTc4Mzc1Nzk1OTcyNTA1NgZDZD',	'2026-04-22 21:31:19',	'2026-04-22 21:31:19'),
(292,	'841261688325984',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4OTk5ODEzNjk4NDQ4NTozMjc3Nzg5OTI3MDE3OTc5MTMwODIxOTI3NTcxODY4ODc2OAZDZD',	'2026-04-22 21:31:20',	'2026-04-22 21:31:20'),
(293,	'2356979574809891',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MTg3MDA5Njc5NzI4OTozMjc3Nzk2NzMzOTI1ODYxNTI0NTY0MzAxNjgxMDAwNDQ4MAZDZD',	'2026-04-22 22:32:50',	'2026-04-22 22:32:50'),
(294,	'977780427913284',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE1OTU2NzU5NjY5Njc1MjozMjc3ODE2NDkyMDAxODgwNTg1ODU2NTc2MzE5MDc1MTIzMgZDZD',	'2026-04-23 01:31:21',	'2026-04-23 01:31:21'),
(295,	'4324287041159854',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MjAxMjEzMzQ0OTc1MjozMjc3ODI2MjYyMzQ1NzI2ODAzOTE2NjcxNTU3MTk5NDYyNAZDZD',	'2026-04-23 02:59:37',	'2026-04-23 02:59:37'),
(296,	'1629475291758281',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MjA3NDg3MDExMDE0NTozMjc3ODM3NzMwODQ1NDk3MDAzNTk1MzYyMjUzMDkxNjM1MgZDZD',	'2026-04-23 04:43:14',	'2026-04-23 04:43:14'),
(480,	'1513465500168398',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5OTk5NzA5NTk4NDU4OTozMjc5NDU3NDUyMjk2MjM5MTQyNTM4MjUyNzkzMTUxNDg4MAZDZD',	'2026-05-03 08:37:27',	'2026-05-03 08:37:27'),
(297,	'1501879734905037',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MjA4NjkwMDEwODk0MjozMjc3ODQwMDE3NTE5MDc1ODk1Njc4NDUwOTA0Mzg2NzY0OAZDZD',	'2026-04-23 05:03:54',	'2026-04-23 05:03:54'),
(298,	'2461732420937844',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MjExNzk3MDEwNTgzNTozMjc3ODQ1OTYzNjk4MDE3MDYxOTI0MTExODMwODQ5OTQ1NgZDZD',	'2026-04-23 05:57:37',	'2026-04-23 05:57:37'),
(299,	'2461732420937844',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MjExNzk3MDEwNTgzNTozMjc3ODQ2MjY1MjE0NzUxMDIxNzcxMTIxNTU5MDc2ODY0MAZDZD',	'2026-04-23 06:00:22',	'2026-04-23 06:00:22'),
(300,	'2461732420937844',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MjExNzk3MDEwNTgzNTozMjc3ODQ2MjcyNTQ3NjI4NzgzNjUwMjU1MDUwMjE3ODgxNgZDZD',	'2026-04-23 06:00:25',	'2026-04-23 06:00:25'),
(301,	'945709441765836',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIwMTU3MTUzMjQ5NjQyNDozMjc3ODUyMjQ1MDg2ODEyMjc4NTc2NjQ2MDc1NzExNDg4MAZDZD',	'2026-04-23 06:54:22',	'2026-04-23 06:54:22'),
(302,	'945709441765836',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIwMTU3MTUzMjQ5NjQyNDozMjc3ODUyMzQ5OTY2MzczMzg0MTYwMjg5OTc3OTUxODQ2NAZDZD',	'2026-04-23 06:55:21',	'2026-04-23 06:55:21'),
(303,	'945709441765836',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIwMTU3MTUzMjQ5NjQyNDozMjc3ODUyMzU0NzgxMjE4OTI5MDk0NjYzMjg2NzY0MzM5MgZDZD',	'2026-04-23 06:55:22',	'2026-04-23 06:55:22'),
(304,	'2124250091644267',	'outbound',	'qué opinas de esto?',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc3ODY1NTI4NjQ5MjM5NTU1MDc0OTgzNjQwNzk5NjQxNgZDZD',	'2026-04-23 08:54:24',	'2026-04-23 08:54:24'),
(305,	'940770378567393',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MjI1MzQ0Njc1ODk1NDozMjc3ODcwOTQzNDI0NDM0NjEwNzY0ODY4MDYxMDc1ODY1NgZDZD',	'2026-04-23 09:43:19',	'2026-04-23 09:43:19'),
(306,	'26376249765372152',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTk5MDU2NzI4NjkxODQ1NjozMjc3ODgwODkxMTU4OTQxNzk2NjkxMDYzMDQ0MDk5Mjc2OAZDZD',	'2026-04-23 11:13:11',	'2026-04-23 11:13:11'),
(307,	'26376249765372152',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTk5MDU2NzI4NjkxODQ1NjozMjc3ODgwOTU2MDc3MTg2NTU0MTY1OTY3MjAwODcyMDM4NAZDZD',	'2026-04-23 11:13:47',	'2026-04-23 11:13:47'),
(308,	'26376249765372152',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTk5MDU2NzI4NjkxODQ1NjozMjc3ODgwOTU5MTIwODg0NTY4OTMyNzg0MjQ5ODcwNzQ1NgZDZD',	'2026-04-23 11:13:48',	'2026-04-23 11:13:48'),
(309,	'1615600679695447',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MjMyMzgwMDA4NTI1MjozMjc3ODgzNDk0ODYxOTczOTc5Nzc5NzI4NzU4ODAwMzg0MAZDZD',	'2026-04-23 11:36:43',	'2026-04-23 11:36:43'),
(310,	'950899621039102',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5ODE3NzY5MjgyOTgzMTozMjc3ODg1NjMxMjcxMTgzMjQxODcyODI4NTM5OTE1NDY4OAZDZD',	'2026-04-23 11:56:01',	'2026-04-23 11:56:01'),
(311,	'950899621039102',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5ODE3NzY5MjgyOTgzMTozMjc3ODg1NjY3NjQ2MTc3Njg1NTY1NzMzMTc4OTEzNTg3MgZDZD',	'2026-04-23 11:56:22',	'2026-04-23 11:56:22'),
(312,	'950899621039102',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5ODE3NzY5MjgyOTgzMTozMjc3ODg1NjcxMzI1MTAyMjQ1MjMxNTkwMjM0NDk1Mzg1NgZDZD',	'2026-04-23 11:56:23',	'2026-04-23 11:56:23'),
(313,	'2171552410363581',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MjQzODc5Njc0MDQxOTozMjc3OTAxMTUzNzQyMzEzNzEyNzA0ODMwNzEzNTIxNzY2NAZDZD',	'2026-04-23 14:16:16',	'2026-04-23 14:16:16'),
(314,	'2171552410363581',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MjQzODc5Njc0MDQxOTozMjc3OTAxMTcxMTY3Nzg3MDA0OTEyNzg1NjgxNDk0ODM1MgZDZD',	'2026-04-23 14:16:26',	'2026-04-23 14:16:26'),
(315,	'2171552410363581',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MjQzODc5Njc0MDQxOTozMjc3OTAxMTc1MDA1MDEyMjk4ODQ3MTgxMjU0MjY5MzM3NgZDZD',	'2026-04-23 14:16:27',	'2026-04-23 14:16:27'),
(435,	'1621503702496640',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5OTE0ODQ0Mjc0MDg2MTozMjc4Nzk5MzY0MzAxNTYzNDYzNzY1ODQ1ODY1MTg4NTU2OAZDZD',	'2026-04-29 05:31:37',	'2026-04-29 05:31:37'),
(479,	'26535104462778974',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIwMDkyMzIzMjU1ODY0MjozMjc5NDE1MzMyMDQ5MzE1NzIwNTUzNjcwMDIzMDUzMzEyMAZDZD',	'2026-05-03 02:16:54',	'2026-05-03 02:16:54'),
(316,	'1012901167737287',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MjU5MjQzMDA1ODM4OTozMjc3OTIxNjc4NTIwMDQ2ODA0Mjg2NzYwODQ2OTM3MjkyOAZDZD',	'2026-04-23 17:21:42',	'2026-04-23 17:21:42'),
(317,	'1615600679695447',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MjMyMzgwMDA4NTI1MjozMjc3OTM0NTEwODI1OTc3NDQ1NjYwMzI1NzUyMDI1OTA3MgZDZD',	'2026-04-23 19:17:40',	'2026-04-23 19:17:40'),
(318,	'1615600679695447',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MjMyMzgwMDA4NTI1MjozMjc3OTM0NTE0ODM5Njg2NDI5NDk2NzE1MzQ3MDIxMDA0OAZDZD',	'2026-04-23 19:17:41',	'2026-04-23 19:17:41'),
(319,	'982088827544882',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MjY3MTM4MzM4MzgyNzozMjc3OTM0OTk4OTUxNDUzODg0MDI3ODcxMTMzNzQ4NDI4OAZDZD',	'2026-04-23 19:22:03',	'2026-04-23 19:22:03'),
(320,	'1012901167737287',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MjU5MjQzMDA1ODM4OTozMjc3OTM3MDQxMzY2ODgxNzQwNTkzOTU2MDE1NTcwOTQ0MAZDZD',	'2026-04-23 19:40:31',	'2026-04-23 19:40:31'),
(321,	'1012901167737287',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MjU5MjQzMDA1ODM4OTozMjc3OTM3MDQ0ODI1NTc4MDAxNDYxNDI0MjE4MjI5OTY0OAZDZD',	'2026-04-23 19:40:32',	'2026-04-23 19:40:32'),
(322,	'1273624654886980',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDI3MjE3NzQwMjEwMDMyOTozMjc3OTQ1NzI2MjczODIxNTcyMzI3ODIxNzYzMjU0NjgxNgZDZD',	'2026-04-23 20:58:59',	'2026-04-23 20:58:59'),
(323,	'4428288237493548',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MTExNTgyNjg3MjcxNjozMjc3OTQ5NzA4NTI4MDMxNjkwODA1NTQzODcwODE3ODk0NAZDZD',	'2026-04-23 21:34:59',	'2026-04-23 21:34:59'),
(324,	'4428288237493548',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MTExNTgyNjg3MjcxNjozMjc3OTQ5NzE0MTA2OTUyNDQzMzE5NDExMDMzMjk2MDc2OAZDZD',	'2026-04-23 21:35:00',	'2026-04-23 21:35:00'),
(325,	'2506360843114107',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIxOTc0OTc1MDY3NzAzNTozMjc3OTU1MzM1ODEyMzM5NzU3OTYyMzM3MDM0Njk4NzUyMAZDZD',	'2026-04-23 22:25:48',	'2026-04-23 22:25:48'),
(326,	'2506360843114107',	'inbound',	'¡Hola! outcrease Gracias por ponerte en contacto con nosotros. Hemos recibido tu mensaje y agradecemos tu interés.

Muy pronto, uno de nuestros expertos se pondrá en contacto contigo.😊 
Tambíen puedes escribir a un experto vía whatsapp, en sl siguiente link: wa.link/c4iey4',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIxOTc0OTc1MDY3NzAzNTozMjc3OTU1MzQxNDk2MzYyNjc5NTEwNTcxNzM4NDY0MjU2MAZDZD',	'2026-04-23 22:25:53',	'2026-04-23 22:25:53'),
(327,	'2356979574809891',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MTg3MDA5Njc5NzI4OTozMjc3OTc4OTAyMDQxOTc4ODUzODA3MTA4NDg0ODY0NDA5NgZDZD',	'2026-04-24 01:58:46',	'2026-04-24 01:58:46'),
(328,	'2356979574809891',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MTg3MDA5Njc5NzI4OTozMjc3OTc4OTEyNjM0MzQyNzk3OTUyOTA1OTg4ODUyOTQwOAZDZD',	'2026-04-24 01:58:49',	'2026-04-24 01:58:49'),
(329,	'1694828791652468',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5Mjg5MzM0MDAyODI5ODozMjc3OTgxMDAxMTI0NDE1NDY0OTgwMTg1NjAxODAyMjQwMAZDZD',	'2026-04-24 02:17:41',	'2026-04-24 02:17:41'),
(330,	'1311014657532802',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDEyNDY4Mzc2MDE4MjU5MDozMjc4MDAyNTc2MTc3MDM1Mzc5MTM0MjQ5MDA3OTQ2MTM3NgZDZD',	'2026-04-24 05:32:38',	'2026-04-24 05:32:38'),
(331,	'1311014657532802',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDEyNDY4Mzc2MDE4MjU5MDozMjc4MDAyNTc4NjU1NTEwMzk4MDg3MzQ2NDI3Nzg5MzEyMAZDZD',	'2026-04-24 05:32:38',	'2026-04-24 05:32:38'),
(332,	'1275791994693239',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIxMDAyNzg1MTY1MTI1NjozMjc4MDEwNjQyOTE5NDA4NjY3Mzg5MjA5MDU0OTYzMzAyNAZDZD',	'2026-04-24 06:45:30',	'2026-04-24 06:45:30'),
(333,	'1012901167737287',	'inbound',	'No logro entrar al link',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MjU5MjQzMDA1ODM4OTozMjc4MDY5NzAwNzU4OTA4NDgyNzAzMjI5NjAyMDI0NjUyOAZDZD',	'2026-04-24 15:39:09',	'2026-04-24 15:39:09'),
(334,	'1889273125048182',	'inbound',	'Clientes',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE1ODkxNjMyMzQzMTMxNDozMjc4MDcwOTA3MTI2MTg4Njc1MDc2MTg1MzIxNDc4NTUzNgZDZD',	'2026-04-24 15:50:01',	'2026-04-24 15:50:01'),
(335,	'1889273125048182',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE1ODkxNjMyMzQzMTMxNDozMjc4MDcwOTM2MDA4MzM4ODgxNjMxNTYxOTc5NjMyMDI1NgZDZD',	'2026-04-24 15:50:15',	'2026-04-24 15:50:15'),
(336,	'1889273125048182',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE1ODkxNjMyMzQzMTMxNDozMjc4MDcwOTQyOTcwMDYwNzc0MDUwMDI5ODA4NDM4NDc2OAZDZD',	'2026-04-24 15:50:19',	'2026-04-24 15:50:19'),
(338,	'1483430649828999',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIxNzI2OTE2MDkyODc0ODozMjc4MDczNDk5OTE2NjM5ODgzNjQzNTI5NDI1Njg4OTg1NgZDZD',	'2026-04-24 16:13:25',	'2026-04-24 16:13:25'),
(339,	'1483430649828999',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIxNzI2OTE2MDkyODc0ODozMjc4MDc3MDk5MjIwNzc0MzI3NDE5NDY2OTg3ODExNjM1MgZDZD',	'2026-04-24 16:45:57',	'2026-04-24 16:45:57'),
(340,	'1483430649828999',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIxNzI2OTE2MDkyODc0ODozMjc4MDc3MTAzNjA5MjczMTg5Mjk5MDQzMDI2ODA5NjUxMgZDZD',	'2026-04-24 16:45:58',	'2026-04-24 16:45:58'),
(341,	'885437074512295',	'inbound',	'Holaaaaaa',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE3OTcyOTYzMTM0MzI5MTozMjc4MDg0ODcyMTIzNDc4MTQ3MzMxNDUzMDk1NjE0ODczNgZDZD',	'2026-04-24 17:56:14',	'2026-04-24 17:56:14'),
(342,	'2706555539701856',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4ODAwOTY4Mzg1MTY5NjozMjc4MTIzMTMzNDcxMzEwNDQ0Mzc0NjQzNTk2MDE0Mzg3MgZDZD',	'2026-04-24 23:41:51',	'2026-04-24 23:41:51'),
(343,	'987757560427144',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4NDIwOTEzNzU2NzA1MDozMjc4MTQ4MDE1NjE1NjEzOTg4MTY4NTE1NDc5MzUyMTE1MgZDZD',	'2026-04-25 03:26:40',	'2026-04-25 03:26:40'),
(344,	'1385342460295707',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIyNjMwNzI3MDAyMjIxMjozMjc4MTU0NTA0MzAwNDUwMjA0OTY0NzUwNzI5Njc0NzUyMAZDZD',	'2026-04-25 04:25:18',	'2026-04-25 04:25:18'),
(345,	'1477654067305681',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5NDA2NjAzOTkxMTAyODozMjc4MTgzNjk2NDQ5MDQ2ODQ3OTU1NDQzOTEzMjIxNzM0NAZDZD',	'2026-04-25 08:49:03',	'2026-04-25 08:49:03'),
(346,	'1490239729411691',	'inbound',	'AI',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDI0NzgxMjQ0MTIwNDM1MDozMjc4MTg1NTAyNDgwOTg5NjgzMDI2MTM3NTMxNDk1MjE5MgZDZD',	'2026-04-25 09:05:26',	'2026-04-25 09:05:26'),
(347,	'940770378567393',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MjI1MzQ0Njc1ODk1NDozMjc4MTkwOTMzMTg4MjMxNzY2ODA5MzQwMDcyMzc1MDkxMgZDZD',	'2026-04-25 09:54:26',	'2026-04-25 09:54:26'),
(348,	'940770378567393',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MjI1MzQ0Njc1ODk1NDozMjc4MTkwOTQwMTE2MTAyMDM5MTc4MTQzNTAzMDExMDIwOAZDZD',	'2026-04-25 09:54:29',	'2026-04-25 09:54:29'),
(349,	'1644156386892359',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE0NjE2MzY2NDcwMDA3OTozMjc4MjI2NTYxODkxNzU0MzI1NDI5MDI2OTc0MTI1MjYwOAZDZD',	'2026-04-25 15:16:20',	'2026-04-25 15:16:20'),
(350,	'1644156386892359',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE0NjE2MzY2NDcwMDA3OTozMjc4MjI2NjQ5MTEyNDI2MjYyNjY4MDMyMDk3MDE5NDk0NAZDZD',	'2026-04-25 15:17:09',	'2026-04-25 15:17:09'),
(351,	'1644156386892359',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE0NjE2MzY2NDcwMDA3OTozMjc4MjI2NjU0NTAzMDk0MzAyNTYwODc4NTQzMzQ2MDczNgZDZD',	'2026-04-25 15:17:10',	'2026-04-25 15:17:10'),
(352,	'911213271524379',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4MzQwNDk5NDMwOTMyNzozMjc4MjYzODczNjc2NDg4NDA0NDkyNTMxMDc1ODU1MTU1MgZDZD',	'2026-04-25 20:53:27',	'2026-04-25 20:53:27'),
(353,	'1873534460029122',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIxMzAzNjE2NDY4NjE3NzozMjc4MjcwNzYwMDYzNjM2MDAwNjQwNzc1NjAyODMxMzYwMAZDZD',	'2026-04-25 21:55:40',	'2026-04-25 21:55:40'),
(354,	'26608022322193852',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5NDY0NDI5OTg1MzIwMjozMjc4Mjc2NzQ0NTg2MjAyNjA0MTAyNDAyNDAzODg2Njk0NAZDZD',	'2026-04-25 22:49:44',	'2026-04-25 22:49:44'),
(355,	'26608022322193852',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5NDY0NDI5OTg1MzIwMjozMjc4Mjc3MzA1MzYwNTkyNjg1MDUyNjgwMzE3NDM1OTA0MAZDZD',	'2026-04-25 22:54:49',	'2026-04-25 22:54:49'),
(356,	'26608022322193852',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5NDY0NDI5OTg1MzIwMjozMjc4Mjc3MzEyNjA5ODY5ODAyNzg5NzYyMTIwNjUzMjA5NgZDZD',	'2026-04-25 22:54:52',	'2026-04-25 22:54:52'),
(457,	'1371898238027545',	'inbound',	'Clientes',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDI1MzAxOTE1NzM1MDkxODozMjc5MTE4MDE4NTA1NTUzODM1Mzc5OTAyNjkzNzE2Nzg3MgZDZD',	'2026-05-01 05:30:48',	'2026-05-01 05:30:48'),
(357,	'927326150296490',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5NDY2MTcxMzE4NDc5NDozMjc4MjgwNjY1NjAzMTU2NzE1NDMyOTI1NTA5MDg0Nzc0NAZDZD',	'2026-04-25 23:25:10',	'2026-04-25 23:25:10'),
(358,	'927326150296490',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5NDY2MTcxMzE4NDc5NDozMjc4MjgwNjkxODQ0ODc2ODY4NzY1NjY0MzY4MDI3MjM4NAZDZD',	'2026-04-25 23:25:24',	'2026-04-25 23:25:24'),
(359,	'927326150296490',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5NDY2MTcxMzE4NDc5NDozMjc4MjgwNjk1MTYxOTIwNTgxODkxMTE2OTIzODI2OTk1MgZDZD',	'2026-04-25 23:25:26',	'2026-04-25 23:25:26'),
(360,	'1012901167737287',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MjU5MjQzMDA1ODM4OTozMjc4Mjk3Njk2NDYxMzg0NjMyMjExOTE0NzYzOTUzNzY2NAZDZD',	'2026-04-26 01:59:02',	'2026-04-26 01:59:02'),
(361,	'1012901167737287',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MjU5MjQzMDA1ODM4OTozMjc4Mjk3NzY4ODIyNTE5ODQzODcyNzQxNDM1Nzk1MDQ2NAZDZD',	'2026-04-26 01:59:42',	'2026-04-26 01:59:42'),
(362,	'1012901167737287',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MjU5MjQzMDA1ODM4OTozMjc4Mjk3Nzc0NjQyNzAxODcyNzc3ODQxMDgxOTQ4NTY5NgZDZD',	'2026-04-26 01:59:44',	'2026-04-26 01:59:44'),
(363,	'1627859015208062',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5NDc4MzU5NjUwNTkzOTozMjc4MzA2NjQyMDEwNjgzNTg0MjY3NjQ4ODE4MDU5NjczNgZDZD',	'2026-04-26 03:19:51',	'2026-04-26 03:19:51'),
(364,	'1425450052664710',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5NDg5OTcwOTgyNzY2MTozMjc4MzI2OTg0NDg0OTE5MjEzODU1MTUzMzg4NjI0MjgxNgZDZD',	'2026-04-26 06:23:39',	'2026-04-26 06:23:39'),
(365,	'2112507496250400',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE2Mjk1ODYyMzAyMzI4NzozMjc4MzQwNTk4OTQ3NjExMzE2MDA0ODk1NTgyMDYwNTQ0MAZDZD',	'2026-04-26 08:26:40',	'2026-04-26 08:26:40'),
(366,	'1650026402853759',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIyNDYxMzgxMDE5NTA0ODozMjc4MzY1ODg4ODAzODc5Njc0MTAwOTc3OTYxOTUyODcwNAZDZD',	'2026-04-26 12:15:09',	'2026-04-26 12:15:09'),
(367,	'1954649795452874',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE3ODEwNjAxMTUxMjA3NTozMjc4MzY5NzA3OTIxMjUzNzk1OTA5Njc0MDUxNjcyNDczNgZDZD',	'2026-04-26 12:49:40',	'2026-04-26 12:49:40'),
(368,	'1954649795452874',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE3ODEwNjAxMTUxMjA3NTozMjc4MzY5NzIwNDM4MjYyNDcyMzM0NzcyMzY1NDI2Njg4MAZDZD',	'2026-04-26 12:49:47',	'2026-04-26 12:49:47'),
(369,	'1954649795452874',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE3ODEwNjAxMTUxMjA3NTozMjc4MzY5NzI3MzEyOTQ4OTM2ODY0NjYzNzg3Nzk4NTI4MAZDZD',	'2026-04-26 12:49:50',	'2026-04-26 12:49:50'),
(370,	'1504731478328689',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE1NzE5NjY5MzU5OTEzMjozMjc4MzgzOTUwMTg1Mjc2MDEzMDg0OTI4ODA1NDg5ODY4OAZDZD',	'2026-04-26 14:58:20',	'2026-04-26 14:58:20'),
(371,	'933196602961071',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDExMjY2MzgxMTM4MDYwNDozMjc4MzkyMTc5NzcxMDM0NDkzMjg0MzQzMzIzMjQzMzE1MgZDZD',	'2026-04-26 16:12:42',	'2026-04-26 16:12:42'),
(372,	'26412915118358917',	'inbound',	'Buenas señor , abandonaste el reto?',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE0OTQ0NTYwNzcwODI2NDozMjc4Mzk0ODg3MDkxNDg4NjM5NzEyNTkzODIxOTMxOTI5NgZDZD',	'2026-04-26 16:37:12',	'2026-04-26 16:37:12'),
(373,	'1163298232533857',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDAzMjAwMzQyNjEwODQ3NzozMjc4Mzk1MDA4NzEyOTU2Nzk5NzU5OTk2ODA1NTUyNTM3NgZDZD',	'2026-04-26 16:38:15',	'2026-04-26 16:38:15'),
(456,	'1291762436176725',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE3ODI2MDMxODE2MDgzMTozMjc5MTEwNjY0MDM5MzgyODk5MzQzMzg2MjAwOTc4MjI3MgZDZD',	'2026-05-01 04:24:13',	'2026-05-01 04:24:13'),
(374,	'2069240703973070',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5NDI0MTIzMzIyOTMyODozMjc4Mzk4MDIxNDQ0MzY1MTA1MTM0MTkzMDA2ODcwNTI4MAZDZD',	'2026-04-26 17:05:28',	'2026-04-26 17:05:28'),
(375,	'1886372735360477',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5NTM3NjY2OTc3OTk2NTozMjc4NDA2MTE4MjQ0MDQ1ODA5ODU3ODI2MTgxNTU5MDkxMgZDZD',	'2026-04-26 18:18:38',	'2026-04-26 18:18:38'),
(376,	'888196754087030',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE2MjM2NTE3NjQxNTYyMzozMjc4NDA4MjUwNDE2NjY1MTQ3NTE4MzQ4MDgxMjMzOTIwMAZDZD',	'2026-04-26 18:37:54',	'2026-04-26 18:37:54'),
(377,	'1425450052664710',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5NDg5OTcwOTgyNzY2MTozMjc4NDIyOTc4OTEyNDQzMTkyNTQ3MDE0MDk5MzM3MjE2MAZDZD',	'2026-04-26 20:50:59',	'2026-04-26 20:50:59'),
(378,	'1425450052664710',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5NDg5OTcwOTgyNzY2MTozMjc4NDIyOTg2MjcyMzMyNTIxNzczMjgwNDg2OTA5NTQyNAZDZD',	'2026-04-26 20:51:02',	'2026-04-26 20:51:02'),
(379,	'1650026402853759',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIyNDYxMzgxMDE5NTA0ODozMjc4NDIzNzE5NTQ1MjY4MzA0MDc5MzMwMjY2NzM2MjMwNAZDZD',	'2026-04-26 20:57:40',	'2026-04-26 20:57:40'),
(380,	'1650026402853759',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIyNDYxMzgxMDE5NTA0ODozMjc4NDIzNzIzMTgxODI2MjI2NjMxMDk4NTk1MTIxNTYxNgZDZD',	'2026-04-26 20:57:41',	'2026-04-26 20:57:41'),
(381,	'983485637452128',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5NTUxMDg1NjQzMzIxMzozMjc4NDI5NDE5ODgzNDMxMDk1MDUwNTIwNjY4NTYzMDQ2NAZDZD',	'2026-04-26 21:49:09',	'2026-04-26 21:49:09'),
(382,	'983485637452128',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5NTUxMDg1NjQzMzIxMzozMjc4NDI5NDMxMDIyMTg3NTk4NjU5NTk1MDkxNDE3NDk3NgZDZD',	'2026-04-26 21:49:15',	'2026-04-26 21:49:15'),
(383,	'1192151939549760',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5NTU1NjMwOTc2MjAwMTozMjc4NDM4NzgyNDExOTQwNjM0MzY4MTUxODI0Nzg3MDQ2NAZDZD',	'2026-04-26 23:13:45',	'2026-04-26 23:13:45'),
(384,	'1192151939549760',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5NTU1NjMwOTc2MjAwMTozMjc4NDM4ODYwNDQ0MjY5MDU3MDczOTQ4MjA3MjQ0OTAyNAZDZD',	'2026-04-26 23:14:28',	'2026-04-26 23:14:28'),
(385,	'1192151939549760',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5NTU1NjMwOTc2MjAwMTozMjc4NDM4ODY0MDQwMTAzOTQ3NDA4NTk1MzI5NDgyNzUyMAZDZD',	'2026-04-26 23:14:29',	'2026-04-26 23:14:29'),
(386,	'1492022395646168',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIzNjkyOTYyODk2MDc0NTozMjc4NDM5OTE3MTI3NDU1MTU4NDM0NzgxNjc5NzkyOTQ3MgZDZD',	'2026-04-26 23:24:00',	'2026-04-26 23:24:00'),
(387,	'1425167615453658',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5NTc0MDU3MzA3NjkwODozMjc4NDcyMjQyNjA3NjMxNjU5OTAzNzc0MjA2ODc5MzM0NAZDZD',	'2026-04-27 04:16:04',	'2026-04-27 04:16:04'),
(388,	'1425167615453658',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5NTc0MDU3MzA3NjkwODozMjc4NDcyMjUyNjQ5NjMzMzA1MjYxNjMyNDk2NDk0MTgyNAZDZD',	'2026-04-27 04:16:10',	'2026-04-27 04:16:10'),
(389,	'1425167615453658',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5NTc0MDU3MzA3NjkwODozMjc4NDcyMjU1OTkwNTgwMzA5MzU3Nzk3ODg5Mjc3OTUyMAZDZD',	'2026-04-27 04:16:11',	'2026-04-27 04:16:11'),
(390,	'3852636308201179',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE3NTQ0ODE3MTc3MDIwODozMjc4NDk2NzI0MTEyMjY5NDQ0NDg5MzQ3OTU4Njc1ODY1NgZDZD',	'2026-04-27 07:57:15',	'2026-04-27 07:57:15'),
(391,	'3852636308201179',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE3NTQ0ODE3MTc3MDIwODozMjc4NDk3MjMxMzIwNzkwMTAxOTcwNTc0ODU4ODg1NTI5NgZDZD',	'2026-04-27 08:01:51',	'2026-04-27 08:01:51'),
(392,	'3852636308201179',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE3NTQ0ODE3MTc3MDIwODozMjc4NDk3MjM0NTUwNjA4Mzg1NzQzNDkxNzk5ODY5MDMwNAZDZD',	'2026-04-27 08:01:52',	'2026-04-27 08:01:52'),
(393,	'1886372735360477',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5NTM3NjY2OTc3OTk2NTozMjc4NTIwNTgwNDY2OTU4OTk5MjI4NjA4MzEwMDk2NjkxMgZDZD',	'2026-04-27 11:32:48',	'2026-04-27 11:32:48'),
(395,	'924401463414917',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5NjE3NDY5OTcwMDE2MjozMjc4NTQyMjIzNDE3MTgxMjg2OTY5NzAxMzc2OTMwNjExMgZDZD',	'2026-04-27 14:48:21',	'2026-04-27 14:48:21'),
(396,	'924401463414917',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5NjE3NDY5OTcwMDE2MjozMjc4NTQyNDE1ODMwMTQ1NjcxNDIyNzYzMTcyNTIxNTc0NAZDZD',	'2026-04-27 14:50:05',	'2026-04-27 14:50:05'),
(397,	'924401463414917',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5NjE3NDY5OTcwMDE2MjozMjc4NTQyNDE4MzcwMTg2Njk4NzIxODY2MjIwODgzMTQ4OAZDZD',	'2026-04-27 14:50:06',	'2026-04-27 14:50:06'),
(398,	'2449412075578909',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDEyNDUwNTQwNjg2MTA0NzozMjc4NTUzNzExOTk0MjUzMDc1MjQyMTI5OTcxOTUwMzg3MgZDZD',	'2026-04-27 16:32:08',	'2026-04-27 16:32:08'),
(399,	'1061145113754991',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5NjI1NTc5OTY5MjA1MjozMjc4NTUzOTc4NzY5NTM0Nzg5NDcxNTQ3NTQ5NzU4MjU5MgZDZD',	'2026-04-27 16:34:33',	'2026-04-27 16:34:33'),
(400,	'2855634211444046',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5NjM1NjMxMzAxNTMzNDozMjc4NTcwNzIxMjUzNTY2NTE0MzY4MTE2Mjg1NDUzMTA3MgZDZD',	'2026-04-27 19:05:49',	'2026-04-27 19:05:49'),
(401,	'2855634211444046',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5NjM1NjMxMzAxNTMzNDozMjc4NTcwODA0MTY5MTY0OTg5ODAwODk2ODE2NTMyNjg0OAZDZD',	'2026-04-27 19:06:35',	'2026-04-27 19:06:35'),
(402,	'2855634211444046',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5NjM1NjMxMzAxNTMzNDozMjc4NTcwODA3NjIwMzQ0MjAyNDU4MzI4Mzc2OTA4MTg1NgZDZD',	'2026-04-27 19:06:36',	'2026-04-27 19:06:36'),
(403,	'4249745812007934',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4NjM2OTIyNzM0NDgzNjozMjc4NTg5MTM1MjEzMTU2OTQwMjIxODAyMTkyMDk2NDYwOAZDZD',	'2026-04-27 21:52:11',	'2026-04-27 21:52:11'),
(404,	'944733318182286',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIzMzgzNjg1MjYwMTI2MDozMjc4NTkxMDU0MTU3MDA1OTczODkxMDA2NzIzODM3MTMyOAZDZD',	'2026-04-27 22:09:32',	'2026-04-27 22:09:32'),
(405,	'1061145113754991',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5NjI1NTc5OTY5MjA1MjozMjc4NjIwMzMzNTI4MDc0OTU2MzQyMjk5MDgyNTE2MDcwNAZDZD',	'2026-04-28 02:34:05',	'2026-04-28 02:34:05'),
(406,	'1061145113754991',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5NjI1NTc5OTY5MjA1MjozMjc4NjIwMzQxMjcyMzk2Mjc2NzM5MDc5ODk2NzIwOTk4NAZDZD',	'2026-04-28 02:34:08',	'2026-04-28 02:34:08'),
(407,	'1442204350502743',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5NjYzMTI4NjMyMTE3MDozMjc4NjI1MzA3MDA2Nzk0MDAyMjUyODg5MTQzMTE1Nzc2MAZDZD',	'2026-04-28 03:19:00',	'2026-04-28 03:19:00'),
(408,	'859605627127823',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDEzODI0OTk3NTQ5NTgzNzozMjc4NjMwOTczNjc1MTg2NTkxMzEyNzE3NTA1MjA2NjgxNgZDZD',	'2026-04-28 04:10:12',	'2026-04-28 04:10:12'),
(409,	'2047585716170464',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5NjgwMzk4Mjk3MDU2NzozMjc4NjU4Mjc0NjIxMzA4MjM4ODgwODY2MjA3OTUwNDM4NAZDZD',	'2026-04-28 08:16:52',	'2026-04-28 08:16:52'),
(410,	'988254307098578',	'inbound',	'Brother cuanto por Promo?',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTY2ODMzMTM5OTI4MjgwMDozMjc4Njc4NTkwOTE0NDgyMTQzNjczMjExMDM4MTUxNDc1MgZDZD',	'2026-04-28 11:20:28',	'2026-04-28 11:20:28'),
(411,	'888196754087030',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE2MjM2NTE3NjQxNTYyMzozMjc4Njk1Njg1MTczMjUwNzkzOTM3MDU4NDYxNTQxOTkwNAZDZD',	'2026-04-28 13:54:52',	'2026-04-28 13:54:52'),
(458,	'1371898238027545',	'inbound',	'Clientes',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDI1MzAxOTE1NzM1MDkxODozMjc5MTE4MDI0OTUyMDU4MTY1ODE5NjYyNzQ1ODg4MzU4NAZDZD',	'2026-05-01 05:30:49',	'2026-05-01 05:30:49'),
(412,	'644794538727267',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5NzA2MjE2Mjk0NDc0OTozMjc4NzAxNDIzNDY4MTg2ODE4MTMxMjI5NjE4MTU2MzM5MgZDZD',	'2026-04-28 14:46:43',	'2026-04-28 14:46:43'),
(413,	'962616409586016',	'inbound',	'Hola bro como andas, me encontré con tu perfil y me gusto mucho tu contenido. Mi intención es ayudar a dueños de negocios y creadores de contenido como vos a delegar y mejorar la edición de video para que ganes tiempo. Te dejo mi portafolio para que lo compruebes. Puedo manejar mas estilos de ediciones o incluso uno que vos quieras

https://drive.google.com/drive/folders/1RfZqyadtJi1ZHgiGaWzinAQyQVDPeLBs?hl=es',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5NzE3ODMwOTU5OTgwMTozMjc4NzE5MjE4MDUwMTYwMTg4OTE2NDk5MTkzNjg1NjA2NAZDZD',	'2026-04-28 17:27:31',	'2026-04-28 17:27:31'),
(414,	'2124250091644267',	'outbound',	'mi setup en el futuro',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc4NzIyNzE4MzE5NjMyMzQ4Mzk4MjU1OTI3OTMxNjk5MgZDZD',	'2026-04-28 17:59:08',	'2026-04-28 17:59:08'),
(415,	'1628763728336026',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5NzIwMjEzOTU5NzQxODozMjc4NzIyOTc3MzU1NjM0MjM3Mzg2MjM3NTExOTkxMjk2MAZDZD',	'2026-04-28 18:01:27',	'2026-04-28 18:01:27'),
(416,	'2124250091644267',	'inbound',	'top',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc4NzI1NTIxMTk1NzgzMjM1ODY1MDI2OTk2NTIyMTg4OAZDZD',	'2026-04-28 18:24:27',	'2026-04-28 18:24:27'),
(417,	'2124250091644267',	'inbound',	'uno de los porsche es para mi no?',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc4NzI1NTU0NDQ5MDIwNDIyNTY4ODA1MjQ3OTAzMzM0NAZDZD',	'2026-04-28 18:24:45',	'2026-04-28 18:24:45'),
(418,	'2124250091644267',	'outbound',	'será el tuyo, habrás venido a visitarme a mi setup obviamente',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc4NzI1NjA2NDcyMzQ3MjgxMTUyNTYwMzYxNzQwNjk3NgZDZD',	'2026-04-28 18:25:13',	'2026-04-28 18:25:13'),
(419,	'2124250091644267',	'inbound',	'que bien',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc4NzI1Njc1MTgxNjUwNjY2MTY4NTg3MTk2NDU4NTk4NAZDZD',	'2026-04-28 18:25:50',	'2026-04-28 18:25:50'),
(420,	'2124250091644267',	'inbound',	'matching porsches',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc4NzI1Njk1NzcxMDgxODMxNzgzMDkzODkzMjgwNTYzMgZDZD',	'2026-04-28 18:26:01',	'2026-04-28 18:26:01'),
(421,	'2124250091644267',	'outbound',	'yeaaaaah',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc4NzI1NzExNjQ2MTQ4NzEyMTA3MTMwNTc5ODk3NTQ4OAZDZD',	'2026-04-28 18:26:10',	'2026-04-28 18:26:10'),
(422,	'2124250091644267',	'inbound',	'creo q es IA',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc4NzI1ODI0MjUwNjczMTI0ODU2NjA0NDkyODc3MDA0OAZDZD',	'2026-04-28 18:27:11',	'2026-04-28 18:27:11'),
(423,	'2124250091644267',	'outbound',	'si lo es',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc4NzI2NzAxNDk3ODY3NTQ3NjQ0MjAwMDQwMjY3Nzc2MAZDZD',	'2026-04-28 18:35:07',	'2026-04-28 18:35:07'),
(424,	'2124250091644267',	'outbound',	'nano banana pro',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc4NzI2NzI4ODEyMzM1OTY2NDkwNjI5NDIxOTc2NzgwOAZDZD',	'2026-04-28 18:35:21',	'2026-04-28 18:35:21'),
(425,	'2030094637888489',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIzNjI5NDg3OTAyNjc1MjozMjc4NzI5OTMxNjk1OTAxNTI4MDg1NzQ3OTY2MjAxMDM2OAZDZD',	'2026-04-28 19:04:17',	'2026-04-28 19:04:17'),
(426,	'1628763728336026',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5NzIwMjEzOTU5NzQxODozMjc4NzM4NTkwNzk3NzM3MTkxOTY3NTA2MjMyMTQxNDE0NAZDZD',	'2026-04-28 20:22:34',	'2026-04-28 20:22:34'),
(427,	'1628763728336026',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5NzIwMjEzOTU5NzQxODozMjc4NzM4NjAwNDU5NTc5MTEyMDgyMzIxMjI3Mjc3OTI2NAZDZD',	'2026-04-28 20:22:37',	'2026-04-28 20:22:37'),
(428,	'1486814872995711',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5NzMwMTUyOTU4NzQ3OTozMjc4NzQxMTk2NzI3MjgwMzE2NzA2NDcwNjAxMTYyNzUyMAZDZD',	'2026-04-28 20:46:04',	'2026-04-28 20:46:04'),
(429,	'940397058777589',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5NzM1NjA1MjkxNTM2MDozMjc4NzUyODc5MTE5NzMwMjA3NjM1NzI5NjUzMzc5ODkxMgZDZD',	'2026-04-28 22:31:37',	'2026-04-28 22:31:37'),
(430,	'940397058777589',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5NzM1NjA1MjkxNTM2MDozMjc4NzUyODk3NDQ5NzE5MzA0MDc5NTUxNDA0MzM2NzQyNAZDZD',	'2026-04-28 22:31:48',	'2026-04-28 22:31:48'),
(431,	'940397058777589',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5NzM1NjA1MjkxNTM2MDozMjc4NzUyOTAwNjMyMzM5NzQ4NDY1NDc1MDg2NTU1NTQ1NgZDZD',	'2026-04-28 22:31:49',	'2026-04-28 22:31:49'),
(432,	'940397058777589',	'inbound',	'Gracias',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5NzM1NjA1MjkxNTM2MDozMjc4NzUyOTE2NDkyNjk5MDM5NzM5NTQzMTQ3NjY5MDk0NAZDZD',	'2026-04-28 22:31:58',	'2026-04-28 22:31:58'),
(433,	'1621503702496640',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5OTE0ODQ0Mjc0MDg2MTozMjc4Nzk5MzM2MzI3Njg4NTA3ODg4NTU3OTk2NjM4MjA4MAZDZD',	'2026-04-29 05:31:22',	'2026-04-29 05:31:22'),
(436,	'1395725265190967',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE0Njk5MjYzNzk0Nzk5MjozMjc4ODMyODAxOTM3NjE4ODIyODk0NDEyODkwMTEyMDAwMAZDZD',	'2026-04-29 10:33:43',	'2026-04-29 10:33:43'),
(437,	'2016058522283155',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5NzkzNDkxNjE5MDgwNzozMjc4ODU3MDU4NzQ2NDY0NDU1MDY0NzExMjY3MjQ3NzE4NAZDZD',	'2026-04-29 14:12:53',	'2026-04-29 14:12:53'),
(438,	'2016058522283155',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5NzkzNDkxNjE5MDgwNzozMjc4ODU3MDkxOTA5MDgzODU2MTgwNzk4NzE3MjcwNDI1NgZDZD',	'2026-04-29 14:13:12',	'2026-04-29 14:13:12'),
(439,	'2016058522283155',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5NzkzNDkxNjE5MDgwNzozMjc4ODU3MTA5OTI4MzY1MjE4ODE5MDkzNjM1NTgzMTgwOAZDZD',	'2026-04-29 14:13:21',	'2026-04-29 14:13:21'),
(440,	'896123850113963',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5ODE1MTIyOTUwMjUwOTozMjc4ODkxMDQ2NzcxMTY3OTMxMzY3Mzc5Mzg5MzgyNjU2MAZDZD',	'2026-04-29 19:19:58',	'2026-04-29 19:19:58'),
(441,	'1620630022544374',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIwNzQ0NjgzMTkxMTQzMTozMjc4ODkyNDA3MTE4MzMzMjc0OTQwNzkxMzAxMTgzODk3NgZDZD',	'2026-04-29 19:32:15',	'2026-04-29 19:32:15'),
(442,	'969669795548377',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDQ1NjE5MzYwNTM0NjozMjc4OTQ2NDY0MzQ0NjY1NTU2MjM4NzE2NTQ5MjAxOTIwMAZDZD',	'2026-04-30 03:40:41',	'2026-04-30 03:40:41'),
(443,	'969669795548377',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDQ1NjE5MzYwNTM0NjozMjc4OTQ2NDcyMDY1NTI5OTk2ODcxMzY4Mjk3NTcxOTQyNAZDZD',	'2026-04-30 03:40:44',	'2026-04-30 03:40:44'),
(444,	'1666736147584931',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5ODU0MDY0Mjc5NjkwMTozMjc4OTYzMDMzMTM1MjQzNDQwOTg2NDk2MTMyMTg2MTEyMAZDZD',	'2026-04-30 06:10:22',	'2026-04-30 06:10:22'),
(445,	'26644821368505096',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5ODgzOTc0NjEwMDMyNDozMjc5MDE1NTY1MjM3OTM3Mzc5NzI0NzE3MzI2MTI2Mjg0OAZDZD',	'2026-04-30 14:05:00',	'2026-04-30 14:05:00'),
(446,	'26644821368505096',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5ODgzOTc0NjEwMDMyNDozMjc5MDI0MzUyODkzMzA0NDIwOTUwNjM2MTg3NDA1NTE2OAZDZD',	'2026-04-30 15:24:24',	'2026-04-30 15:24:24'),
(447,	'26644821368505096',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5ODgzOTc0NjEwMDMyNDozMjc5MDI0MzYwMTkzNjMyOTAyOTExNzA5MTc0NzIwMTAyNAZDZD',	'2026-04-30 15:24:27',	'2026-04-30 15:24:27'),
(448,	'1264566175874095',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDI1MDg4MzUxNDIzMTMwMjozMjc5MDU2MTc3OTI4MTM4MDA2MjE3MTI2MzY4MDkwNTIxNgZDZD',	'2026-04-30 20:11:56',	'2026-04-30 20:11:56'),
(449,	'896123850113963',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5ODE1MTIyOTUwMjUwOTozMjc5MDYxNzMxNzUyODQ0MTQ1NjExODM2NDgwNTAwNTMxMgZDZD',	'2026-04-30 21:02:07',	'2026-04-30 21:02:07'),
(450,	'896123850113963',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5ODE1MTIyOTUwMjUwOTozMjc5MDYxNzM4OTQzMTYzNjI0NjE0OTM1MTg1Nzk3OTM5MgZDZD',	'2026-04-30 21:02:10',	'2026-04-30 21:02:10'),
(451,	'1264566175874095',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDI1MDg4MzUxNDIzMTMwMjozMjc5MDYzODUwNTgxMjkzNTc5MjEwMDg2OTE3MTgzODk3NgZDZD',	'2026-04-30 21:21:16',	'2026-04-30 21:21:16'),
(452,	'1264566175874095',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDI1MDg4MzUxNDIzMTMwMjozMjc5MDYzODU0NTAzNTk4OTQ2MTYxMjQ1NjgzOTIxNzE1MgZDZD',	'2026-04-30 21:21:17',	'2026-04-30 21:21:17'),
(453,	'979719817768499',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIyMDU2NjI2NzI2MTUyNjozMjc5MTAyNTY4NzkyNjc4MjM3OTUzMTM5MDQ4MTg1ODU2MAZDZD',	'2026-05-01 03:11:04',	'2026-05-01 03:11:04'),
(454,	'1291762436176725',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE3ODI2MDMxODE2MDgzMTozMjc5MTEwNjQ1NTQ0NjQwMzk3NTU0MDQyMzMxNjczMzk1MgZDZD',	'2026-05-01 04:24:03',	'2026-05-01 04:24:03'),
(455,	'1291762436176725',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE3ODI2MDMxODE2MDgzMTozMjc5MTEwNjU4NTQzODg5MzkxNTc3Mjc3ODU2NjM4NTY2NAZDZD',	'2026-05-01 04:24:11',	'2026-05-01 04:24:11'),
(459,	'1408497203919389',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5OTg1Mzk5OTMzMjIzMjozMjc5MTkyNzE2MDIwODEzNjg2NzczMzEyMzc0ODU5MzY2NAZDZD',	'2026-05-01 16:45:33',	'2026-05-01 16:45:33'),
(460,	'1408497203919389',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5OTg1Mzk5OTMzMjIzMjozMjc5MTkyNzU1ODcxODUxNzA5NDYwNjAxNjc4ODU2MTkyMAZDZD',	'2026-05-01 16:45:56',	'2026-05-01 16:45:56'),
(461,	'1408497203919389',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5OTg1Mzk5OTMzMjIzMjozMjc5MTkyNzYxMDY3Njk2MzA2NDkzMzcyMDY2NzQ1NTQ4OAZDZD',	'2026-05-01 16:45:58',	'2026-05-01 16:45:58'),
(462,	'1734501051031838',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDEzMjU2NDQyNjA2MDQ2MjozMjc5MTkzODA1OTc0MTg3Njg3OTY3MjU1ODA1NzY4NDk5MgZDZD',	'2026-05-01 16:55:24',	'2026-05-01 16:55:24'),
(463,	'1734501051031838',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDEzMjU2NDQyNjA2MDQ2MjozMjc5MTk0OTc0NDU0NDM4MDk3MTExMTExODQzMTg0NjQwMAZDZD',	'2026-05-01 17:05:58',	'2026-05-01 17:05:58'),
(464,	'1734501051031838',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDEzMjU2NDQyNjA2MDQ2MjozMjc5MTk0OTc3NzUyNjUxMzczODg2MTIxNjg4Njk0Nzg0MAZDZD',	'2026-05-01 17:05:59',	'2026-05-01 17:05:59'),
(465,	'2386303448483414',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5OTkxMDA0NTk5MzI5NDozMjc5MjAxODI0NTA5NDQzMDM2MDQ5Njc5MDE5NTY2Njk0NAZDZD',	'2026-05-01 18:07:51',	'2026-05-01 18:07:51'),
(466,	'1513465500168398',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5OTk5NzA5NTk4NDU4OTozMjc5MjE4MDcyNzI4Mjk4Mzk0ODk4NDcyMjEyODg5NjAwMAZDZD',	'2026-05-01 20:34:39',	'2026-05-01 20:34:39'),
(467,	'1430348485440916',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIwMDE3MTQ0NTk2NzE1NDozMjc5MjUzNTI5MjQzMzcyMzk4NzM5MDc0Mjk0ODQ3ODk3NgZDZD',	'2026-05-02 01:55:00',	'2026-05-02 01:55:00'),
(468,	'950655084536336',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDM2MzE2MDI4MDI0NTozMjc5Mjg1NTY3ODQ3NTY5NTkxODc2MjI1NTIwNjg0MjM2OAZDZD',	'2026-05-02 06:44:28',	'2026-05-02 06:44:28'),
(469,	'950655084536336',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDM2MzE2MDI4MDI0NTozMjc5Mjg5NzY2ODQ5Mzk3NDE4Mjg4Mjg1MzA0NzUwMDgwMAZDZD',	'2026-05-02 07:22:25',	'2026-05-02 07:22:25'),
(470,	'950655084536336',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDM2MzE2MDI4MDI0NTozMjc5Mjg5NzczNjYwMDE4MzQwNjUwMTgzNDU0MzU5NTUyMAZDZD',	'2026-05-02 07:22:28',	'2026-05-02 07:22:28'),
(471,	'1594472889072284',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIwMDQ1MDkzOTI3MjUzODozMjc5MzA3MDMxMDU2MzYyNzAyMDIwNDEyNjQ4NjEzNDc4NAZDZD',	'2026-05-02 09:58:23',	'2026-05-02 09:58:23'),
(472,	'1430348485440916',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIwMDE3MTQ0NTk2NzE1NDozMjc5MzE0NzE2MjE4ODAxNDU1MDIwNDAxOTUxMjQ0Mjg4MAZDZD',	'2026-05-02 11:07:51',	'2026-05-02 11:07:51'),
(473,	'1430348485440916',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIwMDE3MTQ0NTk2NzE1NDozMjc5MzE0NzIxMjMyMzEyODk5NjA1NDA1MDE4MDk1NjE2MAZDZD',	'2026-05-02 11:07:52',	'2026-05-02 11:07:52'),
(474,	'2223528731805900',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIwMDg3NDQyMjU2MzUyMzozMjc5MzgwNTQ5NzMyNDY4MzQ4NDQ2NjI5NTAyNjQ4MzIwMAZDZD',	'2026-05-02 21:02:38',	'2026-05-02 21:02:38'),
(475,	'2223528731805900',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIwMDg3NDQyMjU2MzUyMzozMjc5MzgwNTYzMzAxNjcxOTI4MTM4NDkxMTU2NzU4NTI4MAZDZD',	'2026-05-02 21:02:47',	'2026-05-02 21:02:47'),
(476,	'2223528731805900',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIwMDg3NDQyMjU2MzUyMzozMjc5MzgwNTcxODgwNDcyMjk5NTQ2NDg1Njk5MzI2NzcxMgZDZD',	'2026-05-02 21:02:50',	'2026-05-02 21:02:50'),
(477,	'26535104462778974',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIwMDkyMzIzMjU1ODY0MjozMjc5MzkxNjY3MzgzNTAyMzQ5ODE2NTU3ODA4NTk1NzYzMgZDZD',	'2026-05-02 22:43:05',	'2026-05-02 22:43:05'),
(478,	'26535104462778974',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIwMDkyMzIzMjU1ODY0MjozMjc5NDE1MzI0MjYxOTAwOTYxMzI2Mjk2MzI1MzE4MjQ2NAZDZD',	'2026-05-03 02:16:50',	'2026-05-03 02:16:50'),
(481,	'1513465500168398',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5OTk5NzA5NTk4NDU4OTozMjc5NDU3NDU4OTYzMjA0MjAwNzUxNzMwNDM4NTk2MTk4NAZDZD',	'2026-05-03 08:37:30',	'2026-05-03 08:37:30'),
(482,	'2037051713520046',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIwMTQwMzkzNTg0MzkwNTozMjc5NDg1MDg1MTk2NjkxMDE4ODczNjQzNjEzMTMzMjA5NgZDZD',	'2026-05-03 12:47:07',	'2026-05-03 12:47:07'),
(483,	'2037051713520046',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIwMTQwMzkzNTg0MzkwNTozMjc5NDg1NDg1NzI3MTY2ODEwNTYwODQwMTY2NzQ4OTc5MgZDZD',	'2026-05-03 12:50:45',	'2026-05-03 12:50:45'),
(484,	'2037051713520046',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIwMTQwMzkzNTg0MzkwNTozMjc5NDg1NDg5MzgzMTk1MjcxNDgyNDA4OTI2ODY0OTk4NAZDZD',	'2026-05-03 12:50:46',	'2026-05-03 12:50:46'),
(485,	'1673045544119728',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDA4NzA4MjMyMDYwMjQ0MDozMjc5NTU4MzIxODk4NDc1MTI0MTg3Njc2OTk1NTkwNTUzNgZDZD',	'2026-05-03 23:48:49',	'2026-05-03 23:48:49'),
(486,	'2160665791347244',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDI0MDM1MzcxNTI4MzgxODozMjc5NTY0NDg5NDM4NDA5NzM4NTUyMjE1Mjk3NDg0MzkwNAZDZD',	'2026-05-04 00:44:32',	'2026-05-04 00:44:32'),
(487,	'2160665791347244',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDI0MDM1MzcxNTI4MzgxODozMjc5NTY0NTA4NjcyNDE2NTc3MTQxOTEzNjczNTMxMzkyMAZDZD',	'2026-05-04 00:44:43',	'2026-05-04 00:44:43'),
(488,	'2160665791347244',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDI0MDM1MzcxNTI4MzgxODozMjc5NTY0NTE2MDA5NTUwMDAyODc4ODUxOTU4MjMwMjIwOAZDZD',	'2026-05-04 00:44:46',	'2026-05-04 00:44:46'),
(489,	'1673045544119728',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDA4NzA4MjMyMDYwMjQ0MDozMjc5NTY4MDY1NDc1Mjg0MDM0NTU1OTY5NjE4NjI3Nzg4OAZDZD',	'2026-05-04 01:16:51',	'2026-05-04 01:16:51'),
(490,	'1673045544119728',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDA4NzA4MjMyMDYwMjQ0MDozMjc5NTY4MDY4OTMyODEwNzcxODQ5MTY0NjM1NzE0MzU1MgZDZD',	'2026-05-04 01:16:52',	'2026-05-04 01:16:52'),
(491,	'1479544320309667',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIzNjk5MDgzODk1Mzg2NTozMjc5NTc2ODUzMTM1Njc1OTY4ODY3NTY2OTYxNzY3MjE5MgZDZD',	'2026-05-04 02:36:14',	'2026-05-04 02:36:14'),
(492,	'987519370881020',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIwMjI3Njk5OTA4OTkzMjozMjc5NjQyNjA4NzE2NzI4MzE0Njc4NDM1MTExOTczNjgzMgZDZD',	'2026-05-04 12:30:21',	'2026-05-04 12:30:21'),
(493,	'988254307098578',	'outbound',	'Hola!! 35€ por reel completo 😁',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTY2ODMzMTM5OTI4MjgwMDozMjc5NjQ2NzY0OTI4MTkzNjI2Mjc5ODQ0NTU3MDQyNDgzMgZDZD',	'2026-05-04 13:07:54',	'2026-05-04 13:07:54'),
(494,	'988254307098578',	'inbound',	'La herramienta que tu vas a dar promo, tiene un costo de $19.99 al mes. 

Si aceptas la promo te puedo dar Acceso de gratis por 6 meses ($120) 


Por 35 necesitaria 2-3 reels con promo',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTY2ODMzMTM5OTI4MjgwMDozMjc5NjQ5ODg4NDE5Mjg1OTE2MzM1ODk2MTIzNzc1Mzg1NgZDZD',	'2026-05-04 13:36:07',	'2026-05-04 13:36:07'),
(495,	'988254307098578',	'outbound',	'Agradezco mucho la oferta, pero por el momento no me es posible aceptar canjes como forma de pago. Si en algún momento quieres trabajar con tarifa directa, con gusto lo vemos.',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTY2ODMzMTM5OTI4MjgwMDozMjc5NzA1Nzc4ODM2MzcwMjkxMDMzNzYxMDYyMzc0NjA0OAZDZD',	'2026-05-04 22:01:05',	'2026-05-04 22:01:05'),
(496,	'988254307098578',	'inbound',	'Okay entiendo',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTY2ODMzMTM5OTI4MjgwMDozMjc5NzExMDc5OTc3MzM2MzAxMDgyMDc0OTE0NjQ1NjA2NAZDZD',	'2026-05-04 22:48:59',	'2026-05-04 22:48:59'),
(497,	'988254307098578',	'inbound',	'Vamos hacerlo por 35',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTY2ODMzMTM5OTI4MjgwMDozMjc5NzExMTA3NzMxMTY5MjcwMjc2MTE4Mzk2NzQ0NDk5MgZDZD',	'2026-05-04 22:49:14',	'2026-05-04 22:49:14'),
(498,	'988254307098578',	'inbound',	'Podemos entrar a una llamada para explicar todo mejor?',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTY2ODMzMTM5OTI4MjgwMDozMjc5NzExMTc2NDQ3NjYzMTk2MTMyMDc3MjE0NjgyMzE2OAZDZD',	'2026-05-04 22:49:52',	'2026-05-04 22:49:52'),
(499,	'988254307098578',	'inbound',	'??',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTY2ODMzMTM5OTI4MjgwMDozMjc5NzQxMTgzNzY0NTk2OTE1ODY1MDkzOTU3MDEyNjg0OAZDZD',	'2026-05-05 03:20:59',	'2026-05-05 03:20:59'),
(500,	'965225202585160',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIxMzE3NDQ2MTMzNTY5NzozMjc5NzQ2MDg3ODg1NjYzMDE4MTI2NTgwMjAxMjkxNzc2MAZDZD',	'2026-05-05 04:05:17',	'2026-05-05 04:05:17'),
(542,	'2124250091644267',	'outbound',	'buenoo que bien que te has ido a poner la crema!!!',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjgwMDI3ODM1MDAxNDc2MDM2OTIzOTY3MzQ0MDA0MzAwOAZDZD',	'2026-05-06 22:30:52',	'2026-05-06 22:30:52'),
(544,	'2124250091644267',	'inbound',	'bien, parece que mehor porfin',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjgwMDI3ODc3NTYwMjA2NDc1NzQ5ODYxNTg1MjY5NTU1MgZDZD',	'2026-05-06 22:31:16',	'2026-05-06 22:31:16'),
(501,	'2124250091644267',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc5NzUwODE2MTI1OTI4NjIwOTMxODcxMzg3NTc1OTEwNAZDZD',	'2026-05-05 04:48:00',	'2026-05-05 04:48:00'),
(502,	'1651764636098454',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDA5MzA2MzIxNjY3NzY5NjozMjc5NzYzNzQwNTM2NTQ4MzQ1NDA2NDEwODAxMDIwOTI4MAZDZD',	'2026-05-05 06:44:46',	'2026-05-05 06:44:46'),
(503,	'1651764636098454',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDA5MzA2MzIxNjY3NzY5NjozMjc5NzYzNzYxMDE5NTYyMDg5MTM0MDk0NDY1NTI1MzUwNAZDZD',	'2026-05-05 06:44:58',	'2026-05-05 06:44:58'),
(504,	'1651764636098454',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDA5MzA2MzIxNjY3NzY5NjozMjc5NzYzNzY1NTU5NzA2MTAwMDIwNDE0NjE1NDkzMDE3NgZDZD',	'2026-05-05 06:45:00',	'2026-05-05 06:45:00'),
(505,	'1653698519139762',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIyNTAxODgyMDE1MjM4NDozMjc5Nzc3NTk5MzI0MzI1NDkzOTQ0NjExODcxOTY4NDYwOAZDZD',	'2026-05-05 08:49:59',	'2026-05-05 08:49:59'),
(506,	'1531637094566212',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIwMzIxNzQ2NTY2MjU1MjozMjc5ODEyMjg5MzI1NTU4MTc3MTg4NjYwNzU3OTc0MjIwOAZDZD',	'2026-05-05 14:03:25',	'2026-05-05 14:03:25'),
(507,	'1531637094566212',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIwMzIxNzQ2NTY2MjU1MjozMjc5ODIwMDQ0NTY1OTAxMTUxNTIxMzM1OTQ4ODE3MjAzMgZDZD',	'2026-05-05 15:13:29',	'2026-05-05 15:13:29'),
(508,	'1531637094566212',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIwMzIxNzQ2NTY2MjU1MjozMjc5ODIwMDQ4MTYwNTQ0MzgyMTg4ODIxNDM0MDIwNjU5MgZDZD',	'2026-05-05 15:13:30',	'2026-05-05 15:13:30'),
(509,	'2124250091644267',	'outbound',	'que cute el niño',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc5ODY1Njk2MzQ5MjE4MDMyNjI0OTI3MTIxODE0MzIzMgZDZD',	'2026-05-05 22:05:57',	'2026-05-05 22:05:57'),
(510,	'2124250091644267',	'inbound',	'hahhahaahah',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc5ODY5ODIwMDI5MjI2NjcwMjg5ODUwOTA5MjIyNTAyNAZDZD',	'2026-05-05 22:43:12',	'2026-05-05 22:43:12'),
(511,	'2124250091644267',	'inbound',	'que nos espachurra elseñor flamencoooo',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjc5ODY5ODMxNzcyNzg3MzQ4NDcxNjAzNTQ2MTM0OTM3NgZDZD',	'2026-05-05 22:43:19',	'2026-05-05 22:43:19'),
(512,	'1716103853081134',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIyMDM1NjMwMzk0OTUzNjozMjc5OTgxNjc4OTQ3MDA5NDgwMjY1MTA0NDY0MjgxNjAwMAZDZD',	'2026-05-06 15:33:51',	'2026-05-06 15:33:51'),
(513,	'2062013671380969',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDMwOTQwNDk3NTA0NzU4MDozMjc5OTgxOTEwMTExODQ3ODg0Mzc4MjEyOTYzMTg4NzM2MAZDZD',	'2026-05-06 15:35:56',	'2026-05-06 15:35:56'),
(514,	'2062013671380969',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDMwOTQwNDk3NTA0NzU4MDozMjc5OTgxOTI1NjA4ODUyNDM0MjYwMzg3MTMxMzQ2MTI0OAZDZD',	'2026-05-06 15:36:06',	'2026-05-06 15:36:06'),
(515,	'2062013671380969',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDMwOTQwNDk3NTA0NzU4MDozMjc5OTgxOTM0MTQ4MzYzMDg1NDY1Nzg3Njk5OTI3NDQ5NgZDZD',	'2026-05-06 15:36:09',	'2026-05-06 15:36:09'),
(516,	'3049791801872573',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDA4MTQzMDMwOTQ4OTozMjc5OTgyMjIwNjQxODc0OTgwODcwOTY0NjQxNzkyMDAwMAZDZD',	'2026-05-06 15:38:44',	'2026-05-06 15:38:44'),
(517,	'927326150296490',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5NDY2MTcxMzE4NDc5NDozMjc5OTgyNDg0Mzk1MDU2MTI4Mjk1MDY0MzEzNjMzMTc3NgZDZD',	'2026-05-06 15:41:07',	'2026-05-06 15:41:07'),
(518,	'927326150296490',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5NDY2MTcxMzE4NDc5NDozMjc5OTgyNTgwMjYwMjg3MzkwMjE2MDIzNzg4Njk2MzcxMgZDZD',	'2026-05-06 15:42:00',	'2026-05-06 15:42:00'),
(519,	'927326150296490',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5NDY2MTcxMzE4NDc5NDozMjc5OTgyNTgzMTQyMDEwMDc5Mjk0ODE5Mzc3ODIwNDY3MgZDZD',	'2026-05-06 15:42:01',	'2026-05-06 15:42:01'),
(543,	'2124250091644267',	'outbound',	'como va el tratamiento??',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjgwMDI3ODQ5NTc0OTQwNjU1NDA3MDU4MDY4NTk2MzI2NAZDZD',	'2026-05-06 22:31:01',	'2026-05-06 22:31:01'),
(612,	'988254307098578',	'outbound',	'y a que hora',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTY2ODMzMTM5OTI4MjgwMDozMjgwNDA3NzE1OTA5NjU1NTU1MDY1MjQyNjI4MTI4NzY4MAZDZD',	'2026-05-09 07:43:06',	'2026-05-09 07:43:06'),
(520,	'977780427913284',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE1OTU2NzU5NjY5Njc1MjozMjc5OTgzNTY3MjIyODE5OTg0MDIyMDc0Nzc1MzU4NjY4OAZDZD',	'2026-05-06 15:50:54',	'2026-05-06 15:50:54'),
(521,	'977780427913284',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE1OTU2NzU5NjY5Njc1MjozMjc5OTgzNTk0NzU4NzEyMDUwNjgyODY5Mzg4OTM1MTY4MAZDZD',	'2026-05-06 15:51:10',	'2026-05-06 15:51:10'),
(522,	'977780427913284',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE1OTU2NzU5NjY5Njc1MjozMjc5OTgzNTk4NzQ0NzIxNDAzNjE4MTc2NzIxMjIzNjgwMAZDZD',	'2026-05-06 15:51:11',	'2026-05-06 15:51:11'),
(523,	'1030463396404533',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIzNDcwNzcyNTg0ODA1MTozMjc5OTg1ODYzODk4MTg2NjE5MzgyMzM0ODkzNzQ1NzY2NAZDZD',	'2026-05-06 16:11:39',	'2026-05-06 16:11:39'),
(524,	'3407022642812070',	'inbound',	'Hermano, ofreces mentoría 1-1?',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIwNDIzMjU2MjIyNzcwOTozMjc5OTg5NzE0NzkzMzgzMDY0NjkzNzQyMzkzNjc0OTU2OAZDZD',	'2026-05-06 16:46:29',	'2026-05-06 16:46:29'),
(525,	'1952149915426187',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIwNDI0ODc3MjIyNjA4ODozMjc5OTkyMzc0MDgwNzIzNzE4NDQ3OTQzNTE3NjI4MDA2NAZDZD',	'2026-05-06 17:10:29',	'2026-05-06 17:10:29'),
(526,	'2337910950064402',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE0NDc5NTAyNDgzNTM0OTozMjc5OTk2NTI0NDgyMDg4MTQ2NzgwNTM1NTg2NTAxNDI3MgZDZD',	'2026-05-06 17:47:59',	'2026-05-06 17:47:59'),
(527,	'2337910950064402',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE0NDc5NTAyNDgzNTM0OTozMjc5OTk2NTYzNDgzODQzNjA2MzM3NDU5MjQ2OTYzMDk3NgZDZD',	'2026-05-06 17:48:20',	'2026-05-06 17:48:20'),
(528,	'2337910950064402',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE0NDc5NTAyNDgzNTM0OTozMjc5OTk2NTY2NDg2NjIzMDUzMzk5OTczNzY4NTY3MTkzNgZDZD',	'2026-05-06 17:48:21',	'2026-05-06 17:48:21'),
(529,	'1002933439060329',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5NTc3MjA2MzA3NzkxOTozMjgwMDEzNDgzNTcxMTMxMzM1MjAwODE1NTY4MDIxMDk0NAZDZD',	'2026-05-06 20:21:12',	'2026-05-06 20:21:12'),
(530,	'1365010178956962',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4OTk4MjczMDMxOTM1OTozMjgwMDE2NzAxMjY5MTE0NzMxMDQ0MjI2MzcxMDAwNzI5NgZDZD',	'2026-05-06 20:50:16',	'2026-05-06 20:50:16'),
(531,	'3407022642812070',	'outbound',	'Hola Jorge!

Si ofrezco mentorias, qué necesitas?',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIwNDIzMjU2MjIyNzcwOTozMjgwMDIwNTg3MTI0NTM5OTYyMDEzMDEzOTMyNTU5NTY0OAZDZD',	'2026-05-06 21:25:23',	'2026-05-06 21:25:23'),
(532,	'2124250091644267',	'inbound',	'deja el instagram!!',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjgwMDI3NjAwNzYzMDExNjIwNDU4ODU1NDE5NTU2NjU5MgZDZD',	'2026-05-06 22:28:46',	'2026-05-06 22:28:46'),
(533,	'2124250091644267',	'inbound',	'he wntraso porqu he visto tu noti',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjgwMDI3NjMzODk4OTAxNjg5NDEyMTM3NzI5Mjg3NzgyNAZDZD',	'2026-05-06 22:29:04',	'2026-05-06 22:29:04'),
(534,	'2124250091644267',	'inbound',	'y luego he visto 2 reels',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjgwMDI3NjQ1NzQ5MjQxMzQ1NjY0NTU4MTA1NzI5NDMzNgZDZD',	'2026-05-06 22:29:11',	'2026-05-06 22:29:11'),
(535,	'2124250091644267',	'inbound',	'y me he dado cuenta',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjgwMDI3NjUxNDE5MDA4NjIzMzkyNjMwMDY4MDA2MDkyOAZDZD',	'2026-05-06 22:29:13',	'2026-05-06 22:29:13'),
(536,	'2124250091644267',	'outbound',	'pero si estabas durmiendooo',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjgwMDI3NjU3NjQ3NDgzNTA2OTI3NTg3NDQ1ODA3NTEzNgZDZD',	'2026-05-06 22:29:16',	'2026-05-06 22:29:16'),
(537,	'2124250091644267',	'inbound',	'tenia q ir al vaño a onerme la crema',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjgwMDI3NjgzMzQ0OTQ1Mzg5MDg2Mzc3NTgxMDA2MDI4OAZDZD',	'2026-05-06 22:29:30',	'2026-05-06 22:29:30'),
(538,	'2124250091644267',	'inbound',	'i lavarme losdientes',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjgwMDI3Njk0MzMzODk0MDM5Mzk4NDQ5MzY0MjMxNzgyNAZDZD',	'2026-05-06 22:29:36',	'2026-05-06 22:29:36'),
(539,	'2124250091644267',	'outbound',	'aaaa',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjgwMDI3Njk2MDI0NTg2MDk1Mjg4NTIxNDE0NjcyMzg0MAZDZD',	'2026-05-06 22:29:37',	'2026-05-06 22:29:37'),
(540,	'2124250091644267',	'inbound',	'pero llevaba ocupado el baño como 2 horas',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjgwMDI3NzEyNjQ5MTQyMzQyNjUyOTY5ODEyNDkyMjg4MAZDZD',	'2026-05-06 22:29:46',	'2026-05-06 22:29:46'),
(541,	'2124250091644267',	'inbound',	'y me he desprtado de golpe al escuhar la puerta',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjgwMDI3NzMxNDgyNTc2Mjg5MDA3NjU3OTA0MjQyNjg4MAZDZD',	'2026-05-06 22:29:56',	'2026-05-06 22:29:56'),
(662,	'1656399838684616',	'inbound',	'hola bro',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDA4NzE3MzUxNzI2ODA1NDozMjg0Mzc3NjMwMTA0MDU5Njg2MDQ2ODA5ODQ1ODcxNDExMgZDZD',	'2026-06-03 05:31:22',	'2026-06-03 05:31:22'),
(545,	'2124250091644267',	'inbound',	'pedon si antes no me he enterado de ko que me gas contado',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjgwMDI3ODkzNjI4MTU2MjAxNDU3NDIwMDg1NDkzNzYwMAZDZD',	'2026-05-06 22:31:24',	'2026-05-06 22:31:24'),
(546,	'2124250091644267',	'inbound',	'he desconectado mucho soko escuchando el timbre de tu voz',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjgwMDI3OTA5OTYwMDA1MDQ3ODgzNDY3NDMxMTM2NDYwOAZDZD',	'2026-05-06 22:31:33',	'2026-05-06 22:31:33'),
(547,	'2124250091644267',	'outbound',	'que bieeeen',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjgwMDI3OTY2NjY5Mzc4NTk0OTMwMTQxMDIyNDkzMDgxNgZDZD',	'2026-05-06 22:32:04',	'2026-05-06 22:32:04'),
(548,	'2124250091644267',	'outbound',	'no paza nadaaa',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjgwMDI3OTc1NzA0MzU3NzIzOTA4OTM1OTIxNzQ5MTk2OAZDZD',	'2026-05-06 22:32:09',	'2026-05-06 22:32:09'),
(549,	'2124250091644267',	'inbound',	'etes le mejor',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjgwMDI4MDIxNzcxMzI2ODQ0MTYxMDYwMTA4NDQ4NTYzMgZDZD',	'2026-05-06 22:32:34',	'2026-05-06 22:32:34'),
(550,	'2124250091644267',	'inbound',	'mandame una foo',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjgwMDI4MDMxNjAyMDY1MzA4MzQwMzUyMzg3MjI2MDA5NgZDZD',	'2026-05-06 22:32:39',	'2026-05-06 22:32:39'),
(551,	'2124250091644267',	'inbound',	'q me gusta verye',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjgwMDI4MDM4Njg4NTI1OTI4ODU5NjUxNTc1MDE1MDE0NAZDZD',	'2026-05-06 22:32:43',	'2026-05-06 22:32:43'),
(552,	'2124250091644267',	'inbound',	'bua eres guapo',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjgwMDI4MTYwMzQ5NTQ1NzUyODc1NDk1MjA4MjU1NDg4MAZDZD',	'2026-05-06 22:33:49',	'2026-05-06 22:33:49'),
(553,	'2124250091644267',	'inbound',	':)',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjgwMDI4MTY0OTg3ODk0Njk1MTg3MDIyODk4MTYxMjU0NAZDZD',	'2026-05-06 22:33:51',	'2026-05-06 22:33:51'),
(554,	'2124250091644267',	'outbound',	'y tu eres guapa tambien',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjgwMDI4MjE4ODM1MjUyMjA5ODQ4ODQ0ODE0Mzg1MTUyMAZDZD',	'2026-05-06 22:34:20',	'2026-05-06 22:34:20'),
(555,	'2124250091644267',	'inbound',	'graciass',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjgwMDI4MjM2MzM5NTM3MzcxNDM3MzE2NDcwNjgyNDE5MgZDZD',	'2026-05-06 22:34:30',	'2026-05-06 22:34:30'),
(556,	'2124250091644267',	'inbound',	'con mis nuevos pendientitos',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjgwMDI4MjQ3NTYyNTQ1Njg5MjU0MjQ0NTI4NjMyNjI3MgZDZD',	'2026-05-06 22:34:37',	'2026-05-06 22:34:37'),
(557,	'2124250091644267',	'inbound',	'el otro dia me compre dos pares de pendientes y un anillo siper bonito',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjgwMDI4MjcwMDYwNjU0MDg1NDc3ODQ5MDQ3MzQxNDY1NgZDZD',	'2026-05-06 22:34:48',	'2026-05-06 22:34:48'),
(558,	'2124250091644267',	'outbound',	'alaaa no mabia fijadooo',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjgwMDI4Mjg0Mjk5NzIxNjYxNDE1OTU1MTMzMTA0MTI4MAZDZD',	'2026-05-06 22:34:56',	'2026-05-06 22:34:56'),
(559,	'2124250091644267',	'outbound',	'que son pequess',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjgwMDI4Mjk0ODI4NjYwMTY1NDEzMTE3MDg1NzcxMzY2NAZDZD',	'2026-05-06 22:35:02',	'2026-05-06 22:35:02'),
(560,	'2124250091644267',	'inbound',	'me ire comprando mas anills y pendients',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjgwMDI4Mjk4MTE2NDcxMzIzMjA0OTYyMTE1MTI1MjQ4MAZDZD',	'2026-05-06 22:35:03',	'2026-05-06 22:35:03'),
(561,	'2124250091644267',	'inbound',	'son corazones pequenios',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjgwMDI4MzEyNTE3MTkzMjUxNDg0MjA3MTE0NTY0NDAzMgZDZD',	'2026-05-06 22:35:11',	'2026-05-06 22:35:11'),
(562,	'2124250091644267',	'outbound',	'molan!!',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjgwMDI4MzE3OTQxNjI4MDU2NDAzOTc4ODk1MTI0MDcwNAZDZD',	'2026-05-06 22:35:14',	'2026-05-06 22:35:14'),
(563,	'2124250091644267',	'inbound',	'graciasss',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjgwMDI4NDUwMDY2NDY3NTMzMTYyMzgyMzkyODcyMTQwOAZDZD',	'2026-05-06 22:36:26',	'2026-05-06 22:36:26'),
(564,	'2124250091644267',	'inbound',	'mañana si quieres te eneño los otros pendientes y el anillo',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjgwMDI4NDc0MDA5Mjg0MzQyNDAxOTU2ODMzMTMyNTQ0MAZDZD',	'2026-05-06 22:36:39',	'2026-05-06 22:36:39'),
(565,	'2124250091644267',	'inbound',	'estas mirando reels aun',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjgwMDI4NTE4NzAyMzI3MDUxMzIzMzQyMDE4Nzg2MDk5MgZDZD',	'2026-05-06 22:37:03',	'2026-05-06 22:37:03'),
(566,	'2124250091644267',	'inbound',	'y yo tambien',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjgwMDI4NTIyNTk0MzgxNjAyNjY4MDI0NDkxODI4ODM4NAZDZD',	'2026-05-06 22:37:05',	'2026-05-06 22:37:05'),
(567,	'2124250091644267',	'inbound',	'paremos',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjgwMDI4NTMyNjcwOTMzOTk5Njc1OTQwNzcxNjIwNDU0NAZDZD',	'2026-05-06 22:37:11',	'2026-05-06 22:37:11'),
(568,	'2124250091644267',	'inbound',	'no nos hace bien',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjgwMDI4NTQwMTA1MzkyNDQ3MTQ1NzcwNjUwNjQ1Mjk5MgZDZD',	'2026-05-06 22:37:15',	'2026-05-06 22:37:15'),
(569,	'2124250091644267',	'outbound',	'vamos a mimir',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjgwMDI4NTczMjgzOTk0MTA3MzI3MzIwMDU2MTg4MTA4OAZDZD',	'2026-05-06 22:37:33',	'2026-05-06 22:37:33'),
(570,	'2124250091644267',	'outbound',	'bona niiiit 😁☺️',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjgwMDI4NjA4MzE4MzY5NTgwNzg4OTc1NjYwNTM4MjY1NgZDZD',	'2026-05-06 22:37:51',	'2026-05-06 22:37:51'),
(571,	'2124250091644267',	'inbound',	'vona nit guapuuuu',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjgwMDI4NjU2MjE3MzI5MTI3MTg2OTcyMzIxMTQ2NDcwNAZDZD',	'2026-05-06 22:38:18',	'2026-05-06 22:38:18'),
(572,	'2124250091644267',	'inbound',	'per si encara no has sortit: surt ara mateix',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjgwMDI4Njk5MjM0MTkzNjc4NDU1NDgwMTMxNTcwODkyOAZDZD',	'2026-05-06 22:38:41',	'2026-05-06 22:38:41'),
(592,	'1967388964153557',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDEyNzc3NDExNjU0MDIyMTozMjgwMzE2MjQ1NDMyNDc0NDg2Nzc0ODI4MDQ4Njg1NDY1NgZDZD',	'2026-05-08 17:56:40',	'2026-05-08 17:56:40'),
(573,	'766056946333038',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MTU3ODUwNjgyNjQ0ODozMjgwMDcxMzIwMDQzOTM0NDE2OTI3MTY5Nzg1NjI2NjI0MAZDZD',	'2026-05-07 05:03:45',	'2026-05-07 05:03:45'),
(574,	'1595817744894109',	'inbound',	'Holaa me podrías ayudar a utilizar la herramienta?',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIwNDg3NzMzMjE2MzIzMjozMjgwMTE3NjM4MDM4ODA1MTMwNDAxNTUyOTg3Nzk2Mjc1MgZDZD',	'2026-05-07 12:02:17',	'2026-05-07 12:02:17'),
(575,	'766056946333038',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MTU3ODUwNjgyNjQ0ODozMjgwMTE5MDMzOTMwMDYwODQ1NjU4MTQwNzIxMzM1NTAwOAZDZD',	'2026-05-07 12:14:52',	'2026-05-07 12:14:52'),
(576,	'766056946333038',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MTU3ODUwNjgyNjQ0ODozMjgwMTE5MDQzNTE3NDgzMDY2MTU2Mzg5MjcyMzg3NTg0MAZDZD',	'2026-05-07 12:14:56',	'2026-05-07 12:14:56'),
(577,	'3049791801872573',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDA4MTQzMDMwOTQ4OTozMjgwMTIxMjAyOTQwMDc1NDcxMzU4NDI5ODQ4NDU2Mzk2OAZDZD',	'2026-05-07 12:34:27',	'2026-05-07 12:34:27'),
(578,	'3049791801872573',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDA4MTQzMDMwOTQ4OTozMjgwMTIxMjA2MTkyNTAwMjM5OTkzNjc3ODQ0OTQ1MzA1NgZDZD',	'2026-05-07 12:34:29',	'2026-05-07 12:34:29'),
(579,	'2195321274609339',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTY1MzM5OTIxNzQ1NTkyMDozMjgwMTcyMzM2MTk4MTQ5Mzg1ODAyMjAxOTM0MTIyMTg4OAZDZD',	'2026-05-07 20:16:26',	'2026-05-07 20:16:26'),
(580,	'2437569943421851',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIwNTM5MTI4MjExMTgzNzozMjgwMjExMTg0ODM5MTI4ODA4OTc2MTkzOTk1MDkyNzg3MgZDZD',	'2026-05-08 02:07:26',	'2026-05-08 02:07:26'),
(581,	'3407022642812070',	'inbound',	'No de nada hermano, igualmente por tu amabilidad y humildad de responder.

Mira te voy a crear el videito que te había prometido y después nos unimos a una llamada hermano, te parece?',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIwNDIzMjU2MjIyNzcwOTozMjgwMjk5OTQwNTczNTE0OTQ5NTUwNTQ4MDAxMjc5MTgwOAZDZD',	'2026-05-08 15:29:22',	'2026-05-08 15:29:22'),
(582,	'1504810157681883',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIwNTkzNTgzODcyNDA0ODozMjgwMzAwNDIzNTgwNzg1NDQ3MzQyNzUxNzU1OTUzNzY2NAZDZD',	'2026-05-08 15:33:43',	'2026-05-08 15:33:43'),
(583,	'1405176590879707',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE0OTYyMTcyMTAyNDg5MjozMjgwMzAwNDczNTMxNzc3NDA2NTY5ODY1Mjc2OTIyMjY1NgZDZD',	'2026-05-08 15:34:10',	'2026-05-08 15:34:10'),
(584,	'2386303448483414',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5OTkxMDA0NTk5MzI5NDozMjgwMzA2NDMyNTY0Nzk5MDY5Njc2Mjk3MDQwOTUzMzQ0MAZDZD',	'2026-05-08 16:28:00',	'2026-05-08 16:28:00'),
(585,	'3407022642812070',	'outbound',	'Perfecto Jorge! Quedo pendiente',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIwNDIzMjU2MjIyNzcwOTozMjgwMzA2NjExNjkwMzQ0OTU4MjA5ODU0ODA5MDk5NDY4OAZDZD',	'2026-05-08 16:29:38',	'2026-05-08 16:29:38'),
(586,	'1300599672116994',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4MDA1MzA2Nzk4MjIxODozMjgwMzEyNDIwNzg2NDgwMTk0MTkyNDU2MDAxODM0MTg4OAZDZD',	'2026-05-08 17:22:06',	'2026-05-08 17:22:06'),
(587,	'2004548370132749',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4NTA4MzQ3NzQ3NTk1MTozMjgwMzEzMjcwMTU1MjU3ODcyMzM1Mzk1ODY4Mzc3MDg4MAZDZD',	'2026-05-08 17:29:47',	'2026-05-08 17:29:47'),
(588,	'2004548370132749',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4NTA4MzQ3NzQ3NTk1MTozMjgwMzEzMzE0MDMxMjI3ODc3OTUzNTE5NjU4NTcyMTg1NgZDZD',	'2026-05-08 17:30:11',	'2026-05-08 17:30:11'),
(589,	'2004548370132749',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4NTA4MzQ3NzQ3NTk1MTozMjgwMzEzMzIyODQ5NjI1NjI5NDM3Mjk4MDgzMjYwMDA2NAZDZD',	'2026-05-08 17:30:15',	'2026-05-08 17:30:15'),
(590,	'1967388964153557',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDEyNzc3NDExNjU0MDIyMTozMjgwMzE2MjI2NDY2MzU2Nzk5NjQ2NzYxODk0MDcxNTAwOAZDZD',	'2026-05-08 17:56:29',	'2026-05-08 17:56:29'),
(591,	'1967388964153557',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDEyNzc3NDExNjU0MDIyMTozMjgwMzE2MjQxMDI2ODQyMjg4OTk5NTkwNTc4MTQ2NTA4OAZDZD',	'2026-05-08 17:56:39',	'2026-05-08 17:56:39'),
(593,	'1435961061338713',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE0MDg3Nzk4NTIyOTgzNDozMjgwMzE2OTkwMzk3MzE2Mzc0NTA3NDI4OTc4OTg5NDY1NgZDZD',	'2026-05-08 18:03:23',	'2026-05-08 18:03:23'),
(594,	'1767132208005807',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE0MjYxNDE5ODM4OTU0NjozMjgwMzIzMzk1NjE4OTY0MzYyNzE3MjIzMDI5NDY2NzI2NAZDZD',	'2026-05-08 19:01:16',	'2026-05-08 19:01:16'),
(595,	'1414362883705926',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5OTM0MTQ3MjcxOTkwOTozMjgwMzI3ODkxMjg3NzQ5ODQ5NDYzOTQyODI2MDA2OTM3NgZDZD',	'2026-05-08 19:41:53',	'2026-05-08 19:41:53'),
(596,	'1414362883705926',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5OTM0MTQ3MjcxOTkwOTozMjgwMzI3OTAwNTQzNDg4NTQzNDcwNDQ5NDEzMjcyMzcxMgZDZD',	'2026-05-08 19:41:59',	'2026-05-08 19:41:59'),
(597,	'1414362883705926',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5OTM0MTQ3MjcxOTkwOTozMjgwMzI3OTA0MTk0OTY2MTkyNjI5MDM0MDI3MDA0NzIzMgZDZD',	'2026-05-08 19:42:00',	'2026-05-08 19:42:00'),
(598,	'1564580968426305',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE3NzYyMzU3NDg5NDkyNDozMjgwMzMzOTQ2MzU3MDE1MTYwMTAxMDY1ODM0MzEyNDk5MgZDZD',	'2026-05-08 20:36:35',	'2026-05-08 20:36:35'),
(599,	'1564580968426305',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE3NzYyMzU3NDg5NDkyNDozMjgwMzM0MDM2Mjg3NDMwNzkxNDE5NjcyMzk2NjE0ODYwOAZDZD',	'2026-05-08 20:37:25',	'2026-05-08 20:37:25'),
(600,	'1564580968426305',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE3NzYyMzU3NDg5NDkyNDozMjgwMzM0MDQwNTQ0OTg5MTI5ODQwODM1OTI1Mzc3MDI0MAZDZD',	'2026-05-08 20:37:26',	'2026-05-08 20:37:26'),
(601,	'1767132208005807',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE0MjYxNDE5ODM4OTU0NjozMjgwMzM0OTAzNTg2NjcyNDQ4ODM0ODEwNDMyMzQ5Nzk4NAZDZD',	'2026-05-08 20:45:15',	'2026-05-08 20:45:15'),
(602,	'1767132208005807',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE0MjYxNDE5ODM4OTU0NjozMjgwMzM0OTA3NDM3Mzg0MTU3MzYxNDk1MDU4MzEwNzU4NAZDZD',	'2026-05-08 20:45:16',	'2026-05-08 20:45:16'),
(603,	'2030094637888489',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIzNjI5NDg3OTAyNjc1MjozMjgwMzM5NTA4Mjk2NjMwMzI5NjM1NzUyMTY5MDcyMjMwNAZDZD',	'2026-05-08 21:26:51',	'2026-05-08 21:26:51'),
(604,	'731319353305758',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4OTE2OTA0NzA2NzM5NDozMjgwMzQ1NjU2NjQzMjM4NzEwMTE2MzQzNzY5MDk3ODMwNAZDZD',	'2026-05-08 22:22:23',	'2026-05-08 22:22:23'),
(605,	'731319353305758',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4OTE2OTA0NzA2NzM5NDozMjgwMzQ1ODQ5OTI3MzY3MTg1NTIwMDA1NDc4MzUwODQ4MAZDZD',	'2026-05-08 22:24:08',	'2026-05-08 22:24:08'),
(606,	'731319353305758',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4OTE2OTA0NzA2NzM5NDozMjgwMzQ1ODg3NzcyOTM0MjIyMDk0NjI4MjAxMjIxMzI0OAZDZD',	'2026-05-08 22:24:29',	'2026-05-08 22:24:29'),
(607,	'3407022642812070',	'inbound',	'https://www.tella.tv/video/builds-video-5fck',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIwNDIzMjU2MjIyNzcwOTozMjgwMzQ4OTc4NjYwMTExMDI3NDkyNjYyOTkxNTQ1OTU4NAZDZD',	'2026-05-08 22:52:25',	'2026-05-08 22:52:25'),
(608,	'3407022642812070',	'inbound',	'Hermano te paso el video por favor me dejas saber cualquier cosa, espero de te aporte valor',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIwNDIzMjU2MjIyNzcwOTozMjgwMzQ4OTk3ODUyNTUxODE3NjYxMDcxNjM0OTM2NjI3MgZDZD',	'2026-05-08 22:52:35',	'2026-05-08 22:52:35'),
(609,	'1023415173480195',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIwNjIxNTAzMjAyOTQ2MjozMjgwMzUyMDM5NTYwMjUzMjg3OTcwODIxMTkxMDgwMzQ1NgZDZD',	'2026-05-08 23:20:04',	'2026-05-08 23:20:04'),
(610,	'988254307098578',	'inbound',	'Hello????',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTY2ODMzMTM5OTI4MjgwMDozMjgwNDAxMjk5NzQzMDQ4ODY3MTM1OTUxOTYyMTY0NDI4OAZDZD',	'2026-05-09 06:45:08',	'2026-05-09 06:45:08'),
(611,	'988254307098578',	'outbound',	'Holaa!!
dime cuando te va bien hacer una llamada',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTY2ODMzMTM5OTI4MjgwMDozMjgwNDA3NzExODc5NDU3MDI2NzAxMzY0MDY0OTQ0MTI4MAZDZD',	'2026-05-09 07:43:04',	'2026-05-09 07:43:04'),
(613,	'2223528731805900',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIwMDg3NDQyMjU2MzUyMzozMjgwNDM3Nzk0NTYxNzI3NjQ5MTI1ODA1MDA3MTQ5NDY1NgZDZD',	'2026-05-09 12:14:52',	'2026-05-09 12:14:52'),
(614,	'2223528731805900',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIwMDg3NDQyMjU2MzUyMzozMjgwNDM3ODA5MzE3NTIzNTc1MzgyMjU1NjgxODI0MzU4NAZDZD',	'2026-05-09 12:15:00',	'2026-05-09 12:15:00'),
(615,	'2223528731805900',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIwMDg3NDQyMjU2MzUyMzozMjgwNDM3ODEyMzI5OTI2Njg4ODI4MDI0NDc2NTA2NTIxNgZDZD',	'2026-05-09 12:15:01',	'2026-05-09 12:15:01'),
(616,	'1314021830827971',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDI4ODQwMjEwNzE0NzMwODozMjgwNDYyNTkxMTkyMDE1MTIzODkyMTMyMDY0MDAyMDQ4MAZDZD',	'2026-05-09 15:58:54',	'2026-05-09 15:58:54'),
(617,	'1314021830827971',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDI4ODQwMjEwNzE0NzMwODozMjgwNDYyNzA5NDkyNzQyODQzMzAxNzExMDk3Njc5MDUyOAZDZD',	'2026-05-09 15:59:58',	'2026-05-09 15:59:58'),
(618,	'1314021830827971',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDI4ODQwMjEwNzE0NzMwODozMjgwNDYyNzEyNDU4NTgwODQwNjgyMjE0ODcxMjE2OTQ3MgZDZD',	'2026-05-09 15:59:59',	'2026-05-09 15:59:59'),
(619,	'2194947194625648',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIwNjg4NzIxNTI5NTU3NzozMjgwNDY5MzQwNzI5MjIyOTUyOTQwNjA0MTIzOTg0NjkxMgZDZD',	'2026-05-09 16:59:53',	'2026-05-09 16:59:53'),
(620,	'2194947194625648',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIwNjg4NzIxNTI5NTU3NzozMjgwNDcwOTA4NDc2OTk4MzU0Nzg4MzU0Mzc2NDkyNjQ2NAZDZD',	'2026-05-09 17:14:03',	'2026-05-09 17:14:03'),
(621,	'2194947194625648',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIwNjg4NzIxNTI5NTU3NzozMjgwNDcwOTEyMDc5ODQ0ODUyNTQ1NDE4NDk5Mjk5NzM3NgZDZD',	'2026-05-09 17:14:05',	'2026-05-09 17:14:05'),
(622,	'908334698631729',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIwNjk0ODQwMTk1NjEyNTozMjgwNDc4OTcwMTkyNjc4MTU1MTQzMjM4NTExMDczNjg5NgZDZD',	'2026-05-09 18:26:53',	'2026-05-09 18:26:53'),
(623,	'1489748942945257',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIwNjk1MTMyMTk1NTgzMzozMjgwNDc5NDk5ODY3NzY4ODEwNTA1MjQ4NzA5NTk0MzE2OAZDZD',	'2026-05-09 18:31:40',	'2026-05-09 18:31:40'),
(624,	'908334698631729',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIwNjk0ODQwMTk1NjEyNTozMjgwNDc5NzUxODU2OTc0MjY4MDgxMjIxMzgzNzQ5NjMyMAZDZD',	'2026-05-09 18:33:57',	'2026-05-09 18:33:57'),
(625,	'908334698631729',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIwNjk0ODQwMTk1NjEyNTozMjgwNDc5NzU1NTAxNjIyOTMyNTgzNzE4NzIxNDczNzQwOAZDZD',	'2026-05-09 18:33:59',	'2026-05-09 18:33:59'),
(626,	'988254307098578',	'inbound',	'Puedo hoy a las 6 EST',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTY2ODMzMTM5OTI4MjgwMDozMjgwNDgwMTA2NDU5NjM5NDg3NDU5NTQzODY2MTQ2ODE2MAZDZD',	'2026-05-09 18:37:09',	'2026-05-09 18:37:09'),
(627,	'988254307098578',	'inbound',	'Suena bien para ti?',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTY2ODMzMTM5OTI4MjgwMDozMjgwNDgwMTIwOTUxNjM0MDYwNzQxMDk2MzU2MDI2Nzc3NgZDZD',	'2026-05-09 18:37:18',	'2026-05-09 18:37:18'),
(628,	'988254307098578',	'inbound',	'Pasame un email para enviarte el Google Video call',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTY2ODMzMTM5OTI4MjgwMDozMjgwNDgwMTQ5MDEwNTkwOTM0MzA5NTU0Nzg5NDk1NjAzMgZDZD',	'2026-05-09 18:37:32',	'2026-05-09 18:37:32'),
(629,	'988254307098578',	'outbound',	'Okeyy dale, mi correo es hola@joanpaneque.com',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTY2ODMzMTM5OTI4MjgwMDozMjgwNDgzNTExMzI2ODczMzY5ODUxOTY5NzkwMzg0NTM3NgZDZD',	'2026-05-09 19:07:55',	'2026-05-09 19:07:55'),
(630,	'988254307098578',	'outbound',	'para confirmar, 6 EST es de aquí 2 horas y 52 minutos en el momento que escribo esto?',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTY2ODMzMTM5OTI4MjgwMDozMjgwNDgzNjMwMzU5MDI1NTU5ODMwNTc2NzcxMzY2OTEyMAZDZD',	'2026-05-09 19:08:59',	'2026-05-09 19:08:59'),
(631,	'988254307098578',	'inbound',	'Correcto bro',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTY2ODMzMTM5OTI4MjgwMDozMjgwNDg1MzE2NjY0NzUwMDgwNDUxNzEyMDQ1Mjg1Mzc2MAZDZD',	'2026-05-09 19:24:14',	'2026-05-09 19:24:14'),
(632,	'988254307098578',	'inbound',	'Podemos hacerlo mañana en la mañana?',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTY2ODMzMTM5OTI4MjgwMDozMjgwNDg1NjQ4NjU0NzI0OTUyNzkyNTgzMTI5MTEwOTM3NgZDZD',	'2026-05-09 19:27:14',	'2026-05-09 19:27:14'),
(633,	'988254307098578',	'outbound',	'a que hora?',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTY2ODMzMTM5OTI4MjgwMDozMjgwNDg5MjQzMjM0NTg3MzY1MDM2MDYxMjgwODU1NjU0NAZDZD',	'2026-05-09 19:59:43',	'2026-05-09 19:59:43'),
(634,	'3407022642812070',	'inbound',	'Dale mi hermano estoy atento 🫡🫡',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIwNDIzMjU2MjIyNzcwOTozMjgwNDkxNDAwNTE5ODEwODc0NjQ5NTk3MjM5ODMzMzk1MgZDZD',	'2026-05-09 20:19:12',	'2026-05-09 20:19:12'),
(663,	'1656399838684616',	'inbound',	'recién me acabo de registrar en la pagina y como te habia dicho, como podria buscar cuentas o clientes en el área de ingenieria en sonido',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDA4NzE3MzUxNzI2ODA1NDozMjg0Mzc3NzM1MjQ4NTIzNDE1MjI2NTUyMzkzMTM4MTc2MAZDZD',	'2026-06-03 05:32:18',	'2026-06-03 05:32:18'),
(635,	'984835364241446',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE2NjIxNzM3OTM2MDkyNDozMjgwNTE2OTU5OTY2Mzg1NzQzNTA2NTgxMTYwODc5NzE4NAZDZD',	'2026-05-10 00:10:07',	'2026-05-10 00:10:07'),
(636,	'984835364241446',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE2NjIxNzM3OTM2MDkyNDozMjgwNTE2OTk0NTQwMzQzMzk3NjA5Mjk3OTUzNTgwNjQ2NAZDZD',	'2026-05-10 00:10:27',	'2026-05-10 00:10:27'),
(637,	'984835364241446',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE2NjIxNzM3OTM2MDkyNDozMjgwNTE2OTk4NzA3MjQ3MDU2OTU0NjIzMjYxODgxMTM5MgZDZD',	'2026-05-10 00:10:28',	'2026-05-10 00:10:28'),
(638,	'988254307098578',	'inbound',	'10Am',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTY2ODMzMTM5OTI4MjgwMDozMjgwNTIwMzkwNzM1MjU5Mjk0ODM3NjUxMzkyMzc3NjUxMgZDZD',	'2026-05-10 00:41:07',	'2026-05-10 00:41:07'),
(639,	'988254307098578',	'outbound',	'en la hora de que pais?',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTY2ODMzMTM5OTI4MjgwMDozMjgwNTc2OTY4MjAyODc0Mzc2Njc1NTUwNTAwMjc3NDUyOAZDZD',	'2026-05-10 09:12:18',	'2026-05-10 09:12:18'),
(640,	'988254307098578',	'outbound',	'es que yo soy de españa',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTY2ODMzMTM5OTI4MjgwMDozMjgwNTc2OTczNjQxMjg2Mjc5NTc5OTcyMDA4MDk2NTYzMgZDZD',	'2026-05-10 09:12:21',	'2026-05-10 09:12:21'),
(641,	'1326558189317534',	'outbound',	'Analizo tus procesos, identifico lo que se puede automatizar y lo implemento. También te ayudo a entender el alcance real de la IA para que tomes mejores decisiones tecnológicas sin depender de nadie.',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDEzMzEzMjE5MjY3MTA4MDozMjgwNjI2NTQyOTk5MTEwNzQ4MDAxMTQ4ODI3NjUxMjc2OAZDZD',	'2026-05-10 16:40:13',	'2026-05-10 16:40:13'),
(642,	'1442204350502743',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5NjYzMTI4NjMyMTE3MDozMjgwNjQxODQwODkwNTc2ODU0Mzg1MDk5MzY2ODg0OTY2NAZDZD',	'2026-05-10 18:58:26',	'2026-05-10 18:58:26'),
(643,	'1442204350502743',	'outbound',	'https://mailerfind.com/',	NULL,	'2026-05-10 18:58:26',	'2026-05-10 18:58:26'),
(644,	'2124250091644267',	'inbound',	'yo',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjgwNzYwMzUzNDI2Njc4MzQyMzI2MjU5MTYzMTIyODkyOAZDZD',	'2026-05-11 12:49:12',	'2026-05-11 12:49:12'),
(645,	'2124250091644267',	'outbound',	'en verdad es mega util',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjgwNzYwMzc0MTIxODQ0NDAwMjk2ODYxNjM4ODUyNjA4MAZDZD',	'2026-05-11 12:49:23',	'2026-05-11 12:49:23'),
(646,	'3407022642812070',	'inbound',	'Hermano como vas? pasaba por aquí para saber si pudiste ver el video que te parecio?',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIwNDIzMjU2MjIyNzcwOTozMjgwODAzMjg0NjgxMTQ2NTg4MDE5NDYwMTU4MTU0MzQyNAZDZD',	'2026-05-11 19:17:06',	'2026-05-11 19:17:06'),
(647,	'3407022642812070',	'inbound',	'Rey como estas, hermano espero estes bien pasaba a preguntarte si tal vez alcanzaste  a ver el videito?',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIwNDIzMjU2MjIyNzcwOTozMjgwOTQwNjYwMDYwNzc1Nzg4NDMzOTk5MjMzNzA1NTc0NAZDZD',	'2026-05-12 15:58:17',	'2026-05-12 15:58:17'),
(648,	'3407022642812070',	'inbound',	'Hermano como estas por aca te saluda Jorge, hermano nada solo escribiendote para recordarte si tal ves viste el video que te hice llegar?',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIwNDIzMjU2MjIyNzcwOTozMjgxNDM3NzI4ODI3NjM5MTk4NTgxOTAwMzE4NjU3NzQwOAZDZD',	'2026-05-15 18:49:18',	'2026-05-15 18:49:18'),
(649,	'26927479393524470',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTk2Nzc0NTc2MjUzMzcxMTozMjgxNjQ1NjE5MTAwOTk3Nzk5MDM5MDI3NDAzMjkyNjcyMAZDZD',	'2026-05-17 02:07:36',	'2026-05-17 02:07:36'),
(650,	'26927479393524470',	'outbound',	'https://mailerfind.com/',	NULL,	'2026-05-17 02:07:37',	'2026-05-17 02:07:37'),
(651,	'26376249765372152',	'inbound',	'Holaaaa que tal estas?',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTk5MDU2NzI4NjkxODQ1NjozMjgxNjkxNDM3ODQwMzQyNDMzNzM5NTgxNzA5MjQ4MTAyNAZDZD',	'2026-05-17 09:01:35',	'2026-05-17 09:01:35'),
(652,	'26376249765372152',	'outbound',	'Hola Tamara! Estoy genial :)
gracias por preguntar',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTk5MDU2NzI4NjkxODQ1NjozMjgxNzIwMzg1ODk3OTI4NDU1MjQxOTMxMjU3NjQ5NTYxNgZDZD',	'2026-05-17 13:23:06',	'2026-05-17 13:23:06'),
(653,	'1601236234307066',	'inbound',	'Hola, espero que todo vaya genial, curiosidad, ¿estás intentando ser más productivo y liberar horas de tu agenda en este momento? Quizás pueda ayudar',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIxNDA3NzAwMTI0MzI2NTozMjgxNzM1MTIxMDU0Njg1NTkwMDMyMTU2MTcxNjk4MTc2MAZDZD',	'2026-05-17 15:36:17',	'2026-05-17 15:36:17'),
(654,	'2124250091644267',	'outbound',	'tipo de pensamientos randoms que tengo un dia como hoy',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjgxOTQyNTc5ODc0MDcwMTMzNTg1MDg1NzU2NDk5NTU4NAZDZD',	'2026-05-18 22:50:38',	'2026-05-18 22:50:38'),
(655,	'2124250091644267',	'inbound',	'pues que pensamientos más guays',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjgxOTQyOTc0MTA4ODMyNjU5NTg4NjUzNjE2NjczNTg3MgZDZD',	'2026-05-18 22:54:12',	'2026-05-18 22:54:12'),
(656,	'1690785155380677',	'inbound',	'Hola Joan, vi tu contenido y creo que tiene muchísimo potencial con una edición más enfocada en retención y crecimiento.Yo me dedico a editar TikToks, Reels y Shorts para marcas y creadores. Básicamente me encargo de toda la parte visual para que el contenido se vea mucho más profesional.
Si querés, te mando más info 😁',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTI3NzQ0Mjg1MzM4MDQ0NzozMjgyNzIzNjE3NDMxMzA5NzgzNTM3NDEzODM1OTgwODAwMAZDZD',	'2026-05-23 20:27:22',	'2026-05-23 20:27:22'),
(657,	'811151328731252',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE5MDI4NzUyMzYyMjIxMzozMjgzMDEzMzYyOTI1MTk0NzgxMjg2Njk0NDUxMDQ1OTkwNAZDZD',	'2026-05-25 16:05:12',	'2026-05-25 16:05:12'),
(658,	'811151328731252',	'outbound',	'https://mailerfind.com/',	NULL,	'2026-05-25 16:05:12',	'2026-05-25 16:05:12'),
(659,	'3407022642812070',	'inbound',	'Hermanito, como te a ido con todo?',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIwNDIzMjU2MjIyNzcwOTozMjgzMDE0NDg3MDQ5MjM2MzM4OTQ2Mjg2OTczNDA2NDEyOAZDZD',	'2026-05-25 16:15:21',	'2026-05-25 16:15:21'),
(660,	'1760677718234776',	'inbound',	'Hey qué tal',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIwMjA4NTEwMTk0ODA0MDozMjgzMTcyODUyNTc1NDkwODk1MTI1ODc4ODA4MTQzNDYyNAZDZD',	'2026-05-26 16:06:11',	'2026-05-26 16:06:11'),
(661,	'3407022642812070',	'inbound',	'Rey como estas?',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIwNDIzMjU2MjIyNzcwOTozMjg0MTUwODA0MTgxMTYxNzIzOTc4NjM4Mjk1NjY5MTQ1NgZDZD',	'2026-06-01 19:21:59',	'2026-06-01 19:21:59'),
(664,	'2882070905466303',	'inbound',	'Hello',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTY4ODAwMzkzNzYwNTQ1ODozMjg0NzYzNzYzOTc1Njg2NDcxODA1NzM0NDU2MjM2NDQxNgZDZD',	'2026-06-05 15:40:06',	'2026-06-05 15:40:06'),
(665,	'2882070905466303',	'inbound',	'Hola',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTY4ODAwMzkzNzYwNTQ1ODozMjg0NzY1NDk4MTExMTA2NzA0MTc2OTAxNzY2MzU1MzUzNgZDZD',	'2026-06-05 15:55:45',	'2026-06-05 15:55:45'),
(666,	'974509892041013',	'inbound',	'Hi,

I''ve been using AmuletVoice for the past two months and wanted to continue using the platform, but AmuletVoice.com is currently inaccessible.

I''m a paying user and rely on the service, so I wanted to check whether the project is still active and if there''s an estimated timeline for when the website will be available again.

Looking forward to your update.

Regards,
Mert',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTE4MjEwODQ0NTY2NTY0MDozMjg2MTQwMDQ4MTE3ODM2MTIyNDIxMzg3NTMxMjgyMDIyNAZDZD',	'2026-06-14 06:54:52',	'2026-06-14 06:54:52'),
(667,	'2437569943421851',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIwNTM5MTI4MjExMTgzNzozMjg3MDkwNTc0MjgzOTM2MTgwMTI1MTI1NzU3NTI3NjU0NAZDZD',	'2026-06-20 06:02:52',	'2026-06-20 06:02:52'),
(668,	'2437569943421851',	'outbound',	'https://mailerfind.com/',	NULL,	'2026-06-20 06:02:53',	'2026-06-20 06:02:53'),
(669,	'2124250091644267',	'outbound',	'se que no deberia estar en instagram, ya lo cierro, pero mira esto :)',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTgzODg4MjM3MjEwMjU2NjozMjg4NzE0NzMxNjgwOTkzNTQ3NzQ1MTIyMjI4OTQ4MTcyOAZDZD',	'2026-06-30 10:37:10',	'2026-06-30 10:37:10'),
(670,	'1125370229647100',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDEyNzI1ODU3MzI1ODQ0MjozMjkyNTkwMDUyNTg1OTExMDA2NzM0OTIxMDQyMjgzNzI0OAZDZD',	'2026-07-24 18:10:44',	'2026-07-24 18:10:44'),
(671,	'1125370229647100',	'inbound',	'OBTENER ACCESO',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDEyNzI1ODU3MzI1ODQ0MjozMjkyNTkwMDc5NDc3NDQ5MDc5NTI5MDA0MTYzMTM3NTM2MAZDZD',	'2026-07-24 18:10:59',	'2026-07-24 18:10:59'),
(672,	'1125370229647100',	'outbound',	'https://mailerfind.com/',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDEyNzI1ODU3MzI1ODQ0MjozMjkyNTkwMDg2OTkwMDQwNTU2MTk3NDM4MjE4OTg3MTEwNAZDZD',	'2026-07-24 18:11:02',	'2026-07-24 18:11:02'),
(673,	'1125370229647100',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “prompt” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace y el prompt 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDEyNzI1ODU3MzI1ODQ0MjozMjkyNTkxNTY5MjA2MzcxNDA1MjE2ODAyODYwNjQzMTIzMgZDZD',	'2026-07-24 18:24:26',	'2026-07-24 18:24:26'),
(674,	'1125370229647100',	'inbound',	'PROMPT',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDEyNzI1ODU3MzI1ODQ0MjozMjkyNTkxNTgwOTUzMTc1MDIxMDA2NzEzNjM2NzI5NjUxMgZDZD',	'2026-07-24 18:24:33',	'2026-07-24 18:24:33'),
(675,	'1125370229647100',	'outbound',	'https://mailerfind.com/

Prompt:

Analiza los seguidores de {PON AQUÍ LA CUENTA DE INSTAGRAM} y dame una lista con todos los leads calificados que haya. Ponlo en marcha.',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDEyNzI1ODU3MzI1ODQ0MjozMjkyNTkxNTgzODIzODg4NjkzMjIyMzE5MzY1NDQ5MzE4NAZDZD',	'2026-07-24 18:24:34',	'2026-07-24 18:24:34'),
(676,	'731319353305758',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “prompt” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace y el prompt 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4OTE2OTA0NzA2NzM5NDozMjkyNTkyNTA5ODc4OTI4NTAwMzE0ODQwMTQ5MjA5OTA3MgZDZD',	'2026-07-24 18:32:56',	'2026-07-24 18:32:56'),
(677,	'1298580988818669',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “prompt” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace y el prompt 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTkwNTg1OTM1MTkxMzkxOTozMjkyNTkzMjUyMDUxNTA1MTg0MzU0MDk5OTYwOTUxNjAzMgZDZD',	'2026-07-24 18:39:38',	'2026-07-24 18:39:38'),
(678,	'1068291109214592',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “prompt” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace y el prompt 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDQxMTc3MTE2NDE2MjYzNTozMjkyNTk1NzIyMTExMjAyNTAxMzczNTU0MDQ5ODg5MDc1MgZDZD',	'2026-07-24 19:01:58',	'2026-07-24 19:01:58'),
(679,	'1995606374383541',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “prompt” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace y el prompt 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTI1MTI3MzY4NTE1ODA3NDozMjkyNTk3NTI4MTI3NDEyMTA4NDIzNzgwNzkxNTg5MjczNgZDZD',	'2026-07-24 19:18:16',	'2026-07-24 19:18:16'),
(680,	'2655280604868617',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “prompt” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace y el prompt 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTIwODEwMDM0OTg5NjEwNjozMjkyNTk3NzMxMDA3ODgxODA1MDg1MzI5NjIwMTAwNzEwNAZDZD',	'2026-07-24 19:20:07',	'2026-07-24 19:20:07'),
(681,	'1047735751123503',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “prompt” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace y el prompt 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTczMjY1MTgyMzExNjM0MzozMjkyNjAwMzg2MTg2NDI5NzMyNjc1MjA1MjY1MjUzOTkwNAZDZD',	'2026-07-24 19:44:06',	'2026-07-24 19:44:06'),
(699,	'2537825980007696',	'inbound',	'PROMPT',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MTAyNDkxNTc1NTc4NjYzNzozMjkyNjI4NDQ4NjY2MjkzODQzNzk1NjE0MjA3OTQxMDE3NgZDZD',	'2026-07-24 23:57:39',	'2026-07-24 23:57:39'),
(682,	'2008797486413179',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “prompt” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace y el prompt 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTI1NTg0NTA5NTMxOTk2MTozMjkyNjAzODM1OTM3MzU1MjY4NjY1MjExOTYyMDUxNzg4OAZDZD',	'2026-07-24 20:15:16',	'2026-07-24 20:15:16'),
(683,	'2008797486413179',	'inbound',	'PROMPT',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTI1NTg0NTA5NTMxOTk2MTozMjkyNjA0MDc5Njc0NDg1Mzk2NTE3OTE4OTI5OTUxMTI5NgZDZD',	'2026-07-24 20:17:29',	'2026-07-24 20:17:29'),
(684,	'2008797486413179',	'outbound',	'https://mailerfind.com/

Prompt:

Analiza los seguidores de {PON AQUÍ LA CUENTA DE INSTAGRAM} y dame una lista con todos los leads calificados que haya. Ponlo en marcha.',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTI1NTg0NTA5NTMxOTk2MTozMjkyNjA0MDgyODMzNDI3NjAwMjEwODI5MDMxNzE1NjM1MgZDZD',	'2026-07-24 20:17:30',	'2026-07-24 20:17:30'),
(685,	'972929065242544',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “prompt” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace y el prompt 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIxNzMyMzc3NDI1NjQ5NTozMjkyNjA3MzIyNzA3OTQ2NTI2MjEyOTAyNTk0ODU4MTg4OAZDZD',	'2026-07-24 20:46:46',	'2026-07-24 20:46:46'),
(686,	'972929065242544',	'inbound',	'PROMPT',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIxNzMyMzc3NDI1NjQ5NTozMjkyNjA3MzcwMjcwNDEzNDc5OTM5MTQxMjExNTczNDUyOAZDZD',	'2026-07-24 20:47:13',	'2026-07-24 20:47:13'),
(687,	'972929065242544',	'outbound',	'https://mailerfind.com/

Prompt:

Analiza los seguidores de {PON AQUÍ LA CUENTA DE INSTAGRAM} y dame una lista con todos los leads calificados que haya. Ponlo en marcha.',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDIxNzMyMzc3NDI1NjQ5NTozMjkyNjA3MzczNDU5MDc4OTIyMzU4MDE5NTEzODU2ODE5MgZDZD',	'2026-07-24 20:47:13',	'2026-07-24 20:47:13'),
(688,	'1725202995473249',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “prompt” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace y el prompt 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MjcwODI1NzcyNDA1MTAxNjozMjkyNjEwMDY5NzIxOTg4MzU1OTYxNzAxODkwNjgwNDIyNAZDZD',	'2026-07-24 21:11:35',	'2026-07-24 21:11:35'),
(689,	'1725202995473249',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MjcwODI1NzcyNDA1MTAxNjozMjkyNjEwMzQ2MDA2MDA1ODU5MTY4NTUyNTU2MTY3MTY4MAZDZD',	'2026-07-24 21:14:05',	'2026-07-24 21:14:05'),
(690,	'1601741984857950',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “prompt” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace y el prompt 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTc5MDA3MzQ0NzQxODcwOTozMjkyNjExNTU0MDMyODMyNjI0NzM3NTI5MTE5MTEzMjE2MAZDZD',	'2026-07-24 21:25:00',	'2026-07-24 21:25:00'),
(691,	'1601741984857950',	'inbound',	'PROMPT',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTc5MDA3MzQ0NzQxODcwOTozMjkyNjExOTUwMDE3Mjg5MTE3NTUwOTI5MDMwNTcxNjIyNAZDZD',	'2026-07-24 21:28:35',	'2026-07-24 21:28:35'),
(692,	'1601741984857950',	'outbound',	'https://mailerfind.com/

Prompt:

Analiza los seguidores de {PON AQUÍ LA CUENTA DE INSTAGRAM} y dame una lista con todos los leads calificados que haya. Ponlo en marcha.',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTc5MDA3MzQ0NzQxODcwOTozMjkyNjExOTU0MzU3NDgxNDkwNzI0NjgxODY2NzUyODE5MgZDZD',	'2026-07-24 21:28:37',	'2026-07-24 21:28:37'),
(693,	'1047735751123503',	'inbound',	'PROMPT',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTczMjY1MTgyMzExNjM0MzozMjkyNjE2Njg4OTE5ODExNTMzMTIyODk1ODQwOTYyMTUwNAZDZD',	'2026-07-24 22:11:24',	'2026-07-24 22:11:24'),
(694,	'1047735751123503',	'outbound',	'https://mailerfind.com/

Prompt:

Analiza los seguidores de {PON AQUÍ LA CUENTA DE INSTAGRAM} y dame una lista con todos los leads calificados que haya. Ponlo en marcha.',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTczMjY1MTgyMzExNjM0MzozMjkyNjE2NjkyNjg4NjA2Nzg1MjQxNDU4NDYxMDYxOTM5MgZDZD',	'2026-07-24 22:11:25',	'2026-07-24 22:11:25'),
(695,	'897048319625260',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “prompt” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace y el prompt 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MjY2Mjg1Mjc3NTIzNjQyNDozMjkyNjE3MTAxNDI3NDUwMTkxMjQzNjczMzA5MzM0NzMyOAZDZD',	'2026-07-24 22:15:07',	'2026-07-24 22:15:07'),
(696,	'768008969466546',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “prompt” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace y el prompt 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTA5MDQ3OTAyNzk3MDE2NTozMjkyNjE4NTQwODA4OTQ1MjcwMTY1MDgxMjU0MDAyNjg4MAZDZD',	'2026-07-24 22:28:07',	'2026-07-24 22:28:07'),
(697,	'1737065683989159',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “prompt” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace y el prompt 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTE5Nzk0Mjg3MDc2MzIwNDozMjkyNjIwMTcyNTkyOTE0MDcwMTg0ODMyMzcyMjU3NTg3MgZDZD',	'2026-07-24 22:42:52',	'2026-07-24 22:42:52'),
(698,	'2537825980007696',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “prompt” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace y el prompt 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MTAyNDkxNTc1NTc4NjYzNzozMjkyNjI4NDExMTIzODYwMzA3OTA5ODUzMTc1ODIxMTA3MgZDZD',	'2026-07-24 23:57:18',	'2026-07-24 23:57:18'),
(700,	'2537825980007696',	'outbound',	'https://mailerfind.com/

Prompt:

Analiza los seguidores de {PON AQUÍ LA CUENTA DE INSTAGRAM} y dame una lista con todos los leads calificados que haya. Ponlo en marcha.',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MTAyNDkxNTc1NTc4NjYzNzozMjkyNjI4NDUyMjE4NTQ4MzAxMjU2MTIyNTE0NDg2MDY3MgZDZD',	'2026-07-24 23:57:40',	'2026-07-24 23:57:40'),
(701,	'1003563149187019',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “prompt” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace y el prompt 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTA5NzE2MjYxMzkwNzAxNzozMjkyNjMxMTA0Njg3Nzc2ODA5ODgwMDkyMDM5OTE4Mzg3MgZDZD',	'2026-07-25 00:21:38',	'2026-07-25 00:21:38'),
(702,	'2388139378262304',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “prompt” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace y el prompt 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTE1NDU3ODg2NTUyOTAwMjozMjkyNjMxMTYwMDE0NDA4MjQ2NjAzMjAwODM1NTExOTEwNAZDZD',	'2026-07-25 00:22:08',	'2026-07-25 00:22:08'),
(703,	'1089007757120646',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “prompt” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace y el prompt 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTUzNTM0MDMwMjUzMTUyNzozMjkyNjMxNzQ0MzAxNjMyNjAwNDgxMzI3NzY2ODgzNTMyOAZDZD',	'2026-07-25 00:27:25',	'2026-07-25 00:27:25'),
(704,	'2186104338601241',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “prompt” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace y el prompt 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTY2MTk1ODQ5MDI5MjQ1MzozMjkyNjMyNzkwMDc0NTE0MDU1NTM5NTM1Mzg3NjEwMzE2OAZDZD',	'2026-07-25 00:36:52',	'2026-07-25 00:36:52'),
(705,	'1419677863697292',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “prompt” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace y el prompt 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTE0MjI0ODYzNjc3MzE3MDozMjkyNjMyNzkzNjc4ODk5MDExNzUyMzQ2ODg3MDIyMTgyNAZDZD',	'2026-07-25 00:36:54',	'2026-07-25 00:36:54'),
(706,	'2388139378262304',	'inbound',	'PROMPT',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTE1NDU3ODg2NTUyOTAwMjozMjkyNjM0MTYxMDI3OTkwOTI2NDUyODc2NTk1Mzc2OTQ3MgZDZD',	'2026-07-25 00:49:16',	'2026-07-25 00:49:16'),
(707,	'2388139378262304',	'outbound',	'https://mailerfind.com/

Prompt:

Analiza los seguidores de {PON AQUÍ LA CUENTA DE INSTAGRAM} y dame una lista con todos los leads calificados que haya. Ponlo en marcha.',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTE1NDU3ODg2NTUyOTAwMjozMjkyNjM0MTY1NTk1MjI5NTE1MDM0NjYxMzM0NzU4MTk1MgZDZD',	'2026-07-25 00:49:18',	'2026-07-25 00:49:18'),
(708,	'1494051772522675',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “prompt” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace y el prompt 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTUzODUwMTI0NjQwODI3OTozMjkyNjM3MTUyMDIyMjE3MTgzOTY5NTc5OTExMTkwOTM3NgZDZD',	'2026-07-25 01:16:17',	'2026-07-25 01:16:17'),
(709,	'1494051772522675',	'inbound',	'PROMPT',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTUzODUwMTI0NjQwODI3OTozMjkyNjM3MjA2NjM3NTQyMTY5MjEwNDQ4Mzk2NDcxNTAwOAZDZD',	'2026-07-25 01:16:47',	'2026-07-25 01:16:47'),
(710,	'1494051772522675',	'outbound',	'https://mailerfind.com/

Prompt:

Analiza los seguidores de {PON AQUÍ LA CUENTA DE INSTAGRAM} y dame una lista con todos los leads calificados que haya. Ponlo en marcha.',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTUzODUwMTI0NjQwODI3OTozMjkyNjM3MjE1NDA0NjY3MTk1NTQxMzUxMTIyNDQyNjQ5NgZDZD',	'2026-07-25 01:16:51',	'2026-07-25 01:16:51'),
(711,	'2337910950064402',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “prompt” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace y el prompt 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE0NDc5NTAyNDgzNTM0OTozMjkyNjQ4MTE1NzQ3OTU3MzI4NTUwNzg4MDcxODQzNDMwNAZDZD',	'2026-07-25 02:55:20',	'2026-07-25 02:55:20'),
(712,	'1386404733365981',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “prompt” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace y el prompt 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTE5MjAyNTg1ODIxNzQzNDozMjkyNjUwMjI2MTYzNTk3NTcyNjEzOTExOTk1MjE5OTY4MAZDZD',	'2026-07-25 03:14:24',	'2026-07-25 03:14:24'),
(713,	'1435605851194174',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “prompt” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace y el prompt 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4OTc1NzgzMDM0MTg0OTozMjkyNjU0NzM4NTQzNTAwNjUzMjkwOTYyMjYwNTM4MTYzMgZDZD',	'2026-07-25 03:55:10',	'2026-07-25 03:55:10'),
(714,	'1017350510898417',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “prompt” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace y el prompt 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTIzNzQzNzAxOTg4ODAzNzozMjkyNjU2NTA3NzMyMDY1OTIxMjE4Nzg0NjQzNzc2NTEyMAZDZD',	'2026-07-25 04:11:09',	'2026-07-25 04:11:09'),
(733,	'1602053534683032',	'inbound',	'PROMPT',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTg1ODg5MTMwNjQ2OTM4NTozMjkyNzI1ODU0MTI2MjY5OTA5MjM0ODk3NTA0OTYwNTEyMAZDZD',	'2026-07-25 14:37:43',	'2026-07-25 14:37:43'),
(715,	'2147459216168410',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “prompt” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace y el prompt 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTcyMjA5OTM3MDcxOTU4OTozMjkyNjU5NTMxODE2MjA5MjcyMTA4MjcxMzI0Nzg0MjMwNAZDZD',	'2026-07-25 04:38:29',	'2026-07-25 04:38:29'),
(716,	'1520867099302461',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “prompt” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace y el prompt 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTg3NTgyNDMxNDkyODAwNTozMjkyNjY4MDE0MjU5NDM5MzE3MzQwMjc4NjU5Nzk2MTcyOAZDZD',	'2026-07-25 05:55:07',	'2026-07-25 05:55:07'),
(717,	'2062013671380969',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “prompt” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace y el prompt 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDMwOTQwNDk3NTA0NzU4MDozMjkyNjcwMTQ2MjUwNDMyMDEyODUxMDU2MzE0MjU5ODY1NgZDZD',	'2026-07-25 06:14:23',	'2026-07-25 06:14:23'),
(718,	'1526370182451197',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “prompt” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace y el prompt 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDI1NjcwMjg4OTUzNDEyMjozMjkyNjcyMTQwNzI0ODE3NzY1NzYzNzkwOTM1MzcyNTk1MgZDZD',	'2026-07-25 06:32:24',	'2026-07-25 06:32:24'),
(719,	'1526370182451197',	'inbound',	'PROMPT',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDI1NjcwMjg4OTUzNDEyMjozMjkyNjcyNjU2MzQ4MDczNDUyODYxNDM5NjI2MDc3Nzk4NAZDZD',	'2026-07-25 06:37:04',	'2026-07-25 06:37:04'),
(720,	'1526370182451197',	'outbound',	'https://mailerfind.com/

Prompt:

Analiza los seguidores de {PON AQUÍ LA CUENTA DE INSTAGRAM} y dame una lista con todos los leads calificados que haya. Ponlo en marcha.',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDI1NjcwMjg4OTUzNDEyMjozMjkyNjcyNjU5MzM2NjUwNzUxNjYxNjA1MTYzODkyNzM2MAZDZD',	'2026-07-25 06:37:05',	'2026-07-25 06:37:05'),
(721,	'1435605851194174',	'inbound',	'PROMPT',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4OTc1NzgzMDM0MTg0OTozMjkyNjcyODczNzM3MzcyMjIxNDQ2MjA4MjgxMjczOTU4NAZDZD',	'2026-07-25 06:39:02',	'2026-07-25 06:39:02'),
(722,	'1435605851194174',	'outbound',	'https://mailerfind.com/

Prompt:

Analiza los seguidores de {PON AQUÍ LA CUENTA DE INSTAGRAM} y dame una lista con todos los leads calificados que haya. Ponlo en marcha.',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4OTc1NzgzMDM0MTg0OTozMjkyNjcyODc3MzQ3NTgwODE0NzYzMDg5ODg2MTMwOTk1MgZDZD',	'2026-07-25 06:39:03',	'2026-07-25 06:39:03'),
(723,	'1704738690907605',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “prompt” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace y el prompt 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDcxOTY4NjMxNjM4NzUyNTozMjkyNjc3NzcxNzgxMDcxNzg4OTI2OTM2MzEwNzY5MjU0NAZDZD',	'2026-07-25 07:23:17',	'2026-07-25 07:23:17'),
(724,	'2062013671380969',	'inbound',	'PROMPT',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDMwOTQwNDk3NTA0NzU4MDozMjkyNjc4MTAwNTAzNTk3MDE5NTg0NTIyOTY4MzE0Njc1MgZDZD',	'2026-07-25 07:26:16',	'2026-07-25 07:26:16'),
(725,	'2062013671380969',	'outbound',	'https://mailerfind.com/

Prompt:

Analiza los seguidores de {PON AQUÍ LA CUENTA DE INSTAGRAM} y dame una lista con todos los leads calificados que haya. Ponlo en marcha.',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDMwOTQwNDk3NTA0NzU4MDozMjkyNjc4MTAzOTE0NDIzOTc5NTgwNzE0ODg0NTMwMTc2MAZDZD',	'2026-07-25 07:26:17',	'2026-07-25 07:26:17'),
(726,	'1022478197067546',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “prompt” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace y el prompt 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDEzMzI1OTM4NTI5NjQ2NjozMjkyNjg0NjcyNTQ0NjgzODQ0ODk3NDk3Nzc2ODA5NTc0NAZDZD',	'2026-07-25 08:25:37',	'2026-07-25 08:25:37'),
(727,	'1022478197067546',	'inbound',	'PROMPT',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDEzMzI1OTM4NTI5NjQ2NjozMjkyNzA2NTE0MTQ3MTMxMjExODg2NTA3OTkxODY1NzUzNgZDZD',	'2026-07-25 11:43:00',	'2026-07-25 11:43:00'),
(728,	'1022478197067546',	'outbound',	'https://mailerfind.com/

Prompt:

Analiza los seguidores de {PON AQUÍ LA CUENTA DE INSTAGRAM} y dame una lista con todos los leads calificados que haya. Ponlo en marcha.',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDEzMzI1OTM4NTI5NjQ2NjozMjkyNzA2NTIwMTQ0NjMwNzIzNTI1NzMzMzMxOTcyOTE1MgZDZD',	'2026-07-25 11:43:01',	'2026-07-25 11:43:01'),
(729,	'1889315892027788',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “prompt” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace y el prompt 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTA4ODA4Mjk2NDkxNzU5NDozMjkyNzA3MDkyMDY3MzUzMDEyOTMzNzQ4Mjk2NjIwNDQxNgZDZD',	'2026-07-25 11:48:11',	'2026-07-25 11:48:11'),
(730,	'1520867099302461',	'inbound',	'PROMPT',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTg3NTgyNDMxNDkyODAwNTozMjkyNzIzODEyOTMxNTg4NTQ1ODg1ODc0ODc4NTE5NzA1NgZDZD',	'2026-07-25 14:19:18',	'2026-07-25 14:19:18'),
(731,	'1520867099302461',	'outbound',	'https://mailerfind.com/

Prompt:

Analiza los seguidores de {PON AQUÍ LA CUENTA DE INSTAGRAM} y dame una lista con todos los leads calificados que haya. Ponlo en marcha.',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTg3NTgyNDMxNDkyODAwNTozMjkyNzIzODE5MjIzOTUxODgyODQ1NzE3OTE3Mzg3OTgwOAZDZD',	'2026-07-25 14:19:19',	'2026-07-25 14:19:19'),
(732,	'1602053534683032',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “prompt” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace y el prompt 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTg1ODg5MTMwNjQ2OTM4NTozMjkyNzI1NTA4NDEyMDA0MTQ1NzUxMjY2NDUzNzIzNTQ1NgZDZD',	'2026-07-25 14:34:35',	'2026-07-25 14:34:35'),
(734,	'1602053534683032',	'outbound',	'https://mailerfind.com/

Prompt:

Analiza los seguidores de {PON AQUÍ LA CUENTA DE INSTAGRAM} y dame una lista con todos los leads calificados que haya. Ponlo en marcha.',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTg1ODg5MTMwNjQ2OTM4NTozMjkyNzI1ODU3ODQzMzQyMzM1NjQ1MTg1OTEzMjg0MTk4NAZDZD',	'2026-07-25 14:37:44',	'2026-07-25 14:37:44'),
(735,	'2288401341695335',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “prompt” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace y el prompt 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTcyODE5NTgwMDAyMzkwMDozMjkyNzQwMjk5MTU2ODczNDY5ODM1MDI1Njg2NTY3MzIxNgZDZD',	'2026-07-25 16:48:13',	'2026-07-25 16:48:13'),
(736,	'1089007757120646',	'inbound',	'PROMPT',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTUzNTM0MDMwMjUzMTUyNzozMjkyNzQxNjgyMjA5OTc3NDUxNzM4NDkwNzgwMzU5MDY1NgZDZD',	'2026-07-25 17:00:43',	'2026-07-25 17:00:43'),
(737,	'1089007757120646',	'outbound',	'https://mailerfind.com/

Prompt:

Analiza los seguidores de {PON AQUÍ LA CUENTA DE INSTAGRAM} y dame una lista con todos los leads calificados que haya. Ponlo en marcha.',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTUzNTM0MDMwMjUzMTUyNzozMjkyNzQxNjg2MzU2NTYzODY3MTYxMDMyMzg4NTA5Njk2MAZDZD',	'2026-07-25 17:00:45',	'2026-07-25 17:00:45'),
(738,	'1013985097931703',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “prompt” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace y el prompt 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTczODMxMDQ2NTY2MzcyODozMjkyNzQzODY2OTg3NTg4MjI2Nzg5Mzg0NzQ2MzgyMTMxMgZDZD',	'2026-07-25 17:20:27',	'2026-07-25 17:20:27'),
(739,	'1050812113993490',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “prompt” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace y el prompt 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTc5NTg4MDA4MzM2NTAxMzozMjkyNzQzOTg3NDkxMjk2MjIxMTA4ODM4NTMwMzM3OTk2OAZDZD',	'2026-07-25 17:21:32',	'2026-07-25 17:21:32'),
(740,	'2509623909442988',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “prompt” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace y el prompt 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI4NTM0NzE5MDg3NjIzODk5MDozMjkyNzQ4OTM0NzI2ODcyODY5NzE4NjA2NzI1NTY1NjQ0OAZDZD',	'2026-07-25 18:06:14',	'2026-07-25 18:06:14'),
(741,	'970651182647010',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “prompt” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace y el prompt 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTk0Njc5MzI1NDQxNDU0MTozMjkyNzY3ODQ2NTIyNjIzMDk4MzM4NjEzNzg4ODgxNzE1MgZDZD',	'2026-07-25 20:57:06',	'2026-07-25 20:57:06'),
(742,	'731319353305758',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “prompt” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace y el prompt 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDE4OTE2OTA0NzA2NzM5NDozMjkyNzY5MDUxNzgzNzAxODU0ODIwMjA2NzEzNzEzNDU5MgZDZD',	'2026-07-25 21:08:00',	'2026-07-25 21:08:00'),
(743,	'936304822199635',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “prompt” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace y el prompt 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTUyMDIzNDY0NDg4NTUyNjozMjkyNzg5MzgxNTk5Mjg3MzI4Mjg3MDQxNTQ5Mzk1NTU4NAZDZD',	'2026-07-26 00:11:40',	'2026-07-26 00:11:40'),
(744,	'1613672020322290',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “prompt” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace y el prompt 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTM2ODA0ODgxMzQwODExMjozMjkyNzg5NDkxMDg4MDc3MzQ1OTg3NDU1MjQzMzYwNjY1NgZDZD',	'2026-07-26 00:12:40',	'2026-07-26 00:12:40'),
(745,	'936304822199635',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “prompt” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace y el prompt 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTUyMDIzNDY0NDg4NTUyNjozMjkyNzg5ODAyNDU4NTk4OTc2NzMzODU3MzM1MTA5MjIyNAZDZD',	'2026-07-26 00:15:28',	'2026-07-26 00:15:28'),
(746,	'936304822199635',	'inbound',	'PROMPT',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTUyMDIzNDY0NDg4NTUyNjozMjkyNzg5ODEzMzczMjU4ODk5MzEyMjg2MDEyMDY3MDIwOAZDZD',	'2026-07-26 00:15:35',	'2026-07-26 00:15:35'),
(747,	'936304822199635',	'outbound',	'https://mailerfind.com/

Prompt:

Analiza los seguidores de {PON AQUÍ LA CUENTA DE INSTAGRAM} y dame una lista con todos los leads calificados que haya. Ponlo en marcha.',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTUyMDIzNDY0NDg4NTUyNjozMjkyNzg5ODE2MzE3NDkwMjI1MzU5MjUzNzg3Nzk3MDk0NAZDZD',	'2026-07-26 00:15:36',	'2026-07-26 00:15:36'),
(748,	'1548894863382091',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “prompt” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace y el prompt 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDU5NDkyODMwMjI0Njg3NDozMjkyODE0ODY3NzUxMjEyODk5NTYzNDYwNjAwNDc2NDY3MgZDZD',	'2026-07-26 04:01:56',	'2026-07-26 04:01:56'),
(749,	'1053728253975360',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “prompt” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace y el prompt 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTA3ODQ4MjU0NjU1Mzk4MDozMjkyODkyMjAzOTU1Mzg3NjA2Njg2MjIzOTMxMzgyMTY5NgZDZD',	'2026-07-26 15:40:41',	'2026-07-26 15:40:41'),
(750,	'1042703044827752',	'outbound',	'[Fase 1] Hola!

Vi que comentaste “prompt” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace y el prompt 🔗',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI2MDEzMTI0OTgyOTUyNTk4MzozMjkyOTQwMzI2NTM1MDgxNzUyNzY0ODk2OTkxODc3NTI5NgZDZD',	'2026-07-26 22:55:28',	'2026-07-26 22:55:28'),
(751,	'2288401341695335',	'inbound',	'PROMPT',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTcyODE5NTgwMDAyMzkwMDozMjkyOTUzODk0NDk2MDY4NDcyNDAyOTk0NjI0NzI0OTkyMAZDZD',	'2026-07-27 00:58:04',	'2026-07-27 00:58:04'),
(752,	'2288401341695335',	'outbound',	'https://mailerfind.com/

Prompt:

Analiza los seguidores de {PON AQUÍ LA CUENTA DE INSTAGRAM} y dame una lista con todos los leads calificados que haya. Ponlo en marcha.',	'aWdfZAG1faXRlbToxOklHTWVzc2FnZAUlEOjE3ODQxNDA3OTc3ODYwMTQyOjM0MDI4MjM2Njg0MTcxMDMwMTI0NDI1OTcyODE5NTgwMDAyMzkwMDozMjkyOTUzOTAzNzM5NjQxNTM4NjkyODg5NzYyNjk5NjczNgZDZD',	'2026-07-27 00:58:08',	'2026-07-27 00:58:08');

DROP TABLE IF EXISTS "instagram_keyword_rule_embeddings";
DROP SEQUENCE IF EXISTS instagram_keyword_rule_embeddings_id_seq;
CREATE SEQUENCE instagram_keyword_rule_embeddings_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."instagram_keyword_rule_embeddings" (
    "id" bigint DEFAULT nextval('instagram_keyword_rule_embeddings_id_seq') NOT NULL,
    "instagram_keyword_rule_id" bigint NOT NULL,
    "keyword" character varying(500) NOT NULL,
    "embedding" json NOT NULL,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "instagram_keyword_rule_embeddings_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE UNIQUE INDEX instagram_keyword_rule_embeddings_instagram_keyword_rule_id_key ON public.instagram_keyword_rule_embeddings USING btree (instagram_keyword_rule_id, keyword);

INSERT INTO "instagram_keyword_rule_embeddings" ("id", "instagram_keyword_rule_id", "keyword", "embedding", "created_at", "updated_at") VALUES
(1,	1,	'clientes',	'[0.035858154296875,-0.0028228759765625,0.0230865478515625,0.00876617431640625,0.039520263671875,-0.01396942138671875,-0.0032596588134765625,0.061065673828125,-0.02313232421875,-0.039306640625,0.037994384765625,-0.0173492431640625,0.0223236083984375,-0.04351806640625,0.01898193359375,0.021820068359375,-0.00411224365234375,-0.03961181640625,-0.039947509765625,0.003719329833984375,0.037811279296875,0.054656982421875,0.0504150390625,-0.0347900390625,-0.037872314453125,0.037261962890625,-0.033935546875,-0.01239013671875,0.024169921875,-0.04693603515625,0.0221710205078125,-0.04571533203125,0.01482391357421875,0.016632080078125,0.0299072265625,0.0002391338348388672,0.01617431640625,0.01535797119140625,0.0025615692138671875,-0.01165008544921875,-0.012451171875,0.022979736328125,0.01526641845703125,0.055816650390625,0.0242767333984375,0.015869140625,-0.033966064453125,-0.0302276611328125,0.04742431640625,0.06573486328125,-0.0251922607421875,-0.03717041015625,0.0101776123046875,0.08575439453125,-0.01093292236328125,0.030181884765625,0.0258331298828125,0.0195159912109375,0.004634857177734375,0.007785797119140625,-0.048736572265625,-0.037872314453125,0.04022216796875,-0.0030345916748046875,-0.01318359375,-0.001575469970703125,-0.0296173095703125,0.02362060546875,-0.05291748046875,0.0316162109375,0.011016845703125,0.0093994140625,-0.0323486328125,0.0181427001953125,-0.025970458984375,0.0267181396484375,0.00928497314453125,0.0201416015625,0.0144500732421875,-0.030609130859375,0.0001304149627685547,-0.006221771240234375,-0.0100860595703125,0.010528564453125,-0.0271759033203125,-0.03466796875,-0.062042236328125,0.029998779296875,0.0150909423828125,0.009063720703125,-0.0301361083984375,0.046173095703125,0.01488494873046875,0.04022216796875,0.04144287109375,0.0343017578125,-0.001270294189453125,-0.0235137939453125,0.00199127197265625,0.00887298583984375,0.05609130859375,-0.052734375,-0.004741668701171875,-0.00885009765625,-0.017425537109375,0.0277862548828125,-0.01456451416015625,-0.0259552001953125,0.01009368896484375,0.0179595947265625,-0.041961669921875,-0.0138702392578125,-0.01556396484375,0.041046142578125,0.033905029296875,-0.017181396484375,-0.01464080810546875,-0.0260772705078125,0.02032470703125,-0.0672607421875,0.033294677734375,0.014617919921875,-0.00766754150390625,-0.001583099365234375,-0.004665374755859375,0.015228271484375,-0.01519012451171875,-0.0300750732421875,-0.012176513671875,-0.050872802734375,-0.003711700439453125,-0.035430908203125,0.025054931640625,-0.0265655517578125,-0.04248046875,-0.01305389404296875,0.00937652587890625,0.0009946823120117188,-0.01160430908203125,-0.021331787109375,0.0206451416015625,-0.04345703125,0.010040283203125,-0.0142974853515625,-0.0511474609375,-0.029541015625,-0.035186767578125,0.0273284912109375,-0.019134521484375,0.0188751220703125,-0.01104736328125,0.0075531005859375,-0.033599853515625,-0.002368927001953125,-0.063720703125,-0.0184173583984375,0.0002589225769042969,-0.04656982421875,-0.052764892578125,-0.0379638671875,0.014068603515625,-0.0197296142578125,0.026611328125,-0.004009246826171875,-0.004734039306640625,0.0138702392578125,-0.0178680419921875,0.031707763671875,-0.046295166015625,-0.0173187255859375,-0.01505279541015625,-0.020965576171875,-0.040435791015625,0.0162353515625,-0.0301361083984375,0.0101776123046875,0.024322509765625,-0.007297515869140625,-0.0165252685546875,-0.0100250244140625,0.02862548828125,0.0299224853515625,0.0361328125,-0.033233642578125,-0.01433563232421875,-0.0160980224609375,-0.038818359375,-0.02020263671875,0.0220794677734375,-0.0350341796875,-0.0036487579345703125,0.0205230712890625,0.06903076171875,0.056182861328125,0.00921630859375,-0.0447998046875,-0.0161285400390625,0.0290069580078125,-0.032257080078125,0.017822265625,-0.01535797119140625,-0.03271484375,0.0308380126953125,0.0203704833984375,0.00244903564453125,-0.0243682861328125,0.005886077880859375,0.022125244140625,-0.0236053466796875,-0.00998687744140625,0.11163330078125,0.0003962516784667969,-0.015533447265625,-0.0087432861328125,-0.040252685546875,0.038604736328125,0.024658203125,0.003635406494140625,-0.022247314453125,0.0498046875,0.0006775856018066406,0.01318359375,0.05328369140625,0.003307342529296875,0.01084136962890625,0.0712890625,0.02496337890625,-0.057769775390625,-0.0273284912109375,-0.09124755859375,0.0061187744140625,0.021820068359375,-0.0261383056640625,-0.0175933837890625,-0.0144500732421875,0.01435089111328125,-0.0198974609375,0.0008349418640136719,0.00972747802734375,-0.06219482421875,-0.016845703125,-0.046417236328125,-0.046356201171875,-0.01334381103515625,-0.01210784912109375,-0.005474090576171875,0.006061553955078125,-0.0035533905029296875,0.01076507568359375,0.04888916015625,0.048553466796875,0.020965576171875,-0.019561767578125,-0.002918243408203125,0.052825927734375,0.0017175674438476562,0.0318603515625,-0.01375579833984375,0.0249481201171875,-0.0210113525390625,-0.00977325439453125,-0.0352783203125,0.015716552734375,-0.00583648681640625,-0.002719879150390625,-0.0016536712646484375,0.002651214599609375,-0.0296173095703125,0.02197265625,0.0171661376953125,-0.0557861328125,-0.0245513916015625,0.0184326171875,0.021087646484375,-0.0684814453125,0.026611328125,0.046966552734375,0.0305633544921875,-0.0156707763671875,0.051727294921875,-0.06341552734375,-0.0198211669921875,0.0254364013671875,-0.04156494140625,0.01898193359375,0.0257720947265625,0.045654296875,-0.021331787109375,0.02459716796875,0.048736572265625,0.0020618438720703125,-0.03240966796875,-0.0119781494140625,-0.0168914794921875,0.017974853515625,0.026519775390625,0.0274810791015625,-0.06884765625,-0.010406494140625,0.0072784423828125,0.00766754150390625,0.040771484375,-0.027587890625,-0.0084686279296875,-0.0272064208984375,0.0185089111328125,0.04510498046875,-0.01030731201171875,0.003353118896484375,-0.02362060546875,-0.0262603759765625,-0.01033782958984375,0.024017333984375,-0.0009751319885253906,-0.031524658203125,-0.053680419921875,0.0192413330078125,-0.01390838623046875,0.00978851318359375,-0.01456451416015625,-0.035675048828125,-0.0230712890625,-0.0007395744323730469,-0.0040435791015625,-0.0124359130859375,-0.0330810546875,-0.03619384765625,-0.050079345703125,0.012847900390625,-0.026336669921875,0.00502777099609375,-0.0621337890625,0.0157928466796875,-0.011566162109375,0.003971099853515625,-0.00994873046875,0.01123809814453125,0.016357421875,-0.0311737060546875,-0.031341552734375,-0.0239105224609375,-0.041229248046875,-0.05389404296875,-0.0241546630859375,0.030670166015625,-0.0152587890625,0.060302734375,0.0377197265625,0.03240966796875,0.0313720703125,0.0296783447265625,0.0096588134765625,0.01102447509765625,0.07037353515625,-0.0070343017578125,-0.00453948974609375,0.0252685546875,-0.02056884765625,-0.0094146728515625,0.034088134765625,-0.0310211181640625,-0.004486083984375,0.006710052490234375,-0.0308990478515625,0.00026726722717285156,-0.01806640625,-0.052825927734375,-0.020965576171875,0.017181396484375,-0.009613037109375,0.02691650390625,-0.016143798828125,0.0040130615234375,0.03399658203125,-0.05059814453125,0.0089111328125,0.0150909423828125,0.035888671875,0.0047607421875,0.00801849365234375,-0.00022327899932861328,-0.0003304481506347656,0.0159912109375,-0.03277587890625,0.0156097412109375,0.00777435302734375,-0.0233612060546875,0.0347900390625,-0.00821685791015625,-0.045379638671875,0.0298309326171875,-0.003917694091796875,0.0062713623046875,-0.061126708984375,0.06390380859375,0.005764007568359375,0.049407958984375,0.0419921875,0.006671905517578125,-0.009246826171875,-0.005535125732421875,-0.0272979736328125,0.00399017333984375,0.04193115234375,-0.041717529296875,-0.0141448974609375,-0.07958984375,0.0008335113525390625,0.0194549560546875,-0.0243377685546875,-0.015899658203125,-0.00394439697265625,0.017822265625,0.07183837890625,0.0173187255859375,-0.01220703125,-0.025054931640625,-0.015899658203125,0.01104736328125,0.0198822021484375,-0.0222625732421875,-0.0235137939453125,-0.00962066650390625,-0.00746917724609375,-0.0204315185546875,0.0178680419921875,0.046417236328125,0.001995086669921875,-0.055419921875,-0.039642333984375,-0.014007568359375,0.0450439453125,-0.01678466796875,-0.00589752197265625,-0.055023193359375,-0.024444580078125,0.020233154296875,0.01505279541015625,-0.01366424560546875,-0.05841064453125,-0.04205322265625,-0.01047515869140625,0.005535125732421875,-0.0158843994140625,0.0517578125,-0.0182342529296875,0.00940704345703125,-0.015106201171875,-0.0288848876953125,-0.0504150390625,0.00566864013671875,0.03826904296875,0.01288604736328125,-0.02471923828125,-0.0213775634765625,0.012664794921875,0.01187896728515625,0.01113128662109375,-0.016510009765625,-0.0034923553466796875,-0.025909423828125,-0.00528717041015625,-0.0186920166015625,0.0311737060546875,0.053192138671875,-0.01178741455078125,0.01352691650390625,0.01189422607421875,0.01337432861328125,-0.017822265625,0.0153961181640625,0.0653076171875,-0.0548095703125,0.0148468017578125,-0.052764892578125,0.0174713134765625,0.00165557861328125,0.033172607421875,0.0016508102416992188,-0.0504150390625,-0.01390838623046875,0.0145416259765625,-0.031951904296875,0.04595947265625,-0.01062774658203125,0.1439208984375,0.03717041015625,0.01021575927734375,-0.0391845703125,0.0054168701171875,0.0501708984375,0.02398681640625,0.03497314453125,-0.01413726806640625,-0.01506805419921875,-0.018402099609375,0.018890380859375,-0.053680419921875,0.0102081298828125,-0.04327392578125,-0.0225067138671875,-0.05450439453125,-0.055877685546875,0.051116943359375,-0.0193939208984375,0.03497314453125,-0.0504150390625,-0.03326416015625,0.00849151611328125,0.04229736328125,0.01090240478515625,0.04437255859375,-0.040069580078125,-0.00241851806640625,-0.037628173828125,-0.01229095458984375,-0.038330078125,0.0082550048828125,-0.03564453125,0.004131317138671875,0.00829315185546875,-0.022308349609375,0.0049591064453125,-0.047576904296875,-0.005458831787109375,0.00405120849609375,-0.00926971435546875,-0.08154296875,-0.03497314453125,-0.0231170654296875,-0.0018014907836914062,-0.015380859375,0.0038204193115234375,0.03497314453125,0.0138702392578125,0.0273284912109375,0.01110076904296875,0.006244659423828125,-0.007781982421875,0.01103973388671875,-0.015716552734375,0.007297515869140625,-0.03594970703125,0.01165771484375,-0.0523681640625,0.019287109375,0.0195770263671875,-0.01934814453125,-0.023895263671875,0.039215087890625,0.00978851318359375,-0.03265380859375,0.023590087890625,-0.00351715087890625,0.0333251953125,-0.0648193359375,0.00688934326171875,-0.005260467529296875,0.0264129638671875,-0.01433563232421875,-0.0214691162109375,0.004177093505859375,0.02294921875,-0.0509033203125,-0.053955078125,0.0126953125,0.0169830322265625,-0.0030517578125,-0.0225830078125,-0.01134490966796875,-0.03619384765625,0.042327880859375,-0.00904083251953125,0.0203704833984375,0.033538818359375,0.0164794921875,-0.00666046142578125,0.0223846435546875,-0.030181884765625,0.00824737548828125,-0.023406982421875,0.00836181640625,-0.026153564453125,-0.003021240234375,0.002666473388671875,-0.031646728515625,0.01678466796875,0.0215606689453125,-0.0162811279296875,0.003696441650390625,0.0036678314208984375,-0.0173187255859375,-0.00586700439453125,0.003917694091796875,0.004230499267578125,0.03216552734375,-0.0032958984375,0.0201263427734375,-0.0303802490234375,-0.004306793212890625,-0.0006270408630371094,-0.01190185546875,0.01035308837890625,-0.007843017578125,0.046112060546875,0.0293426513671875,-0.02252197265625,-0.006072998046875,0.0055694580078125,0.0211944580078125,0.02105712890625,-0.001300811767578125,0.002201080322265625,-0.0137786865234375,-0.037109375,-0.0106658935546875,-0.01184844970703125,0.0006475448608398438,0.021087646484375,0.0328369140625,-0.048248291015625,0.027130126953125,0.04534912109375,0.03692626953125,0.003215789794921875,0.0445556640625,-0.01849365234375,-0.0692138671875,0.013397216796875,0.0175628662109375,-0.0154571533203125,0.0162811279296875,-0.005779266357421875,0.0005421638488769531,-0.02264404296875,-0.047332763671875,0.00504302978515625,0.006862640380859375,-0.01082611083984375,-0.0318603515625,0.0011262893676757812,0.026763916015625,-0.00882720947265625,-0.022796630859375,0.0122833251953125,-0.007335662841796875,0.0157470703125,-0.00829315185546875,-0.0063018798828125,0.018585205078125,-0.0311279296875,-0.0182037353515625,0.0258941650390625,-0.04559326171875,0.003993988037109375,-0.0096282958984375,-0.0233917236328125,-0.01068115234375,0.042694091796875,0.0282440185546875,-0.0307464599609375,0.032562255859375,0.0286712646484375,-0.047515869140625,0.007297515869140625,0.0279693603515625,-0.03533935546875,0.005619049072265625,-0.0073089599609375,-0.01503753662109375,-0.034393310546875,0.04803466796875,0.050445556640625,-0.003658294677734375,0.0278167724609375,-0.01422119140625,0.0252532958984375,-0.03765869140625,-0.004261016845703125,-0.0023956298828125,-0.04095458984375,-0.0184783935546875,-0.020751953125,-0.003910064697265625,-0.025634765625,-0.0001729726791381836,0.0007653236389160156,0.003482818603515625,0.001750946044921875,0.0190277099609375,-0.01971435546875,0.010284423828125,0.039886474609375,0.00550079345703125,0.011871337890625,-0.043243408203125,0.0128326416015625,-0.0036163330078125,-0.01071929931640625,0.0190582275390625,0.0127410888671875,-0.0243377685546875,0.0230865478515625,0.0027618408203125,-0.0186614990234375,-0.004505157470703125,-0.0041656494140625,0.00469207763671875,-0.0140228271484375,0.01464080810546875,0.00939178466796875,0.0361328125,-0.0262908935546875,-0.00525665283203125,-0.00887298583984375,0.024261474609375,-0.0268707275390625,0.00481414794921875,0.02813720703125,-0.004840850830078125,-0.01065826416015625,-0.01320648193359375,-0.003173828125,0.0191497802734375,0.0006122589111328125,-0.0035343170166015625,-0.008056640625,0.033599853515625,0.0037975311279296875,0.035186767578125,0.0038967132568359375,0.0227508544921875,0.01218414306640625,-0.00719451904296875,-0.0158233642578125,-0.0128631591796875,-0.051788330078125,0.0258941650390625,-0.030364990234375,-0.01560211181640625,-0.01152801513671875,-0.045379638671875,-0.010589599609375,0.0240631103515625,0.0180511474609375,0.02752685546875,0.034912109375,0.046844482421875,-0.01274871826171875,-0.01198577880859375,-0.03729248046875,0.00787353515625,0.0171966552734375,-0.01055908203125,-0.0172882080078125,-0.038970947265625,0.00946044921875,-0.0252838134765625,-0.043914794921875,-0.009033203125,0.0401611328125,0.017547607421875,-0.01036834716796875,0.0200347900390625,0.019134521484375,-0.01507568359375,-0.01543426513671875,-0.00490570068359375,-0.048095703125,-0.02435302734375,0.015899658203125,-0.0570068359375,0.0187530517578125,0.01495361328125,-0.04083251953125,-0.00873565673828125,-0.033477783203125,-0.032928466796875,0.00568389892578125,0.023895263671875,0.02813720703125,0.0154876708984375,-0.0112152099609375,-0.0225067138671875,0.0032634735107421875,-0.039642333984375,0.0214080810546875,-0.03717041015625,0.0255126953125,-0.024200439453125,0.0111083984375,0.0117034912109375,-0.0245513916015625,-0.007801055908203125,0.01557159423828125,-0.00024318695068359375,-0.01010894775390625,0.0018739700317382812,-0.01413726806640625,0.00455474853515625,-0.025238037109375,0.0005049705505371094,0.02215576171875,0.0163116455078125,0.004367828369140625,-0.0196685791015625,0.0027484893798828125,0.028961181640625,0.0200347900390625,-0.0259246826171875,-0.040283203125,0.02850341796875,-0.01139068603515625,-0.0107421875,0.0200042724609375,-0.006992340087890625,0.022430419921875,-0.0030193328857421875,0.0084075927734375,-0.0260772705078125,-0.0010242462158203125,0.01666259765625,0.005817413330078125,-0.027099609375,0.0628662109375,0.02581787109375,-0.0185394287109375,0.004734039306640625,0.042724609375,-0.01180267333984375,0.035369873046875,-0.011627197265625,0.007205963134765625,0.0220184326171875,-0.037628173828125,-0.009246826171875,-0.0222625732421875,-0.03192138671875,0.0175933837890625,-0.0117950439453125,0.021697998046875,-0.0086822509765625,0.04071044921875,0.0040130615234375,0.0101470947265625,-0.01776123046875,-0.003719329833984375,0.016510009765625,-0.06475830078125,0.02484130859375,-0.02294921875,-0.04254150390625,0.035430908203125,-0.0036830902099609375,0.018402099609375,-0.0201263427734375,-0.0209808349609375,-0.041748046875,0.026153564453125,0.008331298828125,-0.05364990234375,-0.0040130615234375,-0.0023708343505859375,-0.0152587890625,0.01358795166015625,-0.0084991455078125,0.0445556640625,0.02081298828125,0.038543701171875,0.00931549072265625,0.0198822021484375,0.00234222412109375,-0.037384033203125,-0.035980224609375,-0.0008053779602050781,-0.0018863677978515625,-0.00510406494140625,0.0016202926635742188,-0.005313873291015625,0.01349639892578125,0.0413818359375,-0.003910064697265625,0.01171112060546875,-0.0007953643798828125,0.0108642578125,0.0004608631134033203,-0.0185089111328125,0.029083251953125,-0.0001342296600341797,-0.0157012939453125,0.00231170654296875,0.0216064453125,-0.01654052734375,-0.03857421875,-0.00438690185546875,-0.02081298828125,-0.009063720703125,0.0242156982421875,0.03289794921875,0.008758544921875,0.0008635520935058594,-0.0028820037841796875,-0.0186614990234375,0.01198577880859375,-0.0159149169921875,-0.0078277587890625,0.00128936767578125,-0.03717041015625,0.005680084228515625,0.01383209228515625,0.03350830078125,-0.025634765625,0.004352569580078125,-0.0099029541015625,0.01496124267578125,0.0338134765625,-0.005889892578125,0.0220184326171875,0.03704833984375,0.0030155181884765625,-0.0235748291015625,-0.007419586181640625,0.00554656982421875,0.0272216796875,0.00827789306640625,0.046844482421875,-0.0124359130859375,-0.0010662078857421875,0.05755615234375,-0.0005121231079101562,0.0017766952514648438,0.0165863037109375,0.007175445556640625,0.00469970703125,-0.0016765594482421875,0.017333984375,-0.007633209228515625,0.0176849365234375,-0.00597381591796875,-0.037689208984375,-0.00266265869140625,0.009368896484375,-7.468461990356445e-5,0.0299224853515625,0.002613067626953125,-0.006160736083984375,0.0304107666015625,0.0010023117065429688,0.0096588134765625,-0.0246734619140625,0.0479736328125,-0.034027099609375,0.06097412109375,-0.00806427001953125,-0.017608642578125,0.021209716796875,0.021453857421875,0.0028972625732421875,0.0212860107421875,-0.0234222412109375,0.0015277862548828125,-0.01145172119140625,-0.0249786376953125,-0.005657196044921875,0.023651123046875,0.006267547607421875,-0.0226593017578125,-0.0201416015625,-0.01506805419921875,-0.0027942657470703125,-0.0285797119140625,0.0026073455810546875,0.038970947265625,-0.006717681884765625,0.006977081298828125,0.005428314208984375,-0.0003349781036376953,-0.005229949951171875,0.0173492431640625,0.003200531005859375,0.02374267578125,0.063720703125,-0.004192352294921875,-0.028656005859375,-0.00342559814453125,0.0158233642578125,0.007526397705078125,0.0083160400390625,-0.01012420654296875,-0.0018243789672851562,0.01873779296875,0.031646728515625,-0.002246856689453125,0.03790283203125,-0.016937255859375,-0.006992340087890625,-0.00829315185546875,-0.07574462890625,0.002338409423828125,0.0200653076171875,0.01345062255859375,-0.0221099853515625,-0.01003265380859375,0.025726318359375,-0.040771484375,-0.0002143383026123047,0.0212554931640625,-0.0168914794921875,-0.0215606689453125,-0.049072265625,-0.005435943603515625,-0.0287322998046875,-0.001300811767578125,-0.021453857421875,-0.020355224609375,0.00991058349609375,0.01690673828125,-0.031463623046875,-0.016021728515625,-0.00743865966796875,0.013397216796875,-0.0005831718444824219,-0.014373779296875,0.0190887451171875,0.016815185546875,-0.0183258056640625,0.023590087890625,0.01165008544921875,0.0247955322265625,0.007801055908203125,0.0035552978515625,0.01364898681640625,-0.015869140625,0.005672454833984375,0.042694091796875,-0.0108795166015625,-0.0014238357543945312,-0.026214599609375,0.005329132080078125,0.002964019775390625,-0.0310211181640625,0.021514892578125,-0.0296783447265625,-0.0098724365234375,-0.024261474609375,-0.03216552734375,0.0263824462890625,0.0103302001953125,0.01806640625,0.02288818359375,0.0159759521484375,-0.0210418701171875,-0.005283355712890625,-0.01049041748046875,-0.019744873046875,0.0193634033203125,0.00936126708984375,0.0101318359375,0.047027587890625,0.0217437744140625,-0.0160369873046875,0.0245819091796875,-0.01800537109375,-0.00677490234375,0.0205078125,0.01099395751953125,-0.0251312255859375,0.00824737548828125,-0.01061248779296875,0.0069580078125,-0.0177459716796875,-0.0096893310546875,0.016754150390625,0.018768310546875,-0.01030731201171875,-0.02691650390625,0.004390716552734375,-0.03509521484375,-0.004638671875,0.01245880126953125,0.00804901123046875,0.0078582763671875,-0.0084991455078125,-0.0026340484619140625,-0.016632080078125,0.00034809112548828125,-0.007518768310546875,0.033477783203125,0.03265380859375,-0.00644683837890625,-9.191036224365234e-5,-0.01380157470703125,0.00495147705078125,-0.0033206939697265625,-0.031402587890625,-0.0081787109375,0.0092926025390625,0.052276611328125,0.0021228790283203125,-0.01342010498046875,0.0143890380859375,0.016143798828125,0.00995635986328125,-0.0185699462890625,-0.01496124267578125,-0.03082275390625,0.0196533203125,0.003238677978515625,-0.031829833984375,-0.014678955078125,-0.0240478515625,-0.0287017822265625,0.01023101806640625,0.014007568359375,0.010009765625,0.005016326904296875,-0.015838623046875,-0.0231475830078125,-0.005481719970703125,0.003025054931640625,-0.038299560546875,-0.0128326416015625,0.01549530029296875,-0.0027027130126953125,-0.0193939208984375,-0.0027980804443359375,-0.00984954833984375,0.0254669189453125,-0.024810791015625,-0.00305938720703125,0.00039958953857421875,0.0282745361328125,-0.01245880126953125,-0.005062103271484375,-0.024261474609375,-0.00013196468353271484,-0.0180511474609375,-0.004299163818359375,-0.0120697021484375,0.023284912109375,0.0036449432373046875,0.004184722900390625,-0.0069580078125,0.00045609474182128906,0.0291290283203125,0.0007157325744628906,-0.02020263671875,0.1041259765625,0.01348876953125,-0.0312042236328125,0.0019893646240234375,-0.01114654541015625,0.01277923583984375,0.00482940673828125,0.0007853507995605469,-0.0064849853515625,-0.02166748046875,-0.005069732666015625,0.007053375244140625,-0.029541015625,0.01328277587890625,-0.00873565673828125,-0.01812744140625,0.0152587890625,-0.0135345458984375,-0.0122833251953125,-0.027252197265625,0.0231170654296875,0.002696990966796875,0.01143646240234375,-0.0147857666015625,0.01335906982421875,0.0014553070068359375,-0.012725830078125,-0.06488037109375,-0.0006432533264160156,0.03765869140625,0.0372314453125,-0.01374053955078125,-0.047393798828125,-0.00849151611328125,-0.0225067138671875,-0.04925537109375,-0.0005078315734863281,-0.0009064674377441406,-0.000392913818359375,-0.021453857421875,-0.0029277801513671875,-0.00872039794921875,0.01580810546875,0.00787353515625,-0.005474090576171875,-0.0011005401611328125,-0.01306915283203125,0.002346038818359375,-0.0205078125,0.01320648193359375,-0.03802490234375,0.0271759033203125,0.00960540771484375,-0.00409698486328125,-0.015899658203125,-0.030609130859375,-0.0196685791015625,0.0191497802734375,0.021759033203125,0.004322052001953125,-0.0244293212890625,-0.0019006729125976562,-0.005428314208984375,0.048614501953125,0.024993896484375,-0.01160430908203125,0.001384735107421875,-0.01433563232421875,0.01904296875,-0.00833892822265625,0.004787445068359375,0.015472412109375,0.019256591796875,-0.03826904296875,0.0228271484375,-0.01085662841796875,0.00925445556640625,-0.00019538402557373047,-0.02850341796875,-0.025054931640625,-0.0046234130859375,0.033843994140625,0.004261016845703125,0.0163116455078125,-0.0020809173583984375,-0.0183868408203125,-0.0134124755859375,0.01436614990234375,-0.024627685546875,0.0330810546875,0.00888824462890625,0.005733489990234375,0.01055908203125,0.0050506591796875,-0.0275115966796875,0.036651611328125,0.00666046142578125,-0.0078277587890625,-0.00839996337890625,-0.04046630859375,-0.010101318359375,-0.001434326171875,0.01488494873046875,0.022552490234375,-0.024627685546875,-0.0214691162109375,-0.01194000244140625,0.029998779296875,0.0082244873046875,-0.018646240234375,-0.006519317626953125,0.0016765594482421875,0.0178375244140625,-0.0194854736328125,0.01137542724609375,-0.005542755126953125,0.01318359375,-0.037322998046875,-0.022979736328125,0.0027866363525390625,-0.0095367431640625,-0.01727294921875,-0.00350189208984375,-0.010406494140625,-0.00618743896484375,-0.00904083251953125,0.0019664764404296875,0.044708251953125,0.0133819580078125,0.003936767578125,-0.0201263427734375,-0.01436614990234375,0.0034580230712890625,0.01178741455078125,-0.005184173583984375,0.047760009765625,-0.003635406494140625,-0.045257568359375,0.0280609130859375,-0.01480865478515625,0.0240478515625,-0.01088714599609375,-0.01345062255859375,0.049041748046875,-0.005863189697265625,-0.00595855712890625,0.01213836669921875,-0.01409912109375,0.02490234375,0.0023288726806640625,0.0307464599609375,0.0117340087890625,0.01983642578125,0.00852203369140625,0.04400634765625,0.03424072265625,0.0176849365234375,0.0262908935546875,0.0191497802734375,-0.004383087158203125,-0.0227203369140625,-0.026763916015625,-0.0242462158203125,-0.01947021484375,0.0297698974609375,-0.038330078125,0.007442474365234375,0.0304107666015625,-0.0030498504638671875,0.0271453857421875,-0.004119873046875,-0.014801025390625,-0.0005636215209960938,0.01206207275390625,0.003810882568359375,0.042022705078125,-0.02789306640625,0.022979736328125,0.006526947021484375,0.001373291015625,-0.0279083251953125,-0.0080718994140625,-0.0095672607421875,0.0294342041015625,-0.00844573974609375,0.01473236083984375,-0.029571533203125,0.0033016204833984375,-0.01084136962890625,-0.020721435546875,-0.00978851318359375,0.00527191162109375,0.0477294921875,0.01520538330078125,0.014404296875,-0.0186614990234375,0.01473236083984375,-0.033447265625,-0.0005588531494140625,0.0276336669921875,0.01873779296875,-0.005283355712890625,0.00940704345703125,0.03790283203125,0.0014867782592773438,0.0008044242858886719,0.035980224609375,-0.01137542724609375,-0.006557464599609375,0.01160430908203125,0.0538330078125,0.0014362335205078125,0.0215606689453125,0.03424072265625,-0.01218414306640625,0.00640869140625,0.0645751953125,0.0535888671875,-0.025665283203125,0.0151824951171875,0.01849365234375,-0.0227203369140625,-0.0058135986328125,-0.0148468017578125,0.0026397705078125,-0.012176513671875,-0.0109405517578125,-0.0251007080078125,0.00433349609375,-0.032318115234375,0.0240020751953125,0.0040740966796875,0.01206207275390625,-0.03521728515625,-0.00032639503479003906,0.0167388916015625,-0.026947021484375,-0.00045800209045410156,0.0252227783203125,0.0211334228515625,-0.029052734375,-0.0238189697265625,-0.03875732421875,-0.00582122802734375,0.0259857177734375,-0.004703521728515625,0.0218505859375,-0.010650634765625,-0.018341064453125,0.033355712890625,-0.01456451416015625,0.003955841064453125,-0.0164337158203125,-0.019439697265625,-0.0135498046875,-0.0179595947265625,-0.01446533203125,-0.0021266937255859375,0.0065460205078125,-0.0115509033203125,-0.0017910003662109375,-0.01406097412109375,-0.00798797607421875,-0.00855255126953125,0.006805419921875,0.00446319580078125,-0.00665283203125,-0.0010776519775390625,-0.046112060546875,-0.007785797119140625,-4.947185516357422e-6,-0.0091400146484375,-0.007785797119140625,0.031341552734375,-0.042724609375,0.00371551513671875,-0.01335906982421875,-0.0005517005920410156,0.01666259765625,0.025970458984375,-0.021820068359375,0.037628173828125,-0.0294189453125,-0.0301361083984375,-0.004261016845703125,0.00974273681640625,-0.005649566650390625,0.0183258056640625,0.00968170166015625,0.0136871337890625,0.01491546630859375,0.034881591796875,0.0131072998046875,0.0189361572265625,0.0092315673828125,0.01442718505859375,-0.0264129638671875,-0.0132293701171875,0.008697509765625,1.913309097290039e-5,0.0318603515625,-0.0164947509765625,0.020721435546875,-0.0212860107421875,0.03094482421875,0.02874755859375,-0.003330230712890625,0.03179931640625,0.00559234619140625,-0.01171112060546875,0.01012420654296875,-0.004039764404296875,0.0019969940185546875,-0.00582122802734375,0.0128936767578125,-0.02301025390625,0.0296783447265625,0.00033283233642578125,0.024200439453125,-0.0027599334716796875,0.0169830322265625,-0.00669097900390625,-0.011444091796875,-0.0233612060546875,0.0206298828125,0.0014371871948242188,0.048736572265625,0.0279388427734375,0.035491943359375,0.01168060302734375,0.01241302490234375,-0.0032825469970703125,-0.0215911865234375,-0.0205078125,0.03704833984375,-0.00640869140625,-0.0163116455078125,-0.024139404296875,-0.02093505859375,-0.0296783447265625,-0.0129852294921875,0.01025390625,0.0278167724609375,0.01004791259765625,-0.01337432861328125,0.04071044921875,0.03106689453125,0.01537322998046875,-0.0020656585693359375,0.010833740234375,-0.0008115768432617188,0.0270233154296875,0.0135345458984375,0.01285552978515625,0.0287322998046875,0.0225067138671875,0.03936767578125,-0.0215911865234375,-0.0262298583984375,0.004787445068359375,-0.005886077880859375,0.00107574462890625,0.01465606689453125,-0.04150390625,0.0063018798828125,0.028778076171875,-0.0157928466796875,0.0101776123046875,-0.0164031982421875,0.01103973388671875,-0.01702880859375,0.007747650146484375,-0.00994873046875,-0.003314971923828125,0.0008692741394042969,-0.004608154296875,-0.01413726806640625,-0.004703521728515625,-0.060577392578125,-0.0171661376953125,0.0202484130859375,0.00449371337890625,-0.006267547607421875,0.01155853271484375,-0.0242156982421875,-0.02197265625,-0.0301361083984375,0.0164337158203125,-0.031524658203125]',	'2026-04-20 13:10:19',	'2026-04-20 13:10:19'),
(2,	1,	'cliente',	'[-0.0035552978515625,-0.01195526123046875,0.0072174072265625,0.014404296875,0.0229644775390625,-0.007720947265625,0.011322021484375,0.04376220703125,-0.027099609375,-0.04827880859375,0.0255279541015625,-0.0004398822784423828,0.00475311279296875,-0.0208587646484375,0.01373291015625,0.032989501953125,-0.0168304443359375,-0.0157012939453125,-0.027557373046875,0.017578125,0.02569580078125,0.0394287109375,0.0572509765625,-0.039703369140625,-0.001117706298828125,0.020172119140625,-0.046844482421875,0.023681640625,0.031494140625,-0.05670166015625,0.00848388671875,-0.03753662109375,0.0311126708984375,0.006198883056640625,0.025970458984375,0.01091766357421875,0.0187835693359375,0.029815673828125,0.01739501953125,-0.0112457275390625,-0.00799560546875,0.02471923828125,0.0259857177734375,0.034210205078125,0.020355224609375,0.0018463134765625,-0.06634521484375,0.0288543701171875,0.029571533203125,0.06341552734375,-0.0460205078125,-0.0243072509765625,0.0231475830078125,0.10943603515625,-0.0022068023681640625,-0.01155853271484375,0.00975799560546875,0.01253509521484375,0.01334381103515625,0.034576416015625,0.00860595703125,-0.01800537109375,0.004909515380859375,0.00274658203125,-0.01113128662109375,-0.00928497314453125,-0.038299560546875,0.03753662109375,-0.039215087890625,0.01495361328125,0.0037250518798828125,0.0008225440979003906,-0.03204345703125,-0.011993408203125,-0.005077362060546875,-0.0092315673828125,0.006282806396484375,-0.0009608268737792969,0.0006947517395019531,-0.0109405517578125,0.005458831787109375,0.01114654541015625,-0.04376220703125,-0.0146484375,-0.00942230224609375,-0.0237274169921875,-0.07977294921875,0.034881591796875,0.018951416015625,-0.019195556640625,-0.0201568603515625,0.04345703125,0.0006189346313476562,-0.005397796630859375,0.05499267578125,0.05169677734375,-0.0234375,-0.033935546875,0.018463134765625,-0.0018291473388671875,0.067138671875,-0.0285491943359375,-0.0016450881958007812,-0.012237548828125,-0.017425537109375,0.0447998046875,-0.00844573974609375,-0.04364013671875,-0.03485107421875,0.018463134765625,0.043670654296875,0.00872039794921875,-0.0128021240234375,0.00933837890625,0.0173187255859375,-0.0281829833984375,0.0543212890625,-0.048431396484375,0.0001270771026611328,-0.059051513671875,0.05255126953125,0.03753662109375,-0.0097503662109375,-0.026702880859375,-0.023162841796875,0.00566864013671875,-0.038604736328125,-0.0009212493896484375,-0.04608154296875,-0.0291290283203125,0.00882720947265625,-0.0269775390625,0.004314422607421875,-0.0283203125,-0.03692626953125,-0.01488494873046875,0.021026611328125,-0.0194091796875,-0.0341796875,-0.0128021240234375,0.0215301513671875,-0.0263671875,0.0302276611328125,-0.0188446044921875,-0.045379638671875,-0.0222625732421875,-0.00446319580078125,0.0379638671875,-0.0245819091796875,0.01219940185546875,-0.007419586181640625,0.0168914794921875,-0.01145172119140625,-0.0121307373046875,-0.03955078125,-0.0277252197265625,0.026641845703125,-0.040985107421875,-0.04852294921875,-0.015655517578125,0.01554107666015625,-0.04046630859375,0.0235748291015625,-0.004978179931640625,-0.01308441162109375,-0.01120758056640625,-0.0350341796875,0.052764892578125,-0.041107177734375,-0.006023406982421875,-0.00406646728515625,-0.020233154296875,-0.0535888671875,-0.00376129150390625,0.00351715087890625,0.02947998046875,0.056976318359375,-0.032958984375,-0.006603240966796875,0.00787353515625,0.0271148681640625,0.06927490234375,0.05267333984375,-0.02142333984375,0.0196533203125,-0.006237030029296875,-0.024749755859375,-0.001583099365234375,0.0212554931640625,-0.04345703125,-0.035552978515625,0.0021381378173828125,0.033294677734375,0.05035400390625,0.047821044921875,-0.01235198974609375,-0.009490966796875,-2.4259090423583984e-5,-0.0489501953125,0.0029754638671875,0.0179443359375,-0.002193450927734375,0.051788330078125,-0.0029888153076171875,0.0110321044921875,-0.0167388916015625,-0.011260986328125,-0.0266876220703125,0.0116729736328125,-0.031463623046875,0.1156005859375,0.005031585693359375,-0.01013946533203125,0.0009908676147460938,-0.06805419921875,0.03564453125,0.0194549560546875,0.0139312744140625,-0.0167388916015625,0.00936126708984375,-0.01467132568359375,0.0188140869140625,0.04583740234375,-0.0104217529296875,0.0205841064453125,0.051116943359375,0.0009713172912597656,-0.060577392578125,-0.022125244140625,-0.0743408203125,-0.0011835098266601562,0.0016345977783203125,-0.006381988525390625,-0.0198211669921875,-0.0199432373046875,0.03070068359375,-0.037353515625,-0.00676727294921875,0.019378662109375,-0.0146942138671875,-0.0265960693359375,-0.043701171875,-0.028106689453125,-0.002353668212890625,-0.0147247314453125,0.0023555755615234375,0.00951385498046875,0.005535125732421875,0.0201873779296875,0.05120849609375,0.056915283203125,0.0297088623046875,-0.0026874542236328125,0.026702880859375,0.0174407958984375,0.005268096923828125,0.046600341796875,-0.0008387565612792969,0.055999755859375,-0.0231475830078125,-0.00554656982421875,-0.0303955078125,0.01201629638671875,0.0135498046875,-0.004848480224609375,-0.00992584228515625,-0.0142974853515625,-0.01171875,0.00548553466796875,0.04302978515625,-0.032745361328125,-0.002750396728515625,0.0225067138671875,0.038482666015625,-0.019134521484375,0.022216796875,0.0250244140625,0.01018524169921875,-0.0196685791015625,0.01514434814453125,-0.0614013671875,-0.029052734375,0.0316162109375,-0.0070037841796875,0.0157470703125,0.068115234375,-0.00887298583984375,-0.034698486328125,0.037994384765625,0.0255584716796875,0.0191802978515625,-0.0257568359375,-0.0216827392578125,-0.02850341796875,0.0261993408203125,0.0221099853515625,0.042144775390625,-0.05035400390625,-0.0095977783203125,-0.00283050537109375,-0.00567626953125,0.056915283203125,-0.0240020751953125,-0.00518798828125,-0.039794921875,0.033843994140625,0.031158447265625,-0.009002685546875,0.0101776123046875,-0.032928466796875,-0.0361328125,-0.027557373046875,0.0102996826171875,0.01311492919921875,0.0018014907836914062,-0.045806884765625,0.029449462890625,-0.00998687744140625,0.0052490234375,-0.006107330322265625,-0.00861358642578125,-0.0140228271484375,-0.0180816650390625,-0.0227813720703125,-0.042327880859375,-0.03240966796875,-0.028533935546875,-0.052825927734375,0.04425048828125,-0.010101318359375,-0.006343841552734375,-0.05194091796875,0.01076507568359375,0.005245208740234375,0.03106689453125,0.021270751953125,-0.017242431640625,0.0276336669921875,-0.00897216796875,-0.005435943603515625,-0.01715087890625,-0.022918701171875,-0.044158935546875,-0.0194244384765625,0.053558349609375,-0.05230712890625,0.06402587890625,0.01824951171875,0.043182373046875,-0.0013561248779296875,0.0004813671112060547,0.023040771484375,0.0024585723876953125,0.0377197265625,-0.0426025390625,0.0007457733154296875,0.0088653564453125,-0.00505828857421875,-0.0002582073211669922,0.02490234375,-0.01296234130859375,-0.004734039306640625,-0.0031108856201171875,-0.0241851806640625,0.0235595703125,-0.0205535888671875,-0.05950927734375,0.0019931793212890625,-0.00457763671875,-0.029144287109375,0.00899505615234375,-0.01611328125,-0.014495849609375,0.01403045654296875,-0.053558349609375,-0.005939483642578125,-0.0330810546875,0.047088623046875,0.01042938232421875,0.0147705078125,-0.00658416748046875,0.0008635520935058594,-0.004329681396484375,-0.0164794921875,0.0271148681640625,-0.0115966796875,0.0019025802612304688,0.069580078125,0.0103607177734375,-0.033447265625,0.0208740234375,-0.004985809326171875,0.00557708740234375,-0.04010009765625,0.040069580078125,0.01012420654296875,0.04510498046875,0.024169921875,0.0245361328125,-0.0105438232421875,0.01096343994140625,-0.0262451171875,0.0165557861328125,0.009857177734375,-0.039886474609375,-0.017578125,-0.060150146484375,0.0255584716796875,0.037353515625,-0.019775390625,-0.0054168701171875,-0.0204315185546875,0.018157958984375,0.0885009765625,0.022857666015625,-0.02154541015625,-0.0311126708984375,-0.03717041015625,-0.007450103759765625,0.0296783447265625,-0.0032596588134765625,0.001056671142578125,-0.00672149658203125,0.0015697479248046875,-0.015655517578125,0.034942626953125,0.00644683837890625,0.00450897216796875,-0.058380126953125,-0.00411224365234375,-0.003231048583984375,0.0291748046875,-0.01904296875,-0.0015468597412109375,-0.059539794921875,-0.00801849365234375,-0.0017690658569335938,0.00623321533203125,0.007305145263671875,-0.0259857177734375,-0.07281494140625,-0.004352569580078125,0.0200042724609375,0.022125244140625,0.0634765625,-0.0304412841796875,0.013641357421875,-0.025604248046875,-0.03839111328125,-0.032806396484375,-0.00780487060546875,0.0164642333984375,0.034637451171875,-0.0184783935546875,-0.028594970703125,0.0045166015625,0.0190277099609375,0.0294342041015625,0.005046844482421875,0.0231475830078125,-0.01398468017578125,-0.00800323486328125,-0.0189208984375,0.05096435546875,0.0165863037109375,0.0040283203125,-0.01043701171875,0.03033447265625,0.015106201171875,-0.0299072265625,-0.00701141357421875,0.05609130859375,-0.004184722900390625,0.01352691650390625,-0.05255126953125,0.019500732421875,-0.0107421875,0.025482177734375,-0.013641357421875,-0.0287322998046875,0.0186614990234375,0.024444580078125,-0.007328033447265625,0.03387451171875,0.0016794204711914062,0.12335205078125,-0.0010509490966796875,0.00620269775390625,-0.022003173828125,0.004207611083984375,0.0633544921875,0.058380126953125,0.03643798828125,-0.0096893310546875,-0.04345703125,-0.0156402587890625,-0.0008835792541503906,-0.05963134765625,-0.01009368896484375,-0.072021484375,-0.01049041748046875,-0.0184173583984375,-0.0673828125,0.036895751953125,-0.01611328125,0.052642822265625,-0.035125732421875,-0.0345458984375,0.029449462890625,-0.0106201171875,0.039703369140625,0.053863525390625,-0.0270233154296875,-0.00833892822265625,-0.011474609375,0.00765228271484375,-0.0278167724609375,0.00024020671844482422,-0.0552978515625,0.00411224365234375,0.0212860107421875,-0.0016317367553710938,-0.0020904541015625,-0.032012939453125,-0.01204681396484375,0.024078369140625,0.0137481689453125,-0.06597900390625,-0.0360107421875,-0.0024814605712890625,0.027496337890625,-0.0218048095703125,0.0173492431640625,0.0313720703125,0.01035308837890625,0.0234527587890625,0.013824462890625,0.016357421875,0.00988006591796875,0.00632476806640625,-0.00786590576171875,0.01531219482421875,-0.0322265625,-0.00034356117248535156,-0.0535888671875,0.0246124267578125,-0.019744873046875,-0.01134490966796875,3.606081008911133e-5,0.03619384765625,-0.00524139404296875,-0.0194549560546875,-0.00490570068359375,0.0031280517578125,0.0008988380432128906,-0.0438232421875,0.02069091796875,-0.0276031494140625,0.0079193115234375,-0.0093231201171875,-0.03912353515625,0.0016508102416992188,0.0157623291015625,-0.028594970703125,-0.032684326171875,0.0026111602783203125,-0.00254058837890625,-0.01502227783203125,-0.046600341796875,-0.005863189697265625,-0.0206451416015625,0.06390380859375,-0.019775390625,0.0667724609375,0.011077880859375,-0.002590179443359375,-0.006076812744140625,0.0058135986328125,-0.0144500732421875,-0.011688232421875,-0.01264190673828125,0.01904296875,0.0087432861328125,0.01904296875,-0.00646209716796875,-0.0186004638671875,0.0333251953125,0.02301025390625,-0.02349853515625,0.010162353515625,0.0013055801391601562,-0.020538330078125,0.0130157470703125,0.01480865478515625,0.017669677734375,0.0080108642578125,0.0054473876953125,0.020111083984375,-0.033203125,-0.0128326416015625,0.00830841064453125,-0.00536346435546875,0.0193939208984375,-0.002849578857421875,0.042510986328125,0.0061798095703125,-0.007656097412109375,0.01433563232421875,0.0260772705078125,-0.004100799560546875,0.0060882568359375,0.00653076171875,0.040924072265625,-0.03167724609375,-0.041351318359375,0.00691986083984375,-0.0172119140625,-0.01092529296875,0.00862884521484375,0.032867431640625,-0.0555419921875,0.006664276123046875,0.040985107421875,0.032257080078125,-0.007049560546875,0.0274505615234375,-0.029449462890625,-0.04107666015625,-0.003162384033203125,-0.0021152496337890625,0.0098419189453125,0.0060882568359375,-0.01226043701171875,-0.0068511962890625,-0.01390838623046875,-0.025421142578125,0.021636962890625,0.0295257568359375,-0.0152130126953125,-0.044403076171875,-0.007228851318359375,0.018157958984375,-0.00693511962890625,-0.0204620361328125,0.0303955078125,-0.00308990478515625,0.0256195068359375,0.0013589859008789062,-0.0207366943359375,0.00860595703125,-0.024383544921875,0.0226287841796875,0.011383056640625,-0.0604248046875,-0.0014705657958984375,-0.01129150390625,-0.017730712890625,-0.00426483154296875,0.0212554931640625,0.01678466796875,-0.01141357421875,0.0164947509765625,0.00368499755859375,-0.029266357421875,-0.005298614501953125,0.015960693359375,-0.0193328857421875,-0.018310546875,-0.04876708984375,-0.00479888916015625,0.003910064697265625,0.0479736328125,0.037322998046875,0.005115509033203125,0.0211334228515625,-0.0176239013671875,0.0005536079406738281,-0.03985595703125,0.0009331703186035156,-0.00939178466796875,-0.03363037109375,-0.0118865966796875,0.00977325439453125,0.016021728515625,-0.03485107421875,0.0024814605712890625,-0.00934600830078125,-0.019866943359375,0.007350921630859375,0.0562744140625,-0.01244354248046875,0.00675201416015625,0.0601806640625,3.975629806518555e-5,0.02154541015625,-0.04998779296875,0.0256195068359375,-0.0168304443359375,0.0023937225341796875,0.042724609375,-0.0049591064453125,-0.01103973388671875,0.01328277587890625,0.01285552978515625,-0.0199432373046875,0.0005950927734375,0.004489898681640625,0.02154541015625,0.0017328262329101562,0.03558349609375,0.014434814453125,0.01371002197265625,-0.0167694091796875,-0.014495849609375,-0.02520751953125,0.0185394287109375,-0.027069091796875,0.034698486328125,0.0239105224609375,-0.019287109375,-0.0204925537109375,-0.0027313232421875,0.0067291259765625,-0.00218963623046875,0.0063934326171875,-0.029266357421875,-0.0241851806640625,0.022491455078125,-0.00447845458984375,0.052947998046875,0.00431060791015625,0.0309295654296875,0.012939453125,0.0030727386474609375,-0.03948974609375,-0.01152801513671875,-0.054901123046875,0.005031585693359375,-0.01253509521484375,-0.0240325927734375,-0.00557708740234375,-0.0426025390625,-0.025970458984375,0.00921630859375,0.0005583763122558594,0.0180511474609375,0.0216827392578125,0.03826904296875,-0.016021728515625,0.00814056396484375,-0.017974853515625,0.00482940673828125,-0.0072479248046875,-0.0263214111328125,-0.03997802734375,-0.0271453857421875,0.0208892822265625,-0.00884246826171875,-0.03875732421875,0.00946044921875,0.016082763671875,0.019561767578125,0.00888824462890625,0.0290985107421875,0.0147705078125,-0.033355712890625,-0.003269195556640625,-0.0289154052734375,-0.052215576171875,-0.021026611328125,0.02191162109375,-0.06524658203125,-0.0143585205078125,0.0201263427734375,-0.0106353759765625,-0.0141754150390625,-0.048614501953125,-0.019866943359375,0.01474761962890625,0.0360107421875,0.0217132568359375,0.00665283203125,-0.03662109375,-0.021942138671875,0.0306243896484375,-0.049072265625,-0.002704620361328125,-0.0109710693359375,0.0203704833984375,-0.023956298828125,0.011444091796875,0.0010690689086914062,-0.04156494140625,0.002109527587890625,0.018707275390625,-0.0017328262329101562,-0.0041046142578125,-0.00887298583984375,-0.004360198974609375,-0.0035686492919921875,-0.01971435546875,-0.01953125,0.0208892822265625,0.01064300537109375,0.027313232421875,-0.00799560546875,0.00885009765625,0.0171051025390625,0.02197265625,-0.0335693359375,-0.0229339599609375,0.021942138671875,-0.01258087158203125,-0.0104217529296875,0.0125579833984375,-0.0477294921875,0.0159454345703125,0.00397491455078125,-0.0186309814453125,-0.01415252685546875,0.0223541259765625,0.026824951171875,-0.0110321044921875,-0.041412353515625,0.0716552734375,0.0196685791015625,-0.0192718505859375,0.01319122314453125,0.0251617431640625,-0.01079559326171875,0.025604248046875,0.00909423828125,-0.0024776458740234375,0.006572723388671875,-0.04736328125,-0.0194854736328125,-0.011505126953125,-0.034332275390625,0.005077362060546875,-0.0256500244140625,0.013916015625,-0.029266357421875,0.030181884765625,0.0120849609375,-0.0003452301025390625,-0.034515380859375,0.00860595703125,0.0124969482421875,-0.0472412109375,0.0175933837890625,-0.032562255859375,-0.06805419921875,0.020172119140625,-0.034271240234375,0.04425048828125,-0.036102294921875,-0.017730712890625,-0.048492431640625,0.006977081298828125,-0.007297515869140625,-0.046905517578125,-0.0013408660888671875,-0.00971221923828125,-0.01221466064453125,0.011260986328125,-0.0085296630859375,0.026824951171875,0.005985260009765625,0.05474853515625,0.0304718017578125,0.0229644775390625,0.00623321533203125,-0.02215576171875,-0.0295257568359375,0.020477294921875,0.022308349609375,-0.0146484375,0.019378662109375,0.0012874603271484375,0.0310211181640625,0.032623291015625,-0.03790283203125,0.0239105224609375,-0.007099151611328125,0.015472412109375,-0.00308990478515625,-0.017486572265625,-0.002941131591796875,-0.01316070556640625,-0.01517486572265625,0.002788543701171875,0.042633056640625,0.016876220703125,-0.047149658203125,-0.006885528564453125,-0.0026111602783203125,-0.01004791259765625,0.020416259765625,0.0021915435791015625,-0.018951416015625,0.0002560615539550781,-0.01560211181640625,-0.005596160888671875,0.004909515380859375,-0.02935791015625,-0.0014104843139648438,0.01174163818359375,-0.0227508544921875,0.00753021240234375,0.0394287109375,0.04443359375,-0.056396484375,-0.005794525146484375,-0.0231475830078125,0.00897979736328125,0.041412353515625,-0.0067291259765625,0.020233154296875,0.03619384765625,0.0110321044921875,-0.01224517822265625,-0.0019588470458984375,-0.022735595703125,0.0157318115234375,-0.0015382766723632812,0.044921875,-0.01178741455078125,0.01039886474609375,0.03564453125,0.00940704345703125,-0.01678466796875,0.0278167724609375,0.0115814208984375,0.0014095306396484375,0.005626678466796875,-0.033050537109375,0.0054168701171875,0.0073699951171875,0.00217437744140625,-0.043731689453125,-0.0246734619140625,0.048248291015625,0.00762176513671875,0.04339599609375,0.0305328369140625,0.0030612945556640625,0.046966552734375,0.003894805908203125,0.005504608154296875,-0.018096923828125,0.033203125,-0.044891357421875,0.049407958984375,-0.002826690673828125,-0.01465606689453125,0.004833221435546875,0.0247955322265625,-0.01367950439453125,0.004154205322265625,-0.00765228271484375,0.0019626617431640625,-0.022216796875,-0.0201873779296875,0.007293701171875,-0.01264190673828125,0.009490966796875,-0.03564453125,-0.018035888671875,0.026641845703125,0.0037937164306640625,-0.03759765625,0.01202392578125,0.045928955078125,0.0061798095703125,0.016387939453125,-0.00466156005859375,-0.00994110107421875,-0.02154541015625,0.00566864013671875,0.0029697418212890625,0.02362060546875,0.045745849609375,0.0209808349609375,-0.01462554931640625,-0.0229034423828125,0.028900146484375,0.005401611328125,0.01180267333984375,-0.0146484375,0.0229339599609375,-0.00925445556640625,0.0199737548828125,0.0162353515625,0.051666259765625,-0.01209259033203125,0.00798797607421875,-0.0072174072265625,-0.045928955078125,-0.01526641845703125,-0.007068634033203125,0.032623291015625,-0.0220489501953125,-0.01235198974609375,0.0498046875,-0.00801849365234375,0.01169586181640625,-0.0039520263671875,-0.0138397216796875,-0.0127105712890625,-0.04461669921875,-0.0087890625,-0.034881591796875,0.00287628173828125,-0.0165557861328125,-0.0079193115234375,0.005645751953125,0.00860595703125,-0.01384735107421875,0.0023174285888671875,-0.006595611572265625,0.0238189697265625,-0.0055084228515625,-0.0015697479248046875,0.01337432861328125,0.01422882080078125,-0.023590087890625,0.02056884765625,0.002109527587890625,0.0241851806640625,0.01018524169921875,0.0100860595703125,0.008087158203125,-0.0102691650390625,-0.012176513671875,0.03497314453125,0.007419586181640625,0.0164642333984375,-0.00588226318359375,0.01258087158203125,-0.0116424560546875,0.0010223388671875,0.00873565673828125,-0.009246826171875,-0.004253387451171875,-0.01934814453125,-0.023040771484375,-0.002658843994140625,0.003082275390625,-0.00862884521484375,0.0271148681640625,-0.0045928955078125,-0.014495849609375,-0.020233154296875,-0.0073394775390625,-0.03125,0.004520416259765625,0.007419586181640625,0.008880615234375,0.0545654296875,0.0193328857421875,-0.004573822021484375,0.0233306884765625,-0.01316070556640625,-0.007293701171875,0.0401611328125,0.0199432373046875,-0.0035724639892578125,0.0285797119140625,-0.01898193359375,0.016021728515625,-0.032012939453125,0.01690673828125,0.0298919677734375,0.00016546249389648438,0.0013246536254882812,-0.03460693359375,-0.0242919921875,-0.01467132568359375,-0.01503753662109375,0.0198974609375,0.00347900390625,0.02520751953125,-0.01544952392578125,-0.014129638671875,-0.0021228790283203125,0.00565338134765625,-0.01560211181640625,0.027099609375,0.00632476806640625,-0.00788116455078125,0.003246307373046875,-0.001995086669921875,0.0016908645629882812,0.00650787353515625,-0.0201263427734375,0.019073486328125,0.0223388671875,0.041412353515625,0.008453369140625,-0.0242462158203125,0.0020275115966796875,-0.00044035911560058594,0.0180206298828125,-0.038909912109375,-0.009307861328125,0.01084136962890625,0.017974853515625,-0.017333984375,-0.0321044921875,0.0090789794921875,-0.024261474609375,-0.01380157470703125,0.018951416015625,0.0101165771484375,0.0218353271484375,0.0147247314453125,-0.01258087158203125,-0.00977325439453125,-0.00948333740234375,0.0099945068359375,-0.0211334228515625,-0.030517578125,0.037445068359375,0.0075225830078125,-0.0164947509765625,-0.00682830810546875,-0.0178680419921875,0.0548095703125,-0.0576171875,-0.00614166259765625,-0.0171051025390625,0.01055145263671875,-0.00160980224609375,-0.02740478515625,0.002788543701171875,0.026336669921875,-0.004161834716796875,0.0101165771484375,0.0006003379821777344,0.0233917236328125,-0.002094268798828125,-0.00171661376953125,-0.001617431640625,0.0099945068359375,-0.00022733211517333984,-0.0218658447265625,-0.044891357421875,0.10565185546875,-0.0030269622802734375,-0.0162200927734375,0.0169677734375,0.001979827880859375,0.006145477294921875,0.009429931640625,-0.002552032470703125,-0.00443267822265625,-0.019256591796875,0.003070831298828125,0.00843048095703125,-0.0224761962890625,0.01114654541015625,0.01074981689453125,-0.012786865234375,0.003101348876953125,-0.0122222900390625,-0.0210113525390625,-0.023101806640625,0.03173828125,-0.017578125,0.028961181640625,-0.00972747802734375,0.0031719207763671875,-0.005161285400390625,-0.0185699462890625,-0.06689453125,0.00527191162109375,0.035064697265625,0.024810791015625,-0.00701141357421875,-0.01422119140625,-0.0188751220703125,-0.038116455078125,-0.032989501953125,-0.00980377197265625,-0.0249786376953125,-0.0033321380615234375,-0.0323486328125,-0.00287628173828125,0.01143646240234375,0.0216827392578125,0.0038280487060546875,-0.01291656494140625,0.00872039794921875,-0.003253936767578125,0.003948211669921875,-0.03094482421875,-0.006290435791015625,-0.0289154052734375,0.0272369384765625,-0.00850677490234375,-0.005397796630859375,-0.0192413330078125,-0.0173797607421875,-0.0225830078125,0.0038394927978515625,0.03900146484375,0.006320953369140625,-0.0255126953125,-0.004512786865234375,-0.0134124755859375,0.05743408203125,0.02691650390625,-0.010467529296875,-0.0035400390625,-0.0222625732421875,0.01371002197265625,0.017791748046875,-0.00801849365234375,0.010650634765625,0.0136566162109375,-0.0160675048828125,0.01195526123046875,0.023895263671875,0.006011962890625,-0.01206207275390625,-0.024932861328125,0.009307861328125,0.0112457275390625,0.041961669921875,0.01433563232421875,0.019989013671875,0.0014753341674804688,-0.019805908203125,0.0291290283203125,-0.0006308555603027344,-0.0223388671875,0.00437164306640625,0.03009033203125,0.0036525726318359375,-0.0036067962646484375,0.00693511962890625,-0.0250701904296875,0.033782958984375,-0.0106353759765625,0.00290679931640625,0.0101165771484375,-0.049224853515625,-0.0183868408203125,0.006923675537109375,0.0009431838989257812,0.00601959228515625,-0.00785064697265625,-0.039337158203125,-0.00217437744140625,0.03759765625,0.00598907470703125,-0.03204345703125,0.0092315673828125,-0.0004093647003173828,0.01499176025390625,-0.0226287841796875,0.024566650390625,-0.034759521484375,0.035675048828125,-0.03558349609375,-0.0245361328125,0.0027294158935546875,-0.00829315185546875,-0.0162353515625,-0.0223846435546875,-0.01059722900390625,-0.0171051025390625,-0.005916595458984375,-0.0087432861328125,0.02557373046875,0.02899169921875,0.0022182464599609375,-0.0261993408203125,-0.031982421875,-0.020294189453125,0.01111602783203125,0.004268646240234375,0.03363037109375,0.0053863525390625,-0.036376953125,0.024627685546875,-0.0234222412109375,0.0267791748046875,-0.015838623046875,0.0013561248779296875,0.031463623046875,-0.0011959075927734375,-0.008514404296875,0.011688232421875,-0.01390838623046875,0.0171356201171875,0.0002868175506591797,0.03790283203125,0.0219573974609375,0.007511138916015625,-0.0154876708984375,0.0233154296875,0.02899169921875,0.00726318359375,0.0283203125,0.032806396484375,-0.009796142578125,-0.018310546875,-0.02154541015625,-0.0001392364501953125,-0.03619384765625,0.029388427734375,-0.02117919921875,0.0094757080078125,0.0164031982421875,-0.000701904296875,0.0177459716796875,0.0009360313415527344,-0.0125885009765625,-0.006580352783203125,0.01294708251953125,0.037445068359375,0.025238037109375,-0.01580810546875,0.01058197021484375,0.0139312744140625,0.01113128662109375,-0.0300750732421875,0.0021686553955078125,-0.0231781005859375,0.0372314453125,-0.0020542144775390625,0.01271820068359375,-0.042877197265625,-0.0026226043701171875,-0.0127105712890625,-0.03857421875,0.0032405853271484375,0.0034332275390625,0.03729248046875,0.0206451416015625,-0.004608154296875,0.00405120849609375,0.0196533203125,-0.0430908203125,0.0015974044799804688,0.0022430419921875,0.00366973876953125,-0.00882720947265625,0.000530242919921875,0.0292205810546875,0.00909423828125,0.00867462158203125,0.0233306884765625,-0.00431060791015625,0.004337310791015625,0.01348876953125,0.03668212890625,0.0256195068359375,0.03375244140625,0.040313720703125,-0.0175018310546875,0.0076751708984375,0.0517578125,0.06158447265625,-0.006313323974609375,0.0209808349609375,0.042022705078125,-0.0169219970703125,0.00980377197265625,0.00527191162109375,0.01467132568359375,-0.0115509033203125,-0.0308380126953125,-0.0212860107421875,0.01409149169921875,-0.04095458984375,0.00743865966796875,0.0189056396484375,0.01139068603515625,-0.03948974609375,-0.0177764892578125,0.0192718505859375,-0.006595611572265625,7.092952728271484e-5,0.0198516845703125,0.0166015625,0.0009851455688476562,0.0030879974365234375,-0.03216552734375,-0.007572174072265625,0.0408935546875,0.0136871337890625,0.0029125213623046875,0.005695343017578125,-0.003856658935546875,0.018890380859375,0.01248931884765625,0.0131378173828125,-0.00417327880859375,-0.0025539398193359375,-0.017791748046875,-0.035980224609375,0.00818634033203125,0.00010281801223754883,-0.00769805908203125,-0.0159149169921875,0.0185089111328125,-0.0020503997802734375,0.00039196014404296875,-0.0181732177734375,0.01091766357421875,-0.0142669677734375,0.004184722900390625,0.008819580078125,-0.031768798828125,0.0034275054931640625,0.00565338134765625,-0.00867462158203125,0.00463104248046875,0.044708251953125,-0.0194244384765625,0.0008029937744140625,-0.018585205078125,-0.01371002197265625,0.032196044921875,-0.01096343994140625,-0.0022106170654296875,0.03399658203125,-0.0093841552734375,-0.0312042236328125,-0.00202178955078125,-0.0032634735107421875,0.006977081298828125,0.041412353515625,-0.01129913330078125,-0.0084991455078125,0.00272369384765625,0.029266357421875,0.0132598876953125,-0.00194549560546875,0.02972412109375,0.0243988037109375,-0.047607421875,-0.005084991455078125,0.0030059814453125,-0.0179443359375,0.017791748046875,-0.03631591796875,-0.01110076904296875,-0.021728515625,0.0352783203125,0.01125335693359375,-0.02362060546875,0.0193939208984375,-0.014862060546875,-0.0299072265625,0.0008831024169921875,-0.0174102783203125,-0.0177764892578125,0.01479339599609375,0.0220489501953125,-0.01074981689453125,0.017974853515625,-0.021026611328125,0.0271148681640625,0.00498199462890625,-0.0130767822265625,-0.0096435546875,-0.0308074951171875,0.0054931640625,0.025848388671875,0.01497650146484375,0.0295867919921875,0.0330810546875,0.0290985107421875,0.017486572265625,0.00649261474609375,-0.0088653564453125,-0.01898193359375,-0.0218353271484375,0.05377197265625,0.0009622573852539062,-0.0233917236328125,-0.00653839111328125,-0.01338958740234375,-0.0034313201904296875,-0.01035308837890625,0.035552978515625,-0.00457763671875,-0.01197052001953125,0.002864837646484375,0.03271484375,0.0088043212890625,0.023468017578125,-0.0165863037109375,0.0275421142578125,-0.0033893585205078125,0.005931854248046875,-0.0007734298706054688,0.0174560546875,0.0113983154296875,0.01490020751953125,0.03411865234375,-0.0174713134765625,-0.00618743896484375,0.004917144775390625,-0.01085662841796875,-0.0277252197265625,0.01129150390625,-0.08221435546875,-0.0098114013671875,0.048065185546875,0.0072479248046875,-0.005672454833984375,0.006481170654296875,0.01287841796875,-0.0187530517578125,-0.0161590576171875,0.007190704345703125,-0.017486572265625,-0.012969970703125,0.016571044921875,-0.0157623291015625,-0.028594970703125,-0.04254150390625,-0.0164947509765625,-0.0041046142578125,-0.0075225830078125,-0.020843505859375,0.0242156982421875,-0.01204681396484375,-0.0122222900390625,-0.02569580078125,0.03070068359375,-0.01690673828125]',	'2026-04-20 13:10:19',	'2026-04-20 13:10:19');

DROP TABLE IF EXISTS "instagram_keyword_rules";
DROP SEQUENCE IF EXISTS instagram_keyword_rules_id_seq;
CREATE SEQUENCE instagram_keyword_rules_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."instagram_keyword_rules" (
    "id" bigint DEFAULT nextval('instagram_keyword_rules_id_seq') NOT NULL,
    "is_active" boolean DEFAULT true NOT NULL,
    "keywords" json NOT NULL,
    "comment_reply_variants" json NOT NULL,
    "dm_phase1_text" text,
    "dm_quick_replies" json,
    "dm_phase2_reply_variants" json,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "instagram_keyword_rules_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

INSERT INTO "instagram_keyword_rules" ("id", "is_active", "keywords", "comment_reply_variants", "dm_phase1_text", "dm_quick_replies", "dm_phase2_reply_variants", "created_at", "updated_at") VALUES
(1,	't',	'["clientes","cliente"]',	 E'["\\u00a1Hecho! Te acabo de enviar el enlace por privado \\ud83d\\udce9","Ya te he dejado toda la info en mensajes \\ud83d\\ude4c","Te acabo de escribir por privado con los detalles \\ud83d\\udc40","Listo, revisa tus mensajes que ya te lo he pasado \\ud83d\\udd17","\\u00a1Enviado! \\u00c9chale un vistazo y me dices \\ud83d\\ude0a","Te he mandado el enlace por DM, cuando puedas lo miras \\ud83d\\ude09","Ya tienes la info por privado, cualquier cosa me dices \\ud83d\\udcac","\\u00a1Gracias por comentar! Ya te he escrito por mensaje directo \\ud83d\\udcf2","Perfecto, acabo de envi\\u00e1rtelo por MD \\u2709\\ufe0f","Revisa tus mensajes, ya te he compartido el enlace \\ud83d\\ude80","\\u00a1Ya est\\u00e1! Te he escrito por privado con todo \\ud83d\\udd0d","Acabo de pasarte la info por mensaje directo, atento\\/a \\ud83d\\udce9","Te he enviado el acceso por privado, dime si te ha llegado \\u2714\\ufe0f","Ya tienes el enlace en tus mensajes, \\u00a1espero que te sirva! \\ud83d\\ude4c","\\u00a1Gracias! Te he mandado todo por DM, quedo pendiente \\ud83d\\udca1"]',	'Hola!

Vi que comentaste “clientes” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace 🔗',	'[{"title":"OBTENER ACCESO","payload":"OBTENER ACCESO"}]',	 E'["https:\\/\\/mailerfind.com\\/"]',	'2026-04-20 12:10:48',	'2026-04-20 12:14:07'),
(2,	't',	'["prompt","prompts"]',	 E'["\\u00a1Hecho! Te acabo de enviar el enlace por privado \\ud83d\\udce9","Ya te he dejado toda la info en mensajes \\ud83d\\ude4c","Te acabo de escribir por privado con los detalles \\ud83d\\udc40","Listo, revisa tus mensajes que ya te lo he pasado \\ud83d\\udd17","\\u00a1Enviado! \\u00c9chale un vistazo y me dices \\ud83d\\ude0a","Te he mandado el enlace por DM, cuando puedas lo miras \\ud83d\\ude09","Ya tienes la info por privado, cualquier cosa me dices \\ud83d\\udcac","\\u00a1Gracias por comentar! Ya te he escrito por mensaje directo \\ud83d\\udcf2","Perfecto, acabo de envi\\u00e1rtelo por MD \\u2709\\ufe0f","Revisa tus mensajes, ya te he compartido el enlace \\ud83d\\ude80","\\u00a1Ya est\\u00e1! Te he escrito por privado con todo \\ud83d\\udd0d","Acabo de pasarte la info por mensaje directo, atento\\/a \\ud83d\\udce9","Te he enviado el acceso por privado, dime si te ha llegado \\u2714\\ufe0f","Ya tienes el enlace en tus mensajes, \\u00a1espero que te sirva! \\ud83d\\ude4c","\\u00a1Gracias! Te he mandado todo por DM, quedo pendiente \\ud83d\\udca1"]',	'Hola!

Vi que comentaste “prompt” en el reel 👀

Te paso acceso a Mailerfind, una herramienta pensada para conseguir el contacto de potenciales clientes para que puedas contactar con ellos y así aumentar tus ventas de forma mucho más inteligente 📈

Toca el botón de abajo y te envío el enlace y el prompt 🔗',	'[{"title":"PROMPT","payload":"PROMPT"}]',	 E'["https:\\/\\/mailerfind.com\\/\\n\\nPrompt:\\n\\nAnaliza los seguidores de {PON AQU\\u00cd LA CUENTA DE INSTAGRAM} y dame una lista con todos los leads calificados que haya. Ponlo en marcha."]',	'2026-07-24 18:22:08',	'2026-07-24 18:24:15');

DROP TABLE IF EXISTS "job_batches";
CREATE TABLE "public"."job_batches" (
    "id" character varying(255) NOT NULL,
    "name" character varying(255) NOT NULL,
    "total_jobs" integer NOT NULL,
    "pending_jobs" integer NOT NULL,
    "failed_jobs" integer NOT NULL,
    "failed_job_ids" text NOT NULL,
    "options" text,
    "cancelled_at" integer,
    "created_at" integer NOT NULL,
    "finished_at" integer,
    CONSTRAINT "job_batches_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);


DROP TABLE IF EXISTS "jobs";
DROP SEQUENCE IF EXISTS jobs_id_seq;
CREATE SEQUENCE jobs_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."jobs" (
    "id" bigint DEFAULT nextval('jobs_id_seq') NOT NULL,
    "queue" character varying(255) NOT NULL,
    "payload" text NOT NULL,
    "attempts" smallint NOT NULL,
    "reserved_at" integer,
    "available_at" integer NOT NULL,
    "created_at" integer NOT NULL,
    CONSTRAINT "jobs_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE INDEX jobs_queue_index ON public.jobs USING btree (queue);


DROP TABLE IF EXISTS "migrations";
DROP SEQUENCE IF EXISTS migrations_id_seq;
CREATE SEQUENCE migrations_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."migrations" (
    "id" integer DEFAULT nextval('migrations_id_seq') NOT NULL,
    "migration" character varying(255) NOT NULL,
    "batch" integer NOT NULL,
    CONSTRAINT "migrations_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

INSERT INTO "migrations" ("id", "migration", "batch") VALUES
(1,	'0001_01_01_000000_create_users_table',	1),
(2,	'0001_01_01_000001_create_cache_table',	1),
(3,	'0001_01_01_000002_create_jobs_table',	1),
(4,	'2025_02_28_000001_create_google_tokens_table',	2),
(5,	'2025_02_28_000002_create_bookings_table',	2),
(6,	'2026_03_30_163356_create_teeth_cleanings_table',	3),
(7,	'2026_03_30_165432_add_phase_to_teeth_prompts_table',	4),
(8,	'2026_03_30_170120_create_phone_away_prompts_and_records_tables',	4),
(9,	'2026_04_06_120000_add_closed_at_to_telegram_prompt_tables',	5),
(10,	'2026_04_07_120000_run_dental_history_seeder',	5),
(11,	'2026_04_06_180000_add_telegram_message_id_to_teeth_cleanings_table',	6),
(12,	'2026_04_07_200000_seed_personal_panel_user',	6),
(13,	'2026_04_08_120000_add_delay_reason_and_phase_to_teeth_cleanings_table',	6),
(14,	'2026_04_08_140000_teeth_cleanings_completed_and_response_note',	6),
(15,	'2026_04_09_100000_send_april_7_2026_telegram_prompts',	6),
(16,	'2026_04_17_120000_create_instagram_direct_messages_table',	7),
(17,	'2026_04_20_120000_create_instagram_keyword_rules_table',	8),
(18,	'2026_04_20_140000_drop_sort_order_from_instagram_keyword_rules_table',	8),
(19,	'2026_04_20_155000_enable_pgvector_extension',	9),
(20,	'2026_04_20_160000_create_instagram_keyword_rule_embeddings_table',	9),
(21,	'2026_04_17_140000_update_password_joanpd0_gmail',	10),
(22,	'2026_05_02_104253_add_google_token_to_users_table',	11),
(23,	'2026_05_02_120000_drop_google_tokens_table',	11),
(24,	'2026_05_02_180000_remove_google_calendar_from_database',	11),
(25,	'2026_05_02_190000_create_calendar_chats_tables',	11),
(26,	'2026_05_02_200000_create_calendar_message_change_logs_table',	11),
(27,	'2026_05_02_211500_create_calendar_event_indexes_table',	11);

DROP TABLE IF EXISTS "password_reset_tokens";
CREATE TABLE "public"."password_reset_tokens" (
    "email" character varying(255) NOT NULL,
    "token" character varying(255) NOT NULL,
    "created_at" timestamp(0),
    CONSTRAINT "password_reset_tokens_pkey" PRIMARY KEY ("email")
)
WITH (oids = false);


DROP TABLE IF EXISTS "phone_away_prompts";
DROP SEQUENCE IF EXISTS phone_away_prompts_id_seq;
CREATE SEQUENCE phone_away_prompts_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."phone_away_prompts" (
    "id" bigint DEFAULT nextval('phone_away_prompts_id_seq') NOT NULL,
    "telegram_chat_id" character varying(255) NOT NULL,
    "telegram_message_id" bigint,
    "prompt_sent_at" timestamp(0) NOT NULL,
    "grace_period_minutes" integer NOT NULL,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    "closed_at" timestamp(0),
    CONSTRAINT "phone_away_prompts_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE INDEX phone_away_prompts_telegram_chat_id_index ON public.phone_away_prompts USING btree (telegram_chat_id);

INSERT INTO "phone_away_prompts" ("id", "telegram_chat_id", "telegram_message_id", "prompt_sent_at", "grace_period_minutes", "created_at", "updated_at", "closed_at") VALUES
(82,	'-5286210766',	NULL,	'2026-06-18 18:00:02',	240,	'2026-06-18 18:00:02',	'2026-06-18 18:00:02',	NULL),
(83,	'-5286210766',	NULL,	'2026-06-19 18:00:01',	240,	'2026-06-19 18:00:01',	'2026-06-19 18:00:01',	NULL),
(84,	'-5286210766',	NULL,	'2026-06-20 18:00:01',	240,	'2026-06-20 18:00:01',	'2026-06-20 18:00:01',	NULL),
(85,	'-5286210766',	NULL,	'2026-06-21 18:00:01',	240,	'2026-06-21 18:00:01',	'2026-06-21 18:00:01',	NULL),
(11,	'-5286210766',	NULL,	'2026-04-07 20:00:01',	240,	'2026-04-08 21:59:01',	'2026-04-08 22:03:56',	'2026-04-08 22:03:56'),
(12,	'-5286210766',	NULL,	'2026-04-09 18:00:01',	240,	'2026-04-09 18:00:01',	'2026-04-09 22:24:46',	'2026-04-09 22:24:46'),
(13,	'-5286210766',	NULL,	'2026-04-10 18:00:01',	240,	'2026-04-10 18:00:01',	'2026-04-10 18:00:01',	NULL),
(14,	'-5286210766',	NULL,	'2026-04-11 18:00:02',	240,	'2026-04-11 18:00:02',	'2026-04-11 18:00:02',	NULL),
(15,	'-5286210766',	NULL,	'2026-04-12 18:00:02',	240,	'2026-04-12 18:00:02',	'2026-04-12 18:00:02',	NULL),
(16,	'-5286210766',	NULL,	'2026-04-13 18:00:01',	240,	'2026-04-13 18:00:01',	'2026-04-13 18:00:01',	NULL),
(17,	'-5286210766',	NULL,	'2026-04-14 18:00:01',	240,	'2026-04-14 18:00:01',	'2026-04-14 18:00:01',	NULL),
(18,	'-5286210766',	NULL,	'2026-04-15 18:00:02',	240,	'2026-04-15 18:00:02',	'2026-04-15 18:00:02',	NULL),
(19,	'-5286210766',	NULL,	'2026-04-16 18:00:02',	240,	'2026-04-16 18:00:02',	'2026-04-16 18:00:02',	NULL),
(20,	'-5286210766',	NULL,	'2026-04-17 18:00:01',	240,	'2026-04-17 18:00:01',	'2026-04-17 18:00:01',	NULL),
(21,	'-5286210766',	NULL,	'2026-04-18 18:00:02',	240,	'2026-04-18 18:00:02',	'2026-04-18 18:00:02',	NULL),
(22,	'-5286210766',	NULL,	'2026-04-19 18:00:02',	240,	'2026-04-19 18:00:02',	'2026-04-19 18:00:02',	NULL),
(23,	'-5286210766',	NULL,	'2026-04-20 18:00:01',	240,	'2026-04-20 18:00:01',	'2026-04-20 18:00:01',	NULL),
(24,	'-5286210766',	NULL,	'2026-04-21 18:00:02',	240,	'2026-04-21 18:00:02',	'2026-04-21 18:00:02',	NULL),
(25,	'-5286210766',	NULL,	'2026-04-22 18:00:02',	240,	'2026-04-22 18:00:02',	'2026-04-22 18:00:02',	NULL),
(26,	'-5286210766',	NULL,	'2026-04-23 18:00:02',	240,	'2026-04-23 18:00:02',	'2026-04-23 18:00:02',	NULL),
(27,	'-5286210766',	NULL,	'2026-04-24 18:00:01',	240,	'2026-04-24 18:00:01',	'2026-04-24 18:00:01',	NULL),
(28,	'-5286210766',	NULL,	'2026-04-25 18:00:01',	240,	'2026-04-25 18:00:01',	'2026-04-25 18:00:01',	NULL),
(29,	'-5286210766',	NULL,	'2026-04-26 18:00:01',	240,	'2026-04-26 18:00:01',	'2026-04-26 18:00:01',	NULL),
(30,	'-5286210766',	NULL,	'2026-04-27 18:00:02',	240,	'2026-04-27 18:00:02',	'2026-04-27 18:00:02',	NULL),
(31,	'-5286210766',	NULL,	'2026-04-28 18:00:02',	240,	'2026-04-28 18:00:02',	'2026-04-28 18:00:02',	NULL),
(32,	'-5286210766',	NULL,	'2026-04-29 18:00:01',	240,	'2026-04-29 18:00:01',	'2026-04-29 18:00:01',	NULL),
(33,	'-5286210766',	NULL,	'2026-04-30 18:00:02',	240,	'2026-04-30 18:00:02',	'2026-04-30 18:00:02',	NULL),
(34,	'-5286210766',	NULL,	'2026-05-01 18:00:02',	240,	'2026-05-01 18:00:02',	'2026-05-01 18:00:02',	NULL),
(35,	'-5286210766',	NULL,	'2026-05-02 18:00:01',	240,	'2026-05-02 18:00:01',	'2026-05-02 18:00:01',	NULL),
(36,	'-5286210766',	NULL,	'2026-05-03 18:00:01',	240,	'2026-05-03 18:00:01',	'2026-05-03 18:00:01',	NULL),
(37,	'-5286210766',	NULL,	'2026-05-04 18:00:02',	240,	'2026-05-04 18:00:02',	'2026-05-04 18:00:02',	NULL),
(38,	'-5286210766',	NULL,	'2026-05-05 18:00:01',	240,	'2026-05-05 18:00:01',	'2026-05-05 18:00:01',	NULL),
(39,	'-5286210766',	NULL,	'2026-05-06 18:00:02',	240,	'2026-05-06 18:00:02',	'2026-05-06 18:00:02',	NULL),
(40,	'-5286210766',	NULL,	'2026-05-07 18:00:01',	240,	'2026-05-07 18:00:01',	'2026-05-07 18:00:01',	NULL),
(41,	'-5286210766',	NULL,	'2026-05-08 18:00:02',	240,	'2026-05-08 18:00:02',	'2026-05-08 18:00:02',	NULL),
(42,	'-5286210766',	NULL,	'2026-05-09 18:00:01',	240,	'2026-05-09 18:00:01',	'2026-05-09 18:00:01',	NULL),
(43,	'-5286210766',	NULL,	'2026-05-10 18:00:02',	240,	'2026-05-10 18:00:02',	'2026-05-10 18:00:02',	NULL),
(44,	'-5286210766',	NULL,	'2026-05-11 18:00:01',	240,	'2026-05-11 18:00:01',	'2026-05-11 18:00:01',	NULL),
(45,	'-5286210766',	NULL,	'2026-05-12 18:00:01',	240,	'2026-05-12 18:00:01',	'2026-05-12 18:00:01',	NULL),
(46,	'-5286210766',	NULL,	'2026-05-13 18:00:02',	240,	'2026-05-13 18:00:02',	'2026-05-13 18:00:02',	NULL),
(47,	'-5286210766',	NULL,	'2026-05-14 18:00:02',	240,	'2026-05-14 18:00:02',	'2026-05-14 18:00:02',	NULL),
(48,	'-5286210766',	NULL,	'2026-05-15 18:00:01',	240,	'2026-05-15 18:00:01',	'2026-05-15 18:00:01',	NULL),
(49,	'-5286210766',	NULL,	'2026-05-16 18:00:01',	240,	'2026-05-16 18:00:01',	'2026-05-16 18:00:01',	NULL),
(50,	'-5286210766',	NULL,	'2026-05-17 18:00:01',	240,	'2026-05-17 18:00:01',	'2026-05-17 18:00:01',	NULL),
(51,	'-5286210766',	NULL,	'2026-05-18 18:00:01',	240,	'2026-05-18 18:00:01',	'2026-05-18 18:00:01',	NULL),
(52,	'-5286210766',	NULL,	'2026-05-19 18:00:02',	240,	'2026-05-19 18:00:02',	'2026-05-19 18:00:02',	NULL),
(53,	'-5286210766',	NULL,	'2026-05-20 18:00:01',	240,	'2026-05-20 18:00:01',	'2026-05-20 18:00:01',	NULL),
(54,	'-5286210766',	NULL,	'2026-05-21 18:00:02',	240,	'2026-05-21 18:00:02',	'2026-05-21 18:00:02',	NULL),
(55,	'-5286210766',	NULL,	'2026-05-22 18:00:01',	240,	'2026-05-22 18:00:01',	'2026-05-22 18:00:01',	NULL),
(56,	'-5286210766',	NULL,	'2026-05-23 18:00:02',	240,	'2026-05-23 18:00:02',	'2026-05-23 18:00:02',	NULL),
(57,	'-5286210766',	NULL,	'2026-05-24 18:00:02',	240,	'2026-05-24 18:00:02',	'2026-05-24 18:00:02',	NULL),
(58,	'-5286210766',	NULL,	'2026-05-25 18:00:02',	240,	'2026-05-25 18:00:02',	'2026-05-25 18:00:02',	NULL),
(59,	'-5286210766',	NULL,	'2026-05-26 18:00:02',	240,	'2026-05-26 18:00:02',	'2026-05-26 18:00:02',	NULL),
(60,	'-5286210766',	NULL,	'2026-05-27 18:00:01',	240,	'2026-05-27 18:00:01',	'2026-05-27 18:00:01',	NULL),
(61,	'-5286210766',	NULL,	'2026-05-28 18:00:01',	240,	'2026-05-28 18:00:01',	'2026-05-28 18:00:01',	NULL),
(62,	'-5286210766',	NULL,	'2026-05-29 18:00:01',	240,	'2026-05-29 18:00:01',	'2026-05-29 18:00:01',	NULL),
(63,	'-5286210766',	NULL,	'2026-05-30 18:00:01',	240,	'2026-05-30 18:00:01',	'2026-05-30 18:00:01',	NULL),
(64,	'-5286210766',	NULL,	'2026-05-31 18:00:01',	240,	'2026-05-31 18:00:01',	'2026-05-31 18:00:01',	NULL),
(65,	'-5286210766',	NULL,	'2026-06-01 18:00:01',	240,	'2026-06-01 18:00:01',	'2026-06-01 18:00:01',	NULL),
(66,	'-5286210766',	NULL,	'2026-06-02 18:00:01',	240,	'2026-06-02 18:00:01',	'2026-06-02 18:00:01',	NULL),
(67,	'-5286210766',	NULL,	'2026-06-03 18:00:01',	240,	'2026-06-03 18:00:01',	'2026-06-03 18:00:01',	NULL),
(68,	'-5286210766',	NULL,	'2026-06-04 18:00:01',	240,	'2026-06-04 18:00:01',	'2026-06-04 18:00:01',	NULL),
(69,	'-5286210766',	NULL,	'2026-06-05 18:00:02',	240,	'2026-06-05 18:00:02',	'2026-06-05 18:00:02',	NULL),
(70,	'-5286210766',	NULL,	'2026-06-06 18:00:01',	240,	'2026-06-06 18:00:01',	'2026-06-06 18:00:01',	NULL),
(71,	'-5286210766',	NULL,	'2026-06-07 18:00:01',	240,	'2026-06-07 18:00:01',	'2026-06-07 18:00:01',	NULL),
(72,	'-5286210766',	NULL,	'2026-06-08 18:00:01',	240,	'2026-06-08 18:00:01',	'2026-06-08 18:00:01',	NULL),
(73,	'-5286210766',	NULL,	'2026-06-09 18:00:01',	240,	'2026-06-09 18:00:01',	'2026-06-09 18:00:01',	NULL),
(74,	'-5286210766',	NULL,	'2026-06-10 18:00:01',	240,	'2026-06-10 18:00:01',	'2026-06-10 18:00:01',	NULL),
(75,	'-5286210766',	NULL,	'2026-06-11 18:00:02',	240,	'2026-06-11 18:00:02',	'2026-06-11 18:00:02',	NULL),
(76,	'-5286210766',	NULL,	'2026-06-12 18:00:01',	240,	'2026-06-12 18:00:01',	'2026-06-12 18:00:01',	NULL),
(77,	'-5286210766',	NULL,	'2026-06-13 18:00:01',	240,	'2026-06-13 18:00:01',	'2026-06-13 18:00:01',	NULL),
(78,	'-5286210766',	NULL,	'2026-06-14 18:00:01',	240,	'2026-06-14 18:00:01',	'2026-06-14 18:00:01',	NULL),
(79,	'-5286210766',	NULL,	'2026-06-15 18:00:01',	240,	'2026-06-15 18:00:01',	'2026-06-15 18:00:01',	NULL),
(80,	'-5286210766',	NULL,	'2026-06-16 18:00:01',	240,	'2026-06-16 18:00:01',	'2026-06-16 18:00:01',	NULL),
(81,	'-5286210766',	NULL,	'2026-06-17 18:00:02',	240,	'2026-06-17 18:00:02',	'2026-06-17 18:00:02',	NULL),
(86,	'-5286210766',	NULL,	'2026-06-22 18:00:01',	240,	'2026-06-22 18:00:01',	'2026-06-22 18:00:01',	NULL),
(87,	'-5286210766',	NULL,	'2026-06-23 18:00:01',	240,	'2026-06-23 18:00:01',	'2026-06-23 18:00:01',	NULL),
(88,	'-5286210766',	NULL,	'2026-06-24 18:00:01',	240,	'2026-06-24 18:00:01',	'2026-06-24 18:00:01',	NULL),
(89,	'-5286210766',	NULL,	'2026-06-25 18:00:01',	240,	'2026-06-25 18:00:01',	'2026-06-25 18:00:01',	NULL),
(90,	'-5286210766',	NULL,	'2026-06-26 18:00:01',	240,	'2026-06-26 18:00:01',	'2026-06-26 18:00:01',	NULL),
(91,	'-5286210766',	NULL,	'2026-06-27 18:00:02',	240,	'2026-06-27 18:00:02',	'2026-06-27 18:00:02',	NULL),
(92,	'-5286210766',	NULL,	'2026-06-28 18:00:01',	240,	'2026-06-28 18:00:01',	'2026-06-28 18:00:01',	NULL),
(93,	'-5286210766',	NULL,	'2026-06-29 18:00:02',	240,	'2026-06-29 18:00:02',	'2026-06-29 18:00:02',	NULL),
(94,	'-5286210766',	NULL,	'2026-06-30 18:00:02',	240,	'2026-06-30 18:00:02',	'2026-06-30 18:00:02',	NULL),
(95,	'-5286210766',	NULL,	'2026-07-01 18:00:02',	240,	'2026-07-01 18:00:02',	'2026-07-01 18:00:02',	NULL),
(96,	'-5286210766',	NULL,	'2026-07-02 18:00:01',	240,	'2026-07-02 18:00:01',	'2026-07-02 18:00:01',	NULL),
(97,	'-5286210766',	NULL,	'2026-07-03 18:00:01',	240,	'2026-07-03 18:00:01',	'2026-07-03 18:00:01',	NULL),
(98,	'-5286210766',	NULL,	'2026-07-04 18:00:01',	240,	'2026-07-04 18:00:01',	'2026-07-04 18:00:01',	NULL),
(99,	'-5286210766',	NULL,	'2026-07-05 18:00:02',	240,	'2026-07-05 18:00:02',	'2026-07-05 18:00:02',	NULL),
(100,	'-5286210766',	NULL,	'2026-07-06 18:00:02',	240,	'2026-07-06 18:00:02',	'2026-07-06 18:00:02',	NULL),
(101,	'-5286210766',	NULL,	'2026-07-07 18:00:02',	240,	'2026-07-07 18:00:02',	'2026-07-07 18:00:02',	NULL),
(102,	'-5286210766',	NULL,	'2026-07-08 18:00:02',	240,	'2026-07-08 18:00:02',	'2026-07-08 18:00:02',	NULL),
(103,	'-5286210766',	NULL,	'2026-07-09 18:00:01',	240,	'2026-07-09 18:00:01',	'2026-07-09 18:00:01',	NULL),
(104,	'-5286210766',	NULL,	'2026-07-10 18:00:01',	240,	'2026-07-10 18:00:01',	'2026-07-10 18:00:01',	NULL),
(105,	'-5286210766',	NULL,	'2026-07-15 18:00:01',	240,	'2026-07-15 18:00:01',	'2026-07-15 18:00:01',	NULL),
(106,	'-5286210766',	NULL,	'2026-07-16 18:00:01',	240,	'2026-07-16 18:00:01',	'2026-07-16 18:00:01',	NULL),
(107,	'-5286210766',	NULL,	'2026-07-17 18:00:01',	240,	'2026-07-17 18:00:01',	'2026-07-17 18:00:01',	NULL),
(108,	'-5286210766',	NULL,	'2026-07-18 18:00:02',	240,	'2026-07-18 18:00:02',	'2026-07-18 18:00:02',	NULL),
(109,	'-5286210766',	NULL,	'2026-07-19 18:00:01',	240,	'2026-07-19 18:00:01',	'2026-07-19 18:00:01',	NULL),
(110,	'-5286210766',	NULL,	'2026-07-20 18:00:02',	240,	'2026-07-20 18:00:02',	'2026-07-20 18:00:02',	NULL),
(111,	'-5286210766',	NULL,	'2026-07-21 18:00:02',	240,	'2026-07-21 18:00:02',	'2026-07-21 18:00:02',	NULL),
(112,	'-5286210766',	NULL,	'2026-07-22 18:00:01',	240,	'2026-07-22 18:00:01',	'2026-07-22 18:00:01',	NULL),
(113,	'-5286210766',	NULL,	'2026-07-23 18:00:02',	240,	'2026-07-23 18:00:02',	'2026-07-23 18:00:02',	NULL),
(114,	'-5286210766',	NULL,	'2026-07-24 18:00:01',	240,	'2026-07-24 18:00:01',	'2026-07-24 18:00:01',	NULL),
(115,	'-5286210766',	NULL,	'2026-07-25 18:00:02',	240,	'2026-07-25 18:00:02',	'2026-07-25 18:00:02',	NULL),
(116,	'-5286210766',	NULL,	'2026-07-26 18:00:02',	240,	'2026-07-26 18:00:02',	'2026-07-26 18:00:02',	NULL);

DROP TABLE IF EXISTS "phone_away_records";
DROP SEQUENCE IF EXISTS phone_away_records_id_seq;
CREATE SEQUENCE phone_away_records_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."phone_away_records" (
    "id" bigint DEFAULT nextval('phone_away_records_id_seq') NOT NULL,
    "telegram_user_id" bigint NOT NULL,
    "telegram_chat_id" character varying(255) NOT NULL,
    "prompt_sent_at" timestamp(0) NOT NULL,
    "answered_at" timestamp(0) NOT NULL,
    "grace_period_minutes" integer NOT NULL,
    "delayed" boolean DEFAULT false NOT NULL,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "phone_away_records_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE INDEX phone_away_records_telegram_user_id_answered_at_index ON public.phone_away_records USING btree (telegram_user_id, answered_at);

INSERT INTO "phone_away_records" ("id", "telegram_user_id", "telegram_chat_id", "prompt_sent_at", "answered_at", "grace_period_minutes", "delayed", "created_at", "updated_at") VALUES
(6,	6212914707,	'-5286210766',	'2026-03-30 20:00:01',	'2026-03-30 20:05:01',	240,	'f',	'2026-04-06 18:17:59',	'2026-04-06 18:17:59'),
(7,	6212914707,	'-5286210766',	'2026-03-31 20:00:01',	'2026-03-31 20:05:01',	240,	'f',	'2026-04-06 18:17:59',	'2026-04-06 18:17:59'),
(8,	6212914707,	'-5286210766',	'2026-04-01 20:00:01',	'2026-04-02 00:35:01',	240,	't',	'2026-04-06 18:17:59',	'2026-04-06 18:17:59'),
(9,	6212914707,	'-5286210766',	'2026-04-02 20:00:01',	'2026-04-02 20:05:01',	240,	'f',	'2026-04-06 18:17:59',	'2026-04-06 18:17:59'),
(10,	6212914707,	'-5286210766',	'2026-04-03 20:00:01',	'2026-04-03 20:05:01',	240,	'f',	'2026-04-06 18:17:59',	'2026-04-06 18:17:59'),
(11,	6212914707,	'-5286210766',	'2026-04-04 20:00:01',	'2026-04-05 00:35:01',	240,	't',	'2026-04-06 18:17:59',	'2026-04-06 18:17:59'),
(12,	6212914707,	'-5286210766',	'2026-04-05 20:00:01',	'2026-04-06 00:35:01',	240,	't',	'2026-04-06 18:17:59',	'2026-04-06 18:17:59'),
(13,	6212914707,	'-5286210766',	'2026-04-06 20:00:01',	'2026-04-06 20:05:01',	240,	'f',	'2026-04-06 18:17:59',	'2026-04-06 18:17:59'),
(14,	6212914707,	'-5286210766',	'2026-04-07 18:00:02',	'2026-04-07 21:58:26',	240,	'f',	'2026-04-07 21:58:26',	'2026-04-07 21:58:26'),
(16,	6212914707,	'-5286210766',	'2026-04-07 20:00:01',	'2026-04-08 22:03:56',	240,	't',	'2026-04-08 22:03:56',	'2026-04-08 22:03:56'),
(17,	6212914707,	'-5286210766',	'2026-04-09 18:00:01',	'2026-04-09 22:24:46',	240,	't',	'2026-04-09 22:24:46',	'2026-04-09 22:24:46');

DROP TABLE IF EXISTS "sessions";
CREATE TABLE "public"."sessions" (
    "id" character varying(255) NOT NULL,
    "user_id" bigint,
    "ip_address" character varying(45),
    "user_agent" text,
    "payload" text NOT NULL,
    "last_activity" integer NOT NULL,
    CONSTRAINT "sessions_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE INDEX sessions_user_id_index ON public.sessions USING btree (user_id);

CREATE INDEX sessions_last_activity_index ON public.sessions USING btree (last_activity);

INSERT INTO "sessions" ("id", "user_id", "ip_address", "user_agent", "payload", "last_activity") VALUES
('WrzgrzRtwDoaAVm7mhc0kH3uejtSgRtasm1D8v2Z',	NULL,	'104.30.167.164',	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36 (compatible; +https://developers.cloudflare.com/security-center/)',	'YToyOntzOjY6Il90b2tlbiI7czo0MDoiTXdNMEhXdDFXSGJ5dnNyVk85bXliTmhyMEljekV2NnFtQ25pTGVzUSI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',	1784972032),
('bxejnVUCFnvRIKLzmh7K1VxRY6U73N6R2M987woz',	NULL,	'193.19.82.13',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36',	'YToyOntzOjY6Il90b2tlbiI7czo0MDoiZjlZenBrMmNmQjU1R0p6eXRCT3kwVXdQMlZlQW04WktqRW83cVJHRCI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',	1784974853),
('zvMkiodg689jvOB3BzG42ziXksbfwV4BxZfhZwei',	NULL,	'43.130.74.193',	'Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoidWRTdWQ5M3d6azZBTXNsM1Q3bzZrcGJIVjZVQjlsUDRCcTVRWFBWUCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1784994493),
('Vqy3jWgnr2tF6fKz491KwL06oj550U5W2HOLcALq',	NULL,	'34.90.191.83',	'Scrapy/2.17.0 (+https://scrapy.org)',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVUgwVXJrZm9VdGtqUUNFbDM5Ymd6TElsdTRWVThiQ05GU0dYTmdhMyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1785014013),
('ac1EHcV3CuYSVinkJcDndbAcbAfY4BDtICfknBgv',	NULL,	'69.139.64.230',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVmYyYnMxUWhxUkVIUW1sVVhFazZUOTlYNlREdDhDMHV6YVA3MW9PSiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1785024805),
('YU0hnI0LQl1fjN7ARgX5BDtrmJkrLOnZDo9y2Mfq',	NULL,	'43.135.130.202',	'Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiYmlsbno4ZHBtZzNRc21BM3dJUjRQMEhOQ1dSUWRSMGY0T3ZQbmwwNCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1785025543),
('4eCXZqUa2YxCyhg7LQ949aAaDCum6HNjviT3NVWj',	NULL,	'54.216.189.149',	'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTXl5bjEzS2xjcm1Id21FQmRycXVaekhxN2ppZzZaQmZxWkpLUnprNCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1785041088),
('lXRgu9ueCaSKHgF5zmi1l8qFP4EA6fWMG4sMLUHK',	NULL,	'108.131.170.188',	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUHJnRmVPc1R3Rzh5Nm5XMjhCTnZUZ2VRdnNCZFNxblppUWtpR0RsciI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1785048630),
('FXpdLoSzj7pXelJ5y5nD84bSY42tA9nXF2qAdktT',	NULL,	'192.71.2.57',	'Mozilla/5.0 (Linux; Android 14; SM-S901B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.6099.280 Mobile Safari/537.36 OPR/80.4.4244.7786',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoibkN6c2lWVHFXMFRRUXcxREhUZFhFYlM2aEFjaXI5bE9sN0pSWmJRMiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1785064525),
('FaLJUs7yw4r2qywyOceI5cIICeOQ338BXkL69I4N',	NULL,	'43.167.232.38',	'Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoidWNnYTk2MWszc2JMVWhSd3NDeXJDbVNwWmw2cVZaVlk4UEFxYmxJTiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1785083222),
('StIuLpDIvyWV7QqUZbI9K5f3N7ovnBTAHMJudLIz',	NULL,	'170.106.11.6',	'Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMndBV3VUMG5WSHFUUHhYMkJXdzZVMHZDN2FDamNNUHI0U1phVnFXbSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1785105435),
('gFw9wzDuVBB9Vx4t1dVkIN2Gch62sMfXa71zxJMM',	NULL,	'89.163.146.197',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36 Edg/119.0.2151.97',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiYmRCb242SUl4b0VYdW44dzNxaFFuY1duNE0yQm4yOHF1bUx4b0JCRSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1785122037),
('0RiQ0OQ5I7jrYrCJ8XcM7WpWb1Tb4p3mbOaJ87IE',	NULL,	'100.26.150.106',	'Mozilla/5.0 (iPhone; CPU iPhone OS 18_7_8 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0 Mobile/15E148 Safari/604.1',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMEg4NG9kdzFodDh2SlBXSVNrTUJ5Z2hyTDJoMHlQaVNJdW0xOXRoRCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1785137621),
('ru9uITgQO1efDD58R9Ii7ya4Pkz15W6kQ0GV11TJ',	NULL,	'85.137.57.233',	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiQ1EyN2FPOFJWVGtnQVZGS0xoamE4aGJZVU1FQmdTcGk5TUNRbklYMyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1784969040),
('YeYb7DueV88cvXKEI09iJQFUVpxnAhePmqyvxGc2',	NULL,	'147.90.235.22',	'Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiYlVYWEcweXFSQTdQZ1g3blFnUFhEbGhGZDdwSEl0UHhsREtHUWJGRiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1784973273),
('Nv4mMIYTrclFW7WpUuEZLaTkBChmq9WzZWaiwWle',	NULL,	'193.19.82.13',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiczR2eHlmWjRsY3hUQlNxRWwxekcyaHpjUk5tNzlaQUs0cnBSMk1TZSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1784974874),
('EHQCy4CBu7HqmMlJgH1kw8vRQMKTGQffXekaYg7F',	NULL,	'133.242.174.119',	'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoienZlOFdVRnlPZnJxUDlCZVBYenFZV2g3ckN3RWY3SjRGbm82clRLTiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1784994600),
('j2UO028ND92RDzlgJFTaU3042r3Kiiz4bcQl41HN',	NULL,	'133.242.174.119',	'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZGVOeUlURzQ1WmhiVEJpNUJPTGcxUGp3QnJQb0ZrTDNaQmFGWFBTNSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1785015742),
('DfO3YhT5jtgkmDxf1IWo53FyZeKIq2lkyXx4OyZI',	NULL,	'162.199.230.185',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiakFCVTkzN0Nqc2dXcHFCSFRXdDJ3UzVTOXgyVDBPbU5BcXlGWm01YyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1785024805),
('ticH54NLOElkVA3TBIPAy2KbU35kR8dQbbGtKqPc',	NULL,	'51.68.107.137',	'Mozilla/5.0 (compatible; MJ12bot/v2.0.5; http://mj12bot.com/)',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMDhRbGNZWTRNcENTM3c2bHU0bGFQRDFISmhGdk1UVVcwRUFXb1hiMCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1785029894),
('dPyD3JEhdgt7XTs07hGeISgyMF5M7kdAiYo7412o',	NULL,	'82.39.212.240',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36',	'YToyOntzOjY6Il90b2tlbiI7czo0MDoiSmEwbjV0QXpxbE9WQW5QcndoM09ZMkJTRnAzY2lmVGNKVERWd3BiSyI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',	1785044925),
('Z90ZKs4D0yRboXrD65voKOyaxJ6Yp6x4JwtMavKf',	NULL,	'43.165.195.234',	'Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVjdIRWU0T20zOEpUUHBsTDluMFZrRlRPSVhCbVV4S04xYXU2ZkF0dyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1785055477),
('AIbPuIGfAg9tOBPMVo5b1rXhBJHZLe03OuYWZW9Q',	NULL,	'49.232.104.223',	'Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoieDZwTlRKYVNDQk14dEU1MVk5T3d2Mk1hajBURm5INVkwMTExRXlMSCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1785064857),
('LNbDJBygxOjpy6gDYTdzPb2hduMTSOnNVZtAu0WI',	NULL,	'136.66.133.246',	'Mozilla/5.0 (Linux; Android 14; SM-A146P) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/25.0 Chrome/123.0.6312.120 Mobile Safari/537.36',	'YToyOntzOjY6Il90b2tlbiI7czo0MDoiaHBsVXlhYXBKcFFETFFoMHROcFhoRU5PYjVyNTFJNmJ0NkVRS1drbSI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',	1785089656),
('taPY9SZI2HjbpFnaQFPLkE7g9ktvO8k8HgBJd97t',	NULL,	'136.113.9.105',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoidUhxdFEzb2VvV0xhcndrZXRwVVo5ZVAya1k3VU41VEZjWW5INzI5UiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1785107958),
('Deqr1MqgJEcHRQ9mU5Kjt6vIyY5kgOeWWSQfLWLm',	NULL,	'180.178.51.74',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoieENnZ09IYjNtaDI2RFZZMVNYUFlrWjNqWnBiVWx6OVJmY3M0SXZ4SiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1785135223),
('N2BrU20dreaxY99SfqkYU5lNbkGPs4Jxpo4g5OfJ',	NULL,	'94.154.43.188',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRHIwOEVCZURvZTRGdnhobjNQNktZN002UUdSVzRrVkJ5WjNqaGd6bCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1785138951),
('6sr8G09FesinBMPkaimNL0lwJ5mcxiUMpNamydGO',	NULL,	'85.137.57.233',	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoidk1peUlQRWVRWkFoZGU2SW1DaVdDa0tFUFZlTXVEWHZzMzhJamJLNCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1784969043),
('Kijaj7hZrhr7ixQ2peIjwqCFRiBkeChjN0ZMTDeo',	NULL,	'172.233.62.72',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiekNINk5KWElCOHFPZkdMUGprYmZoWHpVRmZxOHhjZjVKdWN6OEV3MSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1784973498),
('NTMWMtIjUDYqPdqODNsco32D59wvZBDB20O40SNd',	NULL,	'107.189.4.12',	'Mozilla/5.0 (Linux; Android 12; Pixel 6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Mobile Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoidm9OanNsNFJNdWRvMjJQcEY0eFlvTngwTWtpU3d5aU5ncTVFbzlSWiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1784976108),
('wUWBvEIibpGGLIfY8DnArv8CvBQNqaPqtBDHfiXz',	NULL,	'52.230.100.152',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiNThJbldONGRGemVtb0RUd1lqOW93RDlCNlZ4clh1QUhYNDExMXJqNiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1784996918),
('VWhJDUvLdtkR6X7YleWJvveVmBTcjspNPBAzdBTi',	NULL,	'66.132.172.111',	'Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTlV3UDRKZk1EUVpBc1lsS3lvaVdWQkFDZkl0bTRnb1RHWG9ubWs5byI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1785017570),
('uFimHSlU1CPi0KJL1trlBjg05rYYEguOuW46KYwF',	NULL,	'172.59.76.208',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMVNRWDhqQUY1czJRT3hzd0N4eUd0U2NLa05WMk4wSm51YWhSbHU4WSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1785024805),
('QvlWLL93yPrdEdZhA6QiYIdrDbhKY7oRv793gMMJ',	NULL,	'46.101.156.128',	'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiR2s2WG9xZEcwdkplekx6YzJFQWVCbFdUU3JWNTRwdDNCbnhWeVhEbSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1785031922),
('dw5ZCNA2b0BGg0PKJe1o7je8Jl5L35LmnycWb03M',	NULL,	'82.39.212.240',	'Mozilla/5.0 (Macintosh; Intel Mac OS X 15.7; rv:149.0) Gecko/20100101 Firefox/149.0',	'YToyOntzOjY6Il90b2tlbiI7czo0MDoiZjZYcWpWR0RSNmczS0UyQ0p0TVFQQ0pNTEVaRTVTZEtPUEh0MVZieCI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',	1785044927),
('D9h7JLBy4pvbRMKEGv1XNgNHuixMVai0PcaYlSlI',	NULL,	'45.154.98.52',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoidzdBNnZBYmVqQWxXbWwwZDVMYUtqVWxIbllGa0l6S2xwNmhOalU0dCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1785056595),
('9S0uBVhqRrTVghOO01KKygaWPI3GxS7FZWE70P03',	NULL,	'54.80.198.68',	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.9; rv:35.0) Gecko/20100101 Firefox/35.0',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTENkNHpSQnFnWUZaRWdraEsxOFNOR1RJcDU4S1FzUWdRNU51UGZDSCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1785065952),
('urUOr7g8NRmKiPOKlU3108nRpJ5rQk45979VfvZv',	NULL,	'45.154.98.52',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoibllIS2ZiOGF4QWFGQUNmRlMxMWtzRWx5ZHZ0OUU3aGI3SXdpQmR4eCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1785093665),
('5d8Y9zrqIHp5YC36YzVfbASiphAQTSEVj2hTdAxS',	NULL,	'101.42.46.71',	'Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVmlmR1RNTVZtYmllRFFMbUtndDBnMzUxSzI0R081T0Z3V1N2dUwybCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1785108666),
('14H6oeU6REw4yNifdZQdqGLMZuyuI0UkRtTDwchP',	NULL,	'88.255.41.28',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoibXVKTnFkZUhXTnVDMjQ2Z2dnaHRTaVVRZERIc0tSOGplZjJhMTZ1diI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1785135643),
('fDAIJqeP40u4CguipVAxyKrvsva7HGfl59qVFj6F',	NULL,	'45.38.239.130',	'Mozilla/5.0 (X11; Linux i686; rv:109.0) Gecko/20100101 Firefox/120.0',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoieXVZUW5SaGg0ZWNaNk42RUtHSVZHbEZiQjhGTTd0emxwakZ3aWZlOCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1784970993),
('xcC7w50dbF4TecICPKXYWH3tn2m5nkNN97Ye3Uix',	NULL,	'51.68.107.150',	'Mozilla/5.0 (compatible; MJ12bot/v2.0.5; http://mj12bot.com/)',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiU0xTeEowZzAzNDlnNm1WMEhaY0RFOVlxdEFaQXVqa0lhSE5PWUV1bCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1784973796),
('zqJnJPyiU1sH3xwG59i7qknw6uFttF4UE7yQrazU',	NULL,	'66.84.92.85',	'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiYnM5N3BnaEQxU2FickRMd2U3dGZCaHBweEROVFpWVVdmNlhYMFNrSCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1784978740),
('fwdI8ythXVGb1X8JlXZOwC45Thdgpi2JLZRVvoJZ',	NULL,	'66.154.100.10',	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTlJ5MlhHako2UllQRXhvZ0NWRWJ4OW05cVo5UlNGNmd1QTUwTG1mUyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1785006765),
('sN9K93kPJkL9Ts2898tCki8hZhODzTzRMwGLuXJy',	NULL,	'82.156.34.74',	'Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRkIxenhoQkFZNFMzWnBvTWRWdnA2MkxBblI3dzBZc09OWG1DVFI0RiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1785019746),
('oPyexqRixHpRizRkhGE7oakSNraVuQb9iLgi1nCZ',	NULL,	'73.116.12.84',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoid1BrdW85dnJleUVIOVV5UmpKR1c0dmFnQkU1MFNFazhOY2ZTZHNHdyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1785024805),
('yhO4mvdE0ioSGvqefY2oqpHHwkliTb6uiLlZZdlA',	NULL,	'195.178.110.223',	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiWHZmVENscXQ5V3BLVjJlektPNnFmUkxONjNJaEk0alNCM0hId2VmWiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1785033387),
('KUfv4FbyIbKg3n6nJaW7Y4F4DNikPCz1MMDnCJmq',	NULL,	'82.39.212.240',	'Mozilla/5.0 (Macintosh; Intel Mac OS X 15.7; rv:149.0) Gecko/20100101 Firefox/149.0',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoid2gzRlJBZ1NGZnRBTVduQWtSTW9BM0lacmx2TTVzdllSd0d3UEMzZyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1785044932),
('PikkAxOvUyoQajZCKtJD1Ck5d083lEsLfY44UmHf',	NULL,	'192.30.80.142',	'Mozilla/5.0 (X11; Linux i686; rv:109.0) Gecko/20100101 Firefox/120.0',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTzVQN3hrRG01S2d1dVBlOW05d0tJdWQ2R0dhWUNrTzBSRVlPMmJhSCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1785057436),
('gEDVtGVpIX33GLpaQcPSkX0yUFBJI8JgwmgPLDsA',	NULL,	'141.98.11.42',	'wp2shell',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiS2JMTjJoUlNJSGdLdzhOUEpiOXM3RXU2a0plWkhSdnR1QUlUSjdYeCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NDk6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tLz9yZXN0X3JvdXRlPSUyRmJhdGNoJTJGdjEiO3M6NToicm91dGUiO047fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',	1785068462),
('W2OCFGUuBEu1NKQgmNEzXkHuyLBhPp0wRcjyo88O',	NULL,	'45.148.10.120',	'Mozilla/5.0 (Linux; U; Android 6.0; zh-CN; KNT-UL10 Build/HUAWEIKNT-UL10) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/57.0.2987.108 Quark/3.0.2.943 Mobile Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiYWN0ckNYejRHNHk4OHBBVjJkNGZlcW9BNVFYTXdBMmZNdmR4dVVSbCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1785097168),
('L9jeZe7zc45bCGsXOz4lfquWrFoAKx8szf6jL5ux',	NULL,	'213.159.214.145',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoicHlTNnFkamQ0MmRGNXdXb1UwclUyMXZHZkRpd2hsTTZ5aFBMZjU5RiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1785113677),
('6mnAaOqY3lNIloSw7kXuwZ3Ba2ysHk5UmzxwvVXN',	NULL,	'91.92.42.30',	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.1 Safari/605.1.15',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiOTZaRUpyRDBocHNxU3NYMURKeWdDZmlyeXJHNkZkOUg2Y3BPUTlsVCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1785136261),
('z0w00IxlKlYWGWcMrzKu1Ud9pm6WzoEhyDwo5WkF',	NULL,	'51.68.107.149',	'Mozilla/5.0 (compatible; MJ12bot/v2.0.5; http://mj12bot.com/)',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoieE1PME5ZWmlMTG1MdDJVUEFYbnZLMHk4UDJ1YnBvU0RoVkNYT2RQSiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1784971655),
('vzJvzmDB2cIWz3TTngkXH3EMI8gJYj8fMbkbgjf6',	NULL,	'43.131.39.179',	'Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZjdrRFcxUWtMNFRoajhETTNEeG04S1VzOG5EWkE3ejJpd29KajRLeSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1784973834),
('2I0OZYdk8WOcgNbJHhDAx9NFnBuO7Z9xTC8yXRUb',	NULL,	'3.217.141.132',	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRnBYcHc1ZE9odFlkRUdxV29wc2FrNEVtM0o3Z2JjMWs5SzFXWG1EeSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1784979889),
('wWW0OoY3q7CnYqHS6nnLsLa84fJLhMlJTsqgwRp9',	NULL,	'43.167.236.228',	'Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMnJHSDREbW42dUlUQXZZR2NndWxhcU1uMUl4bXRJVUM3WkhvV0xFeCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1785010925),
('B66i5ATrv4Spdn8x1JOdY1oLqsrIHhs5zcyBBAVI',	NULL,	'66.132.195.115',	'Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMEhLdmI1cFhKSzM0R3puQmp2ZXYzN1pzTUFMNFNLeTBub2RFZ3dVeCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1785020459),
('Dc9YIwWSm7LVZEKuGXl76cAffvIKf3kWBIhmDBg5',	NULL,	'172.56.213.72',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiem5IRUpWbFl0Q2E5MFloMFZQMVpMNTJhRjlCclNXaVRwVGdOc3ExNyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1785024807),
('8mwTYnYt9giDUhgkdlHz1cADlZjStJqkwIXd6HyC',	NULL,	'195.178.110.223',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:133.0) Gecko/20100101 Firefox/133.0',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiNEg2cHRPYzdDeWZnUW5yTkVjUzZPNmR3a0RuNFpoT0N1dk1ESW5SSyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1785033387),
('mTzOKJN51LtMIpkCqoJpe4LZj5K0LZK4EZ0r3c62',	NULL,	'185.8.106.168',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0',	'YToyOntzOjY6Il90b2tlbiI7czo0MDoieFBBaVZtSUVua0ZiN21RVEVoZWs5Tk95bXdMVzBDS2tXbmlBNkpqQyI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',	1785047268),
('kKUd1AB250uaL9tYi8TPMXnYUNtvTQSUt4aUniuB',	NULL,	'202.78.167.217',	'Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoidFFzdG9STDI1VzNOMDNUMjY3S3lPejYxWjd0UjMycFltMTVJYUlZRSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1785057870),
('4oEdDSjjxlFJLpwbsqSmNk4DAcFMmUT5wkWLxZt7',	NULL,	'49.51.178.45',	'Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoicEV3Z3Z4SzFaOGZobEVselVmRUhVSElOMHNpQVdtTW9zOEtLb0R0dSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1785068907),
('TCfmNV2SicahoAUusLEeM4gFlxkoVk9eEHl6JvRF',	NULL,	'216.226.77.10',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUkFMR2E2dG45cnY1SXZoQUVuNENvWXAwRmNVS3dKNVIySTc1T3AyZSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1785101857),
('8BWorTyQnrLQq3GAM7TJkvC3oOe1xCa7O8gmf2fg',	NULL,	'66.249.74.76',	'Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.7871.128 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoialN2Y3NmSk0zWVQyWnlhZ2NpUmd6enJxVmJVaGdHWHpsOXFKNXNySiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1785117819),
('exA1UBsavGQ21D763Q1UWbdxSZ6CgkNiMyUwVMKR',	NULL,	'178.62.243.183',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36 +https://forestengine.net/#opt-out',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoieUxGVkdmTTM4c1dnUUJRRFhySUZhN2FydGxJaUJ5QnQySk1wY2NFMSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1785136602),
('sQqOHaU3RSc7NNo1SXmxaauSbrEDr5k2d0qENTEQ',	1,	'147.161.97.115',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36',	'YTo1OntzOjY6Il90b2tlbiI7czo0MDoiRjljVGRXTm95cmRFY1dYZWlPMXZYSFlhTG9kTk00VXR6OVFyN1lNNCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mzg6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tL3BlcnNvbmFsL2xvZ2luIjtzOjU6InJvdXRlIjtzOjE0OiJwZXJzb25hbC5sb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6MzoidXJsIjthOjA6e31zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aToxO30=',	1785146625),
('8D3uM3XZPGRhlwWQtr2k0D4d03vmf25bF1HoUqTW',	NULL,	'104.30.167.164',	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36 (compatible; +https://developers.cloudflare.com/security-center/)',	'YToyOntzOjY6Il90b2tlbiI7czo0MDoiV3NpaTRub3ppSWFZcDNSMlFLT1Y5eVBSb0UzOUxKQUNrSmJsVmtyRyI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',	1784972032),
('qI8nVXncTgheeRMY4sgYOE8NiHBsKNNzO1Uy09cq',	NULL,	'1.12.70.96',	'Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVVdBQ2o3dzB5TTNnaUVTRGFPS25WRXAzcUhBQ285UW8yeDJhamNReSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1784974176),
('wCIcm13wViBnvzKJ0LrVw6BG3MAWPAkRTA54MJoB',	NULL,	'34.31.88.250',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUDN0Q2JVbDR2RjJETXVKUDNsYzYwNnpGQ1M3V1hBc2tPd1ZNRk9xRSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1784985121),
('I5zuncvuoF9OVaOsD4pUQi3STlyN6P8pCR3SVl9S',	NULL,	'192.227.183.149',	'Mozilla/5.0 (iPad; CPU OS 13_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0 EdgiOS/45.3.19 Mobile/15E148 Safari/605.1.15',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiOVFnZ1l3QkQwM2NXcnY1azBCd3VpYWxyeDVGSkc0WUk4RWZJT0pJZSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1785013282),
('XaVgrADwFvk6dj0eWvucnOXkedhp9du2DdEXkR0j',	NULL,	'34.34.253.138',	'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/150.0.0.0 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiSURjcFhwSnppSU5XNW1xa3N1VmhFTUZSMkxtbklXNDBRZHpDN2Z0aCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1785024615),
('2VYRadLeCZzoi6aLNOtObPLyPN5rig5IB3szEEEr',	NULL,	'134.209.76.153',	'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiSEFmM29CTHJmRVpIRmhRejZkY0xvMHpnTEp5Q3dRVWs1cHhIdUNrUSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1785024848),
('X6KXQuJjTIr72Av5VcXVb7iWVnIjntEkXSsk8k06',	NULL,	'43.161.233.190',	'Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiOEhUeWJ4YURiRnhYM3J6MkRhQmg2WldMaWhMbVloOVc2N3p6T2JLdiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1785040471),
('0X0Lo1g2w6EyJtxXJYUzjgkUohopmAHhPBGrKpIr',	NULL,	'185.8.106.168',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUjk4Q1B3OEZXYkdMYUlzTUtqWWpWaTk3MVpqUTM1azVaaUprcXRHayI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1785047268),
('kHSLwSqbCfV3j3JGiuza8a9GH3rEICnY20or8FnR',	NULL,	'109.199.118.129',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36 Edg/91.0.864.54',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoieGIwWklHd09yMWdmZlJVZlJvR1JFdnlvNlZtT05WWjFpSnV0TzlEWiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1785062960),
('tcDh0t8hbY7AMIBMqACDFePOHH7a4z6sjbbpAyhA',	NULL,	'54.173.131.118',	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoieHNYVXRpRUhKNjZYT0V0bnpaQVdtUjRjMFJxWmVjV3NtTHljbkY1byI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1785072833),
('zOZom7ekQJ3lvhY7Ie1C5c6gqMLtNytcOwNsRKUm',	NULL,	'152.32.182.165',	'curl/7.29.0',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoidWthMEpCckpSWnc5dmd4dGh6WDl3RzNlTTRhbHlzb1hrN1R4Z0xHZyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1785102970),
('Ae0RNvNSOegL3d3PpZulkbYMmR9DzCqyh0T6sKjO',	NULL,	'49.51.245.241',	'Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZGdZQnVDTGNqMDRHc2E4SUdPVGUxOWRFUWFUSFZDV21TN1BqcWl4UCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1785120894),
('QnxOJ6rtBCBU6JfQpkvGw2GOgOIe1wKQNOqOF4uE',	NULL,	'43.165.126.130',	'Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoidjNBVE5vY0Y3WVpSQ0VIUTI2ZzRIaFl2eXV1Y2N5elg3ZmlQbkZNRSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vam9hbnBhbmVxdWUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1785136904);

DROP TABLE IF EXISTS "teeth_cleanings";
DROP SEQUENCE IF EXISTS teeth_cleanings_id_seq;
CREATE SEQUENCE teeth_cleanings_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."teeth_cleanings" (
    "id" bigint DEFAULT nextval('teeth_cleanings_id_seq') NOT NULL,
    "telegram_user_id" bigint NOT NULL,
    "telegram_chat_id" character varying(255) NOT NULL,
    "prompt_sent_at" timestamp(0) NOT NULL,
    "answered_at" timestamp(0) NOT NULL,
    "grace_period_minutes" integer NOT NULL,
    "delayed" boolean DEFAULT false NOT NULL,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    "telegram_message_id" bigint,
    "phase" character varying(255),
    "completed" boolean DEFAULT true NOT NULL,
    "response_note" text,
    CONSTRAINT "teeth_cleanings_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE INDEX teeth_cleanings_telegram_user_id_answered_at_index ON public.teeth_cleanings USING btree (telegram_user_id, answered_at);

CREATE INDEX teeth_cleanings_telegram_message_id_index ON public.teeth_cleanings USING btree (telegram_message_id);

INSERT INTO "teeth_cleanings" ("id", "telegram_user_id", "telegram_chat_id", "prompt_sent_at", "answered_at", "grace_period_minutes", "delayed", "created_at", "updated_at", "telegram_message_id", "phase", "completed", "response_note") VALUES
(21,	6212914707,	'-5286210766',	'2026-03-30 20:00:00',	'2026-03-30 20:05:00',	240,	'f',	'2026-04-06 18:17:59',	'2026-04-06 18:17:59',	NULL,	NULL,	't',	NULL),
(22,	6212914707,	'-5286210766',	'2026-03-31 07:45:00',	'2026-03-31 07:50:00',	20,	'f',	'2026-04-06 18:17:59',	'2026-04-06 18:17:59',	NULL,	NULL,	't',	NULL),
(23,	6212914707,	'-5286210766',	'2026-03-31 13:00:00',	'2026-03-31 13:05:00',	240,	'f',	'2026-04-06 18:17:59',	'2026-04-06 18:17:59',	NULL,	NULL,	't',	NULL),
(24,	6212914707,	'-5286210766',	'2026-03-31 20:00:00',	'2026-03-31 20:05:00',	240,	'f',	'2026-04-06 18:17:59',	'2026-04-06 18:17:59',	NULL,	NULL,	't',	NULL),
(25,	6212914707,	'-5286210766',	'2026-04-01 07:45:00',	'2026-04-01 07:50:00',	20,	'f',	'2026-04-06 18:17:59',	'2026-04-06 18:17:59',	NULL,	NULL,	't',	NULL),
(26,	6212914707,	'-5286210766',	'2026-04-01 13:00:00',	'2026-04-01 17:35:00',	240,	't',	'2026-04-06 18:17:59',	'2026-04-06 18:17:59',	NULL,	NULL,	't',	NULL),
(27,	6212914707,	'-5286210766',	'2026-04-01 20:00:00',	'2026-04-02 00:35:00',	240,	't',	'2026-04-06 18:17:59',	'2026-04-06 18:17:59',	NULL,	NULL,	't',	NULL),
(28,	6212914707,	'-5286210766',	'2026-04-02 07:45:00',	'2026-04-02 07:50:00',	20,	'f',	'2026-04-06 18:17:59',	'2026-04-06 18:17:59',	NULL,	NULL,	't',	NULL),
(29,	6212914707,	'-5286210766',	'2026-04-02 13:00:00',	'2026-04-02 13:05:00',	240,	'f',	'2026-04-06 18:17:59',	'2026-04-06 18:17:59',	NULL,	NULL,	't',	NULL),
(30,	6212914707,	'-5286210766',	'2026-04-02 20:00:00',	'2026-04-02 20:05:00',	240,	'f',	'2026-04-06 18:17:59',	'2026-04-06 18:17:59',	NULL,	NULL,	't',	NULL),
(31,	6212914707,	'-5286210766',	'2026-04-03 07:45:00',	'2026-04-03 08:40:00',	20,	't',	'2026-04-06 18:17:59',	'2026-04-06 18:17:59',	NULL,	NULL,	't',	NULL),
(32,	6212914707,	'-5286210766',	'2026-04-03 13:00:00',	'2026-04-03 17:35:00',	240,	't',	'2026-04-06 18:17:59',	'2026-04-06 18:17:59',	NULL,	NULL,	't',	NULL),
(33,	6212914707,	'-5286210766',	'2026-04-03 20:00:00',	'2026-04-03 20:05:00',	240,	'f',	'2026-04-06 18:17:59',	'2026-04-06 18:17:59',	NULL,	NULL,	't',	NULL),
(34,	6212914707,	'-5286210766',	'2026-04-04 07:45:00',	'2026-04-04 08:40:00',	20,	't',	'2026-04-06 18:17:59',	'2026-04-06 18:17:59',	NULL,	NULL,	't',	NULL),
(35,	6212914707,	'-5286210766',	'2026-04-04 20:00:00',	'2026-04-05 00:35:00',	240,	't',	'2026-04-06 18:17:59',	'2026-04-06 18:17:59',	NULL,	NULL,	't',	NULL),
(36,	6212914707,	'-5286210766',	'2026-04-05 07:45:00',	'2026-04-05 07:50:00',	20,	'f',	'2026-04-06 18:17:59',	'2026-04-06 18:17:59',	NULL,	NULL,	't',	NULL),
(37,	6212914707,	'-5286210766',	'2026-04-05 13:00:00',	'2026-04-05 17:35:00',	240,	't',	'2026-04-06 18:17:59',	'2026-04-06 18:17:59',	NULL,	NULL,	't',	NULL),
(38,	6212914707,	'-5286210766',	'2026-04-05 20:00:00',	'2026-04-06 00:35:00',	240,	't',	'2026-04-06 18:17:59',	'2026-04-06 18:17:59',	NULL,	NULL,	't',	NULL),
(39,	6212914707,	'-5286210766',	'2026-04-06 07:45:00',	'2026-04-06 07:50:00',	20,	'f',	'2026-04-06 18:17:59',	'2026-04-06 18:17:59',	NULL,	NULL,	't',	NULL),
(40,	6212914707,	'-5286210766',	'2026-04-06 13:00:00',	'2026-04-06 17:35:00',	240,	't',	'2026-04-06 18:17:59',	'2026-04-06 18:17:59',	NULL,	NULL,	't',	NULL),
(41,	6212914707,	'-5286210766',	'2026-04-06 20:00:00',	'2026-04-06 20:05:00',	240,	'f',	'2026-04-06 18:17:59',	'2026-04-06 18:17:59',	NULL,	NULL,	't',	NULL),
(42,	6212914707,	'-5286210766',	'2026-04-07 05:45:01',	'2026-04-07 05:56:10',	20,	'f',	'2026-04-07 05:56:10',	'2026-04-07 05:56:10',	NULL,	NULL,	't',	NULL),
(43,	6212914707,	'-5286210766',	'2026-04-07 11:00:01',	'2026-04-07 13:18:00',	240,	'f',	'2026-04-07 13:18:00',	'2026-04-07 13:18:00',	NULL,	NULL,	't',	NULL),
(44,	6212914707,	'-5286210766',	'2026-04-07 18:00:01',	'2026-04-07 21:58:24',	240,	'f',	'2026-04-07 21:58:24',	'2026-04-07 21:58:24',	NULL,	NULL,	't',	NULL),
(45,	6212914707,	'-5286210766',	'2026-04-07 07:45:00',	'2026-04-07 08:59:17',	20,	'f',	'2026-04-08 21:59:17',	'2026-04-08 21:59:38',	114,	'morning',	't',	'en verdad me los he lavado a tiempo'),
(46,	6212914707,	'-5286210766',	'2026-04-07 13:00:00',	'2026-04-08 22:02:11',	240,	'f',	'2026-04-08 22:02:11',	'2026-04-08 22:02:53',	115,	'midday',	'f',	'porque he ido a comer con el roman, me he encontrado mal a la vuelta me he desubicado y me he olvidado de los dientes'),
(47,	6212914707,	'-5286210766',	'2026-04-07 20:00:00',	'2026-04-08 22:03:12',	240,	't',	'2026-04-08 22:03:12',	'2026-04-08 22:03:51',	116,	'night',	't',	'porque he estado programando el sistema de tener controlado lo de los dientes y me he distraido un poquillo y se me ha alargado'),
(49,	6212914707,	'-5286210766',	'2026-04-09 11:00:01',	'2026-04-09 12:01:38',	240,	'f',	'2026-04-09 12:01:38',	'2026-04-09 12:01:38',	122,	'midday',	't',	NULL),
(48,	6212914707,	'-5286210766',	'2026-04-09 05:45:01',	'2026-04-09 12:01:36',	20,	't',	'2026-04-09 12:01:36',	'2026-04-09 12:02:11',	121,	'morning',	't',	'me he levantado he apagado la alarma y me he vuelto a tumbar unos minutitos, lo he hecho 10 minutos mas tarde'),
(50,	6212914707,	'-5286210766',	'2026-04-09 18:00:01',	'2026-04-09 22:00:31',	240,	't',	'2026-04-09 22:00:31',	'2026-04-09 22:00:58',	124,	'night',	't',	'si lo he hecho a tiempo, solo se me ha olvidado apuntarlo'),
(51,	6212914707,	'-5286210766',	'2026-04-10 05:45:01',	'2026-04-10 05:59:11',	20,	'f',	'2026-04-10 05:59:11',	'2026-04-10 05:59:11',	127,	'morning',	't',	NULL),
(52,	6212914707,	'-5286210766',	'2026-04-13 05:45:01',	'2026-04-13 09:11:00',	20,	't',	'2026-04-13 09:11:00',	'2026-04-13 09:11:16',	138,	'morning',	't',	'perque m''he oblidat');

DROP TABLE IF EXISTS "teeth_prompts";
DROP SEQUENCE IF EXISTS teeth_prompts_id_seq;
CREATE SEQUENCE teeth_prompts_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."teeth_prompts" (
    "id" bigint DEFAULT nextval('teeth_prompts_id_seq') NOT NULL,
    "telegram_chat_id" character varying(255) NOT NULL,
    "telegram_message_id" bigint,
    "prompt_sent_at" timestamp(0) NOT NULL,
    "grace_period_minutes" integer NOT NULL,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    "phase" character varying(20),
    "closed_at" timestamp(0),
    CONSTRAINT "teeth_prompts_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE INDEX teeth_prompts_telegram_chat_id_index ON public.teeth_prompts USING btree (telegram_chat_id);

INSERT INTO "teeth_prompts" ("id", "telegram_chat_id", "telegram_message_id", "prompt_sent_at", "grace_period_minutes", "created_at", "updated_at", "phase", "closed_at") VALUES
(44,	'-5286210766',	NULL,	'2026-04-10 18:00:01',	240,	'2026-04-10 18:00:01',	'2026-04-10 18:00:01',	'night',	NULL),
(45,	'-5286210766',	NULL,	'2026-04-11 05:45:01',	20,	'2026-04-11 05:45:01',	'2026-04-11 05:45:01',	'morning',	NULL),
(46,	'-5286210766',	NULL,	'2026-04-11 11:00:01',	240,	'2026-04-11 11:00:01',	'2026-04-11 11:00:01',	'midday',	NULL),
(47,	'-5286210766',	NULL,	'2026-04-11 18:00:02',	240,	'2026-04-11 18:00:02',	'2026-04-11 18:00:02',	'night',	NULL),
(48,	'-5286210766',	NULL,	'2026-04-12 05:45:01',	20,	'2026-04-12 05:45:01',	'2026-04-12 05:45:01',	'morning',	NULL),
(49,	'-5286210766',	NULL,	'2026-04-12 11:00:02',	240,	'2026-04-12 11:00:02',	'2026-04-12 11:00:02',	'midday',	NULL),
(50,	'-5286210766',	NULL,	'2026-04-12 18:00:02',	240,	'2026-04-12 18:00:02',	'2026-04-12 18:00:02',	'night',	NULL),
(51,	'-5286210766',	NULL,	'2026-04-13 05:45:01',	20,	'2026-04-13 05:45:01',	'2026-04-13 09:11:00',	'morning',	'2026-04-13 09:11:00'),
(52,	'-5286210766',	NULL,	'2026-04-13 11:00:01',	240,	'2026-04-13 11:00:01',	'2026-04-13 11:00:01',	'midday',	NULL),
(53,	'-5286210766',	NULL,	'2026-04-13 18:00:01',	240,	'2026-04-13 18:00:01',	'2026-04-13 18:00:01',	'night',	NULL),
(54,	'-5286210766',	NULL,	'2026-04-14 05:45:01',	20,	'2026-04-14 05:45:01',	'2026-04-14 05:45:01',	'morning',	NULL),
(55,	'-5286210766',	NULL,	'2026-04-14 11:00:01',	240,	'2026-04-14 11:00:01',	'2026-04-14 11:00:01',	'midday',	NULL),
(56,	'-5286210766',	NULL,	'2026-04-14 18:00:01',	240,	'2026-04-14 18:00:01',	'2026-04-14 18:00:01',	'night',	NULL),
(57,	'-5286210766',	NULL,	'2026-04-15 05:45:01',	20,	'2026-04-15 05:45:01',	'2026-04-15 05:45:01',	'morning',	NULL),
(58,	'-5286210766',	NULL,	'2026-04-15 11:00:01',	240,	'2026-04-15 11:00:01',	'2026-04-15 11:00:01',	'midday',	NULL),
(59,	'-5286210766',	NULL,	'2026-04-15 18:00:02',	240,	'2026-04-15 18:00:02',	'2026-04-15 18:00:02',	'night',	NULL),
(60,	'-5286210766',	NULL,	'2026-04-16 05:45:01',	20,	'2026-04-16 05:45:01',	'2026-04-16 05:45:01',	'morning',	NULL),
(61,	'-5286210766',	NULL,	'2026-04-16 11:00:01',	240,	'2026-04-16 11:00:01',	'2026-04-16 11:00:01',	'midday',	NULL),
(62,	'-5286210766',	NULL,	'2026-04-16 18:00:01',	240,	'2026-04-16 18:00:01',	'2026-04-16 18:00:01',	'night',	NULL),
(63,	'-5286210766',	NULL,	'2026-04-17 05:45:01',	20,	'2026-04-17 05:45:01',	'2026-04-17 05:45:01',	'morning',	NULL),
(64,	'-5286210766',	NULL,	'2026-04-17 11:00:02',	240,	'2026-04-17 11:00:02',	'2026-04-17 11:00:02',	'midday',	NULL),
(65,	'-5286210766',	NULL,	'2026-04-17 18:00:01',	240,	'2026-04-17 18:00:01',	'2026-04-17 18:00:01',	'night',	NULL),
(66,	'-5286210766',	NULL,	'2026-04-18 05:45:01',	20,	'2026-04-18 05:45:01',	'2026-04-18 05:45:01',	'morning',	NULL),
(67,	'-5286210766',	NULL,	'2026-04-18 11:00:01',	240,	'2026-04-18 11:00:01',	'2026-04-18 11:00:01',	'midday',	NULL),
(68,	'-5286210766',	NULL,	'2026-04-18 18:00:02',	240,	'2026-04-18 18:00:02',	'2026-04-18 18:00:02',	'night',	NULL),
(69,	'-5286210766',	NULL,	'2026-04-19 05:45:01',	20,	'2026-04-19 05:45:01',	'2026-04-19 05:45:01',	'morning',	NULL),
(70,	'-5286210766',	NULL,	'2026-04-19 11:00:01',	240,	'2026-04-19 11:00:01',	'2026-04-19 11:00:01',	'midday',	NULL),
(71,	'-5286210766',	NULL,	'2026-04-19 18:00:02',	240,	'2026-04-19 18:00:02',	'2026-04-19 18:00:02',	'night',	NULL),
(72,	'-5286210766',	NULL,	'2026-04-20 05:45:01',	20,	'2026-04-20 05:45:01',	'2026-04-20 05:45:01',	'morning',	NULL),
(73,	'-5286210766',	NULL,	'2026-04-20 11:00:01',	240,	'2026-04-20 11:00:01',	'2026-04-20 11:00:01',	'midday',	NULL),
(74,	'-5286210766',	NULL,	'2026-04-20 18:00:01',	240,	'2026-04-20 18:00:01',	'2026-04-20 18:00:01',	'night',	NULL),
(75,	'-5286210766',	NULL,	'2026-04-21 05:45:01',	20,	'2026-04-21 05:45:01',	'2026-04-21 05:45:01',	'morning',	NULL),
(76,	'-5286210766',	NULL,	'2026-04-21 11:00:01',	240,	'2026-04-21 11:00:01',	'2026-04-21 11:00:01',	'midday',	NULL),
(77,	'-5286210766',	NULL,	'2026-04-21 18:00:01',	240,	'2026-04-21 18:00:01',	'2026-04-21 18:00:01',	'night',	NULL),
(78,	'-5286210766',	NULL,	'2026-04-22 05:45:02',	20,	'2026-04-22 05:45:02',	'2026-04-22 05:45:02',	'morning',	NULL),
(79,	'-5286210766',	NULL,	'2026-04-22 11:00:02',	240,	'2026-04-22 11:00:02',	'2026-04-22 11:00:02',	'midday',	NULL),
(80,	'-5286210766',	NULL,	'2026-04-22 18:00:01',	240,	'2026-04-22 18:00:01',	'2026-04-22 18:00:01',	'night',	NULL),
(81,	'-5286210766',	NULL,	'2026-04-23 05:45:01',	20,	'2026-04-23 05:45:01',	'2026-04-23 05:45:01',	'morning',	NULL),
(82,	'-5286210766',	NULL,	'2026-04-23 11:00:02',	240,	'2026-04-23 11:00:02',	'2026-04-23 11:00:02',	'midday',	NULL),
(83,	'-5286210766',	NULL,	'2026-04-23 18:00:02',	240,	'2026-04-23 18:00:02',	'2026-04-23 18:00:02',	'night',	NULL),
(84,	'-5286210766',	NULL,	'2026-04-24 05:45:01',	20,	'2026-04-24 05:45:01',	'2026-04-24 05:45:01',	'morning',	NULL),
(85,	'-5286210766',	NULL,	'2026-04-24 11:00:02',	240,	'2026-04-24 11:00:02',	'2026-04-24 11:00:02',	'midday',	NULL),
(86,	'-5286210766',	NULL,	'2026-04-24 18:00:01',	240,	'2026-04-24 18:00:01',	'2026-04-24 18:00:01',	'night',	NULL),
(37,	'-5286210766',	NULL,	'2026-04-07 07:45:00',	20,	'2026-04-08 21:58:58',	'2026-04-08 21:59:17',	'morning',	'2026-04-08 21:59:17'),
(38,	'-5286210766',	NULL,	'2026-04-07 13:00:00',	240,	'2026-04-08 21:58:59',	'2026-04-08 22:02:11',	'midday',	'2026-04-08 22:02:11'),
(39,	'-5286210766',	NULL,	'2026-04-07 20:00:00',	240,	'2026-04-08 21:59:00',	'2026-04-08 22:03:12',	'night',	'2026-04-08 22:03:12'),
(40,	'-5286210766',	NULL,	'2026-04-09 05:45:01',	20,	'2026-04-09 05:45:01',	'2026-04-09 12:01:37',	'morning',	'2026-04-09 12:01:37'),
(41,	'-5286210766',	NULL,	'2026-04-09 11:00:01',	240,	'2026-04-09 11:00:01',	'2026-04-09 12:01:38',	'midday',	'2026-04-09 12:01:38'),
(42,	'-5286210766',	NULL,	'2026-04-09 18:00:01',	240,	'2026-04-09 18:00:01',	'2026-04-09 22:00:31',	'night',	'2026-04-09 22:00:31'),
(43,	'-5286210766',	NULL,	'2026-04-10 05:45:01',	20,	'2026-04-10 05:45:01',	'2026-04-10 05:59:11',	'morning',	'2026-04-10 05:59:11'),
(87,	'-5286210766',	NULL,	'2026-04-25 05:45:01',	20,	'2026-04-25 05:45:01',	'2026-04-25 05:45:01',	'morning',	NULL),
(88,	'-5286210766',	NULL,	'2026-04-25 11:00:02',	240,	'2026-04-25 11:00:02',	'2026-04-25 11:00:02',	'midday',	NULL),
(89,	'-5286210766',	NULL,	'2026-04-25 18:00:01',	240,	'2026-04-25 18:00:01',	'2026-04-25 18:00:01',	'night',	NULL),
(90,	'-5286210766',	NULL,	'2026-04-26 05:45:01',	20,	'2026-04-26 05:45:01',	'2026-04-26 05:45:01',	'morning',	NULL),
(91,	'-5286210766',	NULL,	'2026-04-26 11:00:01',	240,	'2026-04-26 11:00:01',	'2026-04-26 11:00:01',	'midday',	NULL),
(92,	'-5286210766',	NULL,	'2026-04-26 18:00:01',	240,	'2026-04-26 18:00:01',	'2026-04-26 18:00:01',	'night',	NULL),
(93,	'-5286210766',	NULL,	'2026-04-27 05:45:01',	20,	'2026-04-27 05:45:01',	'2026-04-27 05:45:01',	'morning',	NULL),
(94,	'-5286210766',	NULL,	'2026-04-27 11:00:01',	240,	'2026-04-27 11:00:01',	'2026-04-27 11:00:01',	'midday',	NULL),
(95,	'-5286210766',	NULL,	'2026-04-27 18:00:01',	240,	'2026-04-27 18:00:01',	'2026-04-27 18:00:01',	'night',	NULL),
(96,	'-5286210766',	NULL,	'2026-04-28 05:45:02',	20,	'2026-04-28 05:45:02',	'2026-04-28 05:45:02',	'morning',	NULL),
(97,	'-5286210766',	NULL,	'2026-04-28 11:00:01',	240,	'2026-04-28 11:00:01',	'2026-04-28 11:00:01',	'midday',	NULL),
(98,	'-5286210766',	NULL,	'2026-04-28 18:00:02',	240,	'2026-04-28 18:00:02',	'2026-04-28 18:00:02',	'night',	NULL),
(99,	'-5286210766',	NULL,	'2026-04-29 05:45:01',	20,	'2026-04-29 05:45:01',	'2026-04-29 05:45:01',	'morning',	NULL),
(100,	'-5286210766',	NULL,	'2026-04-29 11:00:01',	240,	'2026-04-29 11:00:01',	'2026-04-29 11:00:01',	'midday',	NULL),
(101,	'-5286210766',	NULL,	'2026-04-29 18:00:01',	240,	'2026-04-29 18:00:01',	'2026-04-29 18:00:01',	'night',	NULL),
(102,	'-5286210766',	NULL,	'2026-04-30 05:45:01',	20,	'2026-04-30 05:45:01',	'2026-04-30 05:45:01',	'morning',	NULL),
(103,	'-5286210766',	NULL,	'2026-04-30 11:00:01',	240,	'2026-04-30 11:00:01',	'2026-04-30 11:00:01',	'midday',	NULL),
(104,	'-5286210766',	NULL,	'2026-04-30 18:00:02',	240,	'2026-04-30 18:00:02',	'2026-04-30 18:00:02',	'night',	NULL),
(105,	'-5286210766',	NULL,	'2026-05-01 05:45:01',	20,	'2026-05-01 05:45:01',	'2026-05-01 05:45:01',	'morning',	NULL),
(106,	'-5286210766',	NULL,	'2026-05-01 11:00:01',	240,	'2026-05-01 11:00:01',	'2026-05-01 11:00:01',	'midday',	NULL),
(107,	'-5286210766',	NULL,	'2026-05-01 18:00:02',	240,	'2026-05-01 18:00:02',	'2026-05-01 18:00:02',	'night',	NULL),
(108,	'-5286210766',	NULL,	'2026-05-02 05:45:01',	20,	'2026-05-02 05:45:01',	'2026-05-02 05:45:01',	'morning',	NULL),
(109,	'-5286210766',	NULL,	'2026-05-02 11:00:01',	240,	'2026-05-02 11:00:01',	'2026-05-02 11:00:01',	'midday',	NULL),
(110,	'-5286210766',	NULL,	'2026-05-02 18:00:01',	240,	'2026-05-02 18:00:01',	'2026-05-02 18:00:01',	'night',	NULL),
(111,	'-5286210766',	NULL,	'2026-05-03 05:45:01',	20,	'2026-05-03 05:45:01',	'2026-05-03 05:45:01',	'morning',	NULL),
(112,	'-5286210766',	NULL,	'2026-05-03 11:00:01',	240,	'2026-05-03 11:00:01',	'2026-05-03 11:00:01',	'midday',	NULL),
(113,	'-5286210766',	NULL,	'2026-05-03 18:00:01',	240,	'2026-05-03 18:00:01',	'2026-05-03 18:00:01',	'night',	NULL),
(114,	'-5286210766',	NULL,	'2026-05-04 05:45:01',	20,	'2026-05-04 05:45:01',	'2026-05-04 05:45:01',	'morning',	NULL),
(115,	'-5286210766',	NULL,	'2026-05-04 11:00:02',	240,	'2026-05-04 11:00:02',	'2026-05-04 11:00:02',	'midday',	NULL),
(116,	'-5286210766',	NULL,	'2026-05-04 18:00:02',	240,	'2026-05-04 18:00:02',	'2026-05-04 18:00:02',	'night',	NULL),
(117,	'-5286210766',	NULL,	'2026-05-05 05:45:01',	20,	'2026-05-05 05:45:01',	'2026-05-05 05:45:01',	'morning',	NULL),
(118,	'-5286210766',	NULL,	'2026-05-05 11:00:01',	240,	'2026-05-05 11:00:01',	'2026-05-05 11:00:01',	'midday',	NULL),
(119,	'-5286210766',	NULL,	'2026-05-05 18:00:01',	240,	'2026-05-05 18:00:01',	'2026-05-05 18:00:01',	'night',	NULL),
(120,	'-5286210766',	NULL,	'2026-05-06 05:45:01',	20,	'2026-05-06 05:45:01',	'2026-05-06 05:45:01',	'morning',	NULL),
(121,	'-5286210766',	NULL,	'2026-05-06 11:00:02',	240,	'2026-05-06 11:00:02',	'2026-05-06 11:00:02',	'midday',	NULL),
(122,	'-5286210766',	NULL,	'2026-05-06 18:00:02',	240,	'2026-05-06 18:00:02',	'2026-05-06 18:00:02',	'night',	NULL),
(123,	'-5286210766',	NULL,	'2026-05-07 05:45:01',	20,	'2026-05-07 05:45:01',	'2026-05-07 05:45:01',	'morning',	NULL),
(124,	'-5286210766',	NULL,	'2026-05-07 11:00:01',	240,	'2026-05-07 11:00:01',	'2026-05-07 11:00:01',	'midday',	NULL),
(125,	'-5286210766',	NULL,	'2026-05-07 18:00:01',	240,	'2026-05-07 18:00:01',	'2026-05-07 18:00:01',	'night',	NULL),
(126,	'-5286210766',	NULL,	'2026-05-08 05:45:01',	20,	'2026-05-08 05:45:01',	'2026-05-08 05:45:01',	'morning',	NULL),
(127,	'-5286210766',	NULL,	'2026-05-08 11:00:02',	240,	'2026-05-08 11:00:02',	'2026-05-08 11:00:02',	'midday',	NULL),
(128,	'-5286210766',	NULL,	'2026-05-08 18:00:02',	240,	'2026-05-08 18:00:02',	'2026-05-08 18:00:02',	'night',	NULL),
(129,	'-5286210766',	NULL,	'2026-05-09 05:45:01',	20,	'2026-05-09 05:45:01',	'2026-05-09 05:45:01',	'morning',	NULL),
(130,	'-5286210766',	NULL,	'2026-05-09 11:00:01',	240,	'2026-05-09 11:00:01',	'2026-05-09 11:00:01',	'midday',	NULL),
(131,	'-5286210766',	NULL,	'2026-05-09 18:00:01',	240,	'2026-05-09 18:00:01',	'2026-05-09 18:00:01',	'night',	NULL),
(132,	'-5286210766',	NULL,	'2026-05-10 05:45:02',	20,	'2026-05-10 05:45:02',	'2026-05-10 05:45:02',	'morning',	NULL),
(133,	'-5286210766',	NULL,	'2026-05-10 11:00:01',	240,	'2026-05-10 11:00:01',	'2026-05-10 11:00:01',	'midday',	NULL),
(134,	'-5286210766',	NULL,	'2026-05-10 18:00:02',	240,	'2026-05-10 18:00:02',	'2026-05-10 18:00:02',	'night',	NULL),
(135,	'-5286210766',	NULL,	'2026-05-11 05:45:01',	20,	'2026-05-11 05:45:01',	'2026-05-11 05:45:01',	'morning',	NULL),
(136,	'-5286210766',	NULL,	'2026-05-11 11:00:02',	240,	'2026-05-11 11:00:02',	'2026-05-11 11:00:02',	'midday',	NULL),
(137,	'-5286210766',	NULL,	'2026-05-11 18:00:01',	240,	'2026-05-11 18:00:01',	'2026-05-11 18:00:01',	'night',	NULL),
(138,	'-5286210766',	NULL,	'2026-05-12 05:45:02',	20,	'2026-05-12 05:45:02',	'2026-05-12 05:45:02',	'morning',	NULL),
(139,	'-5286210766',	NULL,	'2026-05-12 11:00:01',	240,	'2026-05-12 11:00:01',	'2026-05-12 11:00:01',	'midday',	NULL),
(140,	'-5286210766',	NULL,	'2026-05-12 18:00:01',	240,	'2026-05-12 18:00:01',	'2026-05-12 18:00:01',	'night',	NULL),
(141,	'-5286210766',	NULL,	'2026-05-13 05:45:01',	20,	'2026-05-13 05:45:01',	'2026-05-13 05:45:01',	'morning',	NULL),
(142,	'-5286210766',	NULL,	'2026-05-13 11:00:02',	240,	'2026-05-13 11:00:02',	'2026-05-13 11:00:02',	'midday',	NULL),
(143,	'-5286210766',	NULL,	'2026-05-13 18:00:01',	240,	'2026-05-13 18:00:01',	'2026-05-13 18:00:01',	'night',	NULL),
(144,	'-5286210766',	NULL,	'2026-05-14 05:45:01',	20,	'2026-05-14 05:45:01',	'2026-05-14 05:45:01',	'morning',	NULL),
(145,	'-5286210766',	NULL,	'2026-05-14 11:00:01',	240,	'2026-05-14 11:00:01',	'2026-05-14 11:00:01',	'midday',	NULL),
(146,	'-5286210766',	NULL,	'2026-05-14 18:00:02',	240,	'2026-05-14 18:00:02',	'2026-05-14 18:00:02',	'night',	NULL),
(147,	'-5286210766',	NULL,	'2026-05-15 05:45:01',	20,	'2026-05-15 05:45:01',	'2026-05-15 05:45:01',	'morning',	NULL),
(148,	'-5286210766',	NULL,	'2026-05-15 11:00:01',	240,	'2026-05-15 11:00:01',	'2026-05-15 11:00:01',	'midday',	NULL),
(149,	'-5286210766',	NULL,	'2026-05-15 18:00:01',	240,	'2026-05-15 18:00:01',	'2026-05-15 18:00:01',	'night',	NULL),
(150,	'-5286210766',	NULL,	'2026-05-16 05:45:01',	20,	'2026-05-16 05:45:01',	'2026-05-16 05:45:01',	'morning',	NULL),
(151,	'-5286210766',	NULL,	'2026-05-16 11:00:01',	240,	'2026-05-16 11:00:01',	'2026-05-16 11:00:01',	'midday',	NULL),
(152,	'-5286210766',	NULL,	'2026-05-16 18:00:01',	240,	'2026-05-16 18:00:01',	'2026-05-16 18:00:01',	'night',	NULL),
(153,	'-5286210766',	NULL,	'2026-05-17 05:45:01',	20,	'2026-05-17 05:45:01',	'2026-05-17 05:45:01',	'morning',	NULL),
(154,	'-5286210766',	NULL,	'2026-05-17 11:00:01',	240,	'2026-05-17 11:00:01',	'2026-05-17 11:00:01',	'midday',	NULL),
(155,	'-5286210766',	NULL,	'2026-05-17 18:00:01',	240,	'2026-05-17 18:00:01',	'2026-05-17 18:00:01',	'night',	NULL),
(156,	'-5286210766',	NULL,	'2026-05-18 05:45:01',	20,	'2026-05-18 05:45:01',	'2026-05-18 05:45:01',	'morning',	NULL),
(157,	'-5286210766',	NULL,	'2026-05-18 11:00:01',	240,	'2026-05-18 11:00:01',	'2026-05-18 11:00:01',	'midday',	NULL),
(158,	'-5286210766',	NULL,	'2026-05-18 18:00:01',	240,	'2026-05-18 18:00:01',	'2026-05-18 18:00:01',	'night',	NULL),
(159,	'-5286210766',	NULL,	'2026-05-19 05:45:01',	20,	'2026-05-19 05:45:01',	'2026-05-19 05:45:01',	'morning',	NULL),
(160,	'-5286210766',	NULL,	'2026-05-19 11:00:01',	240,	'2026-05-19 11:00:01',	'2026-05-19 11:00:01',	'midday',	NULL),
(161,	'-5286210766',	NULL,	'2026-05-19 18:00:01',	240,	'2026-05-19 18:00:01',	'2026-05-19 18:00:01',	'night',	NULL),
(162,	'-5286210766',	NULL,	'2026-05-20 05:45:01',	20,	'2026-05-20 05:45:01',	'2026-05-20 05:45:01',	'morning',	NULL),
(163,	'-5286210766',	NULL,	'2026-05-20 11:00:02',	240,	'2026-05-20 11:00:02',	'2026-05-20 11:00:02',	'midday',	NULL),
(164,	'-5286210766',	NULL,	'2026-05-20 18:00:01',	240,	'2026-05-20 18:00:01',	'2026-05-20 18:00:01',	'night',	NULL),
(165,	'-5286210766',	NULL,	'2026-05-21 05:45:01',	20,	'2026-05-21 05:45:01',	'2026-05-21 05:45:01',	'morning',	NULL),
(166,	'-5286210766',	NULL,	'2026-05-21 11:00:02',	240,	'2026-05-21 11:00:02',	'2026-05-21 11:00:02',	'midday',	NULL),
(167,	'-5286210766',	NULL,	'2026-05-21 18:00:02',	240,	'2026-05-21 18:00:02',	'2026-05-21 18:00:02',	'night',	NULL),
(168,	'-5286210766',	NULL,	'2026-05-22 05:45:01',	20,	'2026-05-22 05:45:01',	'2026-05-22 05:45:01',	'morning',	NULL),
(169,	'-5286210766',	NULL,	'2026-05-22 11:00:01',	240,	'2026-05-22 11:00:01',	'2026-05-22 11:00:01',	'midday',	NULL),
(170,	'-5286210766',	NULL,	'2026-05-22 18:00:01',	240,	'2026-05-22 18:00:01',	'2026-05-22 18:00:01',	'night',	NULL),
(171,	'-5286210766',	NULL,	'2026-05-23 05:45:01',	20,	'2026-05-23 05:45:01',	'2026-05-23 05:45:01',	'morning',	NULL),
(172,	'-5286210766',	NULL,	'2026-05-23 11:00:01',	240,	'2026-05-23 11:00:01',	'2026-05-23 11:00:01',	'midday',	NULL),
(173,	'-5286210766',	NULL,	'2026-05-23 18:00:01',	240,	'2026-05-23 18:00:01',	'2026-05-23 18:00:01',	'night',	NULL),
(174,	'-5286210766',	NULL,	'2026-05-24 05:45:01',	20,	'2026-05-24 05:45:01',	'2026-05-24 05:45:01',	'morning',	NULL),
(175,	'-5286210766',	NULL,	'2026-05-24 11:00:01',	240,	'2026-05-24 11:00:01',	'2026-05-24 11:00:01',	'midday',	NULL),
(176,	'-5286210766',	NULL,	'2026-05-24 18:00:01',	240,	'2026-05-24 18:00:01',	'2026-05-24 18:00:01',	'night',	NULL),
(177,	'-5286210766',	NULL,	'2026-05-25 05:45:01',	20,	'2026-05-25 05:45:01',	'2026-05-25 05:45:01',	'morning',	NULL),
(178,	'-5286210766',	NULL,	'2026-05-25 11:00:01',	240,	'2026-05-25 11:00:01',	'2026-05-25 11:00:01',	'midday',	NULL),
(179,	'-5286210766',	NULL,	'2026-05-25 18:00:02',	240,	'2026-05-25 18:00:02',	'2026-05-25 18:00:02',	'night',	NULL),
(180,	'-5286210766',	NULL,	'2026-05-26 05:45:02',	20,	'2026-05-26 05:45:02',	'2026-05-26 05:45:02',	'morning',	NULL),
(181,	'-5286210766',	NULL,	'2026-05-26 11:00:02',	240,	'2026-05-26 11:00:02',	'2026-05-26 11:00:02',	'midday',	NULL),
(182,	'-5286210766',	NULL,	'2026-05-26 18:00:02',	240,	'2026-05-26 18:00:02',	'2026-05-26 18:00:02',	'night',	NULL),
(183,	'-5286210766',	NULL,	'2026-05-27 05:45:01',	20,	'2026-05-27 05:45:01',	'2026-05-27 05:45:01',	'morning',	NULL),
(184,	'-5286210766',	NULL,	'2026-05-27 11:00:01',	240,	'2026-05-27 11:00:01',	'2026-05-27 11:00:01',	'midday',	NULL),
(185,	'-5286210766',	NULL,	'2026-05-27 18:00:01',	240,	'2026-05-27 18:00:01',	'2026-05-27 18:00:01',	'night',	NULL),
(186,	'-5286210766',	NULL,	'2026-05-28 05:45:01',	20,	'2026-05-28 05:45:01',	'2026-05-28 05:45:01',	'morning',	NULL),
(187,	'-5286210766',	NULL,	'2026-05-28 11:00:01',	240,	'2026-05-28 11:00:01',	'2026-05-28 11:00:01',	'midday',	NULL),
(188,	'-5286210766',	NULL,	'2026-05-28 18:00:01',	240,	'2026-05-28 18:00:01',	'2026-05-28 18:00:01',	'night',	NULL),
(189,	'-5286210766',	NULL,	'2026-05-29 05:45:01',	20,	'2026-05-29 05:45:01',	'2026-05-29 05:45:01',	'morning',	NULL),
(190,	'-5286210766',	NULL,	'2026-05-29 11:00:02',	240,	'2026-05-29 11:00:02',	'2026-05-29 11:00:02',	'midday',	NULL),
(191,	'-5286210766',	NULL,	'2026-05-29 18:00:01',	240,	'2026-05-29 18:00:01',	'2026-05-29 18:00:01',	'night',	NULL),
(192,	'-5286210766',	NULL,	'2026-05-30 05:45:01',	20,	'2026-05-30 05:45:01',	'2026-05-30 05:45:01',	'morning',	NULL),
(193,	'-5286210766',	NULL,	'2026-05-30 11:00:01',	240,	'2026-05-30 11:00:01',	'2026-05-30 11:00:01',	'midday',	NULL),
(194,	'-5286210766',	NULL,	'2026-05-30 18:00:01',	240,	'2026-05-30 18:00:01',	'2026-05-30 18:00:01',	'night',	NULL),
(195,	'-5286210766',	NULL,	'2026-05-31 05:45:01',	20,	'2026-05-31 05:45:01',	'2026-05-31 05:45:01',	'morning',	NULL),
(196,	'-5286210766',	NULL,	'2026-05-31 11:00:02',	240,	'2026-05-31 11:00:02',	'2026-05-31 11:00:02',	'midday',	NULL),
(197,	'-5286210766',	NULL,	'2026-05-31 18:00:01',	240,	'2026-05-31 18:00:01',	'2026-05-31 18:00:01',	'night',	NULL),
(198,	'-5286210766',	NULL,	'2026-06-01 05:45:01',	20,	'2026-06-01 05:45:01',	'2026-06-01 05:45:01',	'morning',	NULL),
(199,	'-5286210766',	NULL,	'2026-06-01 11:00:02',	240,	'2026-06-01 11:00:02',	'2026-06-01 11:00:02',	'midday',	NULL),
(200,	'-5286210766',	NULL,	'2026-06-01 18:00:01',	240,	'2026-06-01 18:00:01',	'2026-06-01 18:00:01',	'night',	NULL),
(201,	'-5286210766',	NULL,	'2026-06-02 05:45:01',	20,	'2026-06-02 05:45:01',	'2026-06-02 05:45:01',	'morning',	NULL),
(202,	'-5286210766',	NULL,	'2026-06-02 11:00:01',	240,	'2026-06-02 11:00:01',	'2026-06-02 11:00:01',	'midday',	NULL),
(203,	'-5286210766',	NULL,	'2026-06-02 18:00:01',	240,	'2026-06-02 18:00:01',	'2026-06-02 18:00:01',	'night',	NULL),
(204,	'-5286210766',	NULL,	'2026-06-03 05:45:01',	20,	'2026-06-03 05:45:01',	'2026-06-03 05:45:01',	'morning',	NULL),
(205,	'-5286210766',	NULL,	'2026-06-03 11:00:01',	240,	'2026-06-03 11:00:01',	'2026-06-03 11:00:01',	'midday',	NULL),
(206,	'-5286210766',	NULL,	'2026-06-03 18:00:01',	240,	'2026-06-03 18:00:01',	'2026-06-03 18:00:01',	'night',	NULL),
(207,	'-5286210766',	NULL,	'2026-06-04 05:45:01',	20,	'2026-06-04 05:45:01',	'2026-06-04 05:45:01',	'morning',	NULL),
(208,	'-5286210766',	NULL,	'2026-06-04 11:00:01',	240,	'2026-06-04 11:00:01',	'2026-06-04 11:00:01',	'midday',	NULL),
(209,	'-5286210766',	NULL,	'2026-06-04 18:00:01',	240,	'2026-06-04 18:00:01',	'2026-06-04 18:00:01',	'night',	NULL),
(210,	'-5286210766',	NULL,	'2026-06-05 05:45:01',	20,	'2026-06-05 05:45:01',	'2026-06-05 05:45:01',	'morning',	NULL),
(211,	'-5286210766',	NULL,	'2026-06-05 11:00:02',	240,	'2026-06-05 11:00:02',	'2026-06-05 11:00:02',	'midday',	NULL),
(212,	'-5286210766',	NULL,	'2026-06-05 18:00:01',	240,	'2026-06-05 18:00:01',	'2026-06-05 18:00:01',	'night',	NULL),
(213,	'-5286210766',	NULL,	'2026-06-06 05:45:01',	20,	'2026-06-06 05:45:01',	'2026-06-06 05:45:01',	'morning',	NULL),
(214,	'-5286210766',	NULL,	'2026-06-06 11:00:01',	240,	'2026-06-06 11:00:01',	'2026-06-06 11:00:01',	'midday',	NULL),
(215,	'-5286210766',	NULL,	'2026-06-06 18:00:01',	240,	'2026-06-06 18:00:01',	'2026-06-06 18:00:01',	'night',	NULL),
(216,	'-5286210766',	NULL,	'2026-06-07 05:45:01',	20,	'2026-06-07 05:45:01',	'2026-06-07 05:45:01',	'morning',	NULL),
(217,	'-5286210766',	NULL,	'2026-06-07 11:00:01',	240,	'2026-06-07 11:00:01',	'2026-06-07 11:00:01',	'midday',	NULL),
(218,	'-5286210766',	NULL,	'2026-06-07 18:00:01',	240,	'2026-06-07 18:00:01',	'2026-06-07 18:00:01',	'night',	NULL),
(219,	'-5286210766',	NULL,	'2026-06-08 05:45:01',	20,	'2026-06-08 05:45:01',	'2026-06-08 05:45:01',	'morning',	NULL),
(220,	'-5286210766',	NULL,	'2026-06-08 11:00:02',	240,	'2026-06-08 11:00:02',	'2026-06-08 11:00:02',	'midday',	NULL),
(221,	'-5286210766',	NULL,	'2026-06-08 18:00:01',	240,	'2026-06-08 18:00:01',	'2026-06-08 18:00:01',	'night',	NULL),
(222,	'-5286210766',	NULL,	'2026-06-09 05:45:02',	20,	'2026-06-09 05:45:02',	'2026-06-09 05:45:02',	'morning',	NULL),
(223,	'-5286210766',	NULL,	'2026-06-09 11:00:01',	240,	'2026-06-09 11:00:01',	'2026-06-09 11:00:01',	'midday',	NULL),
(224,	'-5286210766',	NULL,	'2026-06-09 18:00:01',	240,	'2026-06-09 18:00:01',	'2026-06-09 18:00:01',	'night',	NULL),
(225,	'-5286210766',	NULL,	'2026-06-10 05:45:01',	20,	'2026-06-10 05:45:01',	'2026-06-10 05:45:01',	'morning',	NULL),
(226,	'-5286210766',	NULL,	'2026-06-10 11:00:01',	240,	'2026-06-10 11:00:01',	'2026-06-10 11:00:01',	'midday',	NULL),
(227,	'-5286210766',	NULL,	'2026-06-10 18:00:01',	240,	'2026-06-10 18:00:01',	'2026-06-10 18:00:01',	'night',	NULL),
(228,	'-5286210766',	NULL,	'2026-06-11 05:45:01',	20,	'2026-06-11 05:45:01',	'2026-06-11 05:45:01',	'morning',	NULL),
(229,	'-5286210766',	NULL,	'2026-06-11 18:00:02',	240,	'2026-06-11 18:00:02',	'2026-06-11 18:00:02',	'night',	NULL),
(230,	'-5286210766',	NULL,	'2026-06-12 05:45:02',	20,	'2026-06-12 05:45:02',	'2026-06-12 05:45:02',	'morning',	NULL),
(231,	'-5286210766',	NULL,	'2026-06-12 11:00:01',	240,	'2026-06-12 11:00:01',	'2026-06-12 11:00:01',	'midday',	NULL),
(232,	'-5286210766',	NULL,	'2026-06-12 18:00:01',	240,	'2026-06-12 18:00:01',	'2026-06-12 18:00:01',	'night',	NULL),
(233,	'-5286210766',	NULL,	'2026-06-13 05:45:01',	20,	'2026-06-13 05:45:01',	'2026-06-13 05:45:01',	'morning',	NULL),
(234,	'-5286210766',	NULL,	'2026-06-13 11:00:01',	240,	'2026-06-13 11:00:01',	'2026-06-13 11:00:01',	'midday',	NULL),
(235,	'-5286210766',	NULL,	'2026-06-13 18:00:01',	240,	'2026-06-13 18:00:01',	'2026-06-13 18:00:01',	'night',	NULL),
(236,	'-5286210766',	NULL,	'2026-06-14 05:45:01',	20,	'2026-06-14 05:45:01',	'2026-06-14 05:45:01',	'morning',	NULL),
(237,	'-5286210766',	NULL,	'2026-06-14 11:00:01',	240,	'2026-06-14 11:00:01',	'2026-06-14 11:00:01',	'midday',	NULL),
(238,	'-5286210766',	NULL,	'2026-06-14 18:00:01',	240,	'2026-06-14 18:00:01',	'2026-06-14 18:00:01',	'night',	NULL),
(239,	'-5286210766',	NULL,	'2026-06-15 05:45:01',	20,	'2026-06-15 05:45:01',	'2026-06-15 05:45:01',	'morning',	NULL),
(240,	'-5286210766',	NULL,	'2026-06-15 11:00:01',	240,	'2026-06-15 11:00:01',	'2026-06-15 11:00:01',	'midday',	NULL),
(241,	'-5286210766',	NULL,	'2026-06-15 18:00:01',	240,	'2026-06-15 18:00:01',	'2026-06-15 18:00:01',	'night',	NULL),
(242,	'-5286210766',	NULL,	'2026-06-16 05:45:01',	20,	'2026-06-16 05:45:01',	'2026-06-16 05:45:01',	'morning',	NULL),
(243,	'-5286210766',	NULL,	'2026-06-16 11:00:02',	240,	'2026-06-16 11:00:02',	'2026-06-16 11:00:02',	'midday',	NULL),
(244,	'-5286210766',	NULL,	'2026-06-16 18:00:01',	240,	'2026-06-16 18:00:01',	'2026-06-16 18:00:01',	'night',	NULL),
(245,	'-5286210766',	NULL,	'2026-06-17 05:45:01',	20,	'2026-06-17 05:45:01',	'2026-06-17 05:45:01',	'morning',	NULL),
(246,	'-5286210766',	NULL,	'2026-06-17 11:00:01',	240,	'2026-06-17 11:00:01',	'2026-06-17 11:00:01',	'midday',	NULL),
(247,	'-5286210766',	NULL,	'2026-06-17 18:00:02',	240,	'2026-06-17 18:00:02',	'2026-06-17 18:00:02',	'night',	NULL),
(248,	'-5286210766',	NULL,	'2026-06-18 05:45:01',	20,	'2026-06-18 05:45:01',	'2026-06-18 05:45:01',	'morning',	NULL),
(249,	'-5286210766',	NULL,	'2026-06-18 11:00:01',	240,	'2026-06-18 11:00:01',	'2026-06-18 11:00:01',	'midday',	NULL),
(250,	'-5286210766',	NULL,	'2026-06-18 18:00:02',	240,	'2026-06-18 18:00:02',	'2026-06-18 18:00:02',	'night',	NULL),
(251,	'-5286210766',	NULL,	'2026-06-19 05:45:02',	20,	'2026-06-19 05:45:02',	'2026-06-19 05:45:02',	'morning',	NULL),
(252,	'-5286210766',	NULL,	'2026-06-19 11:00:02',	240,	'2026-06-19 11:00:02',	'2026-06-19 11:00:02',	'midday',	NULL),
(253,	'-5286210766',	NULL,	'2026-06-19 18:00:01',	240,	'2026-06-19 18:00:01',	'2026-06-19 18:00:01',	'night',	NULL),
(254,	'-5286210766',	NULL,	'2026-06-20 05:45:02',	20,	'2026-06-20 05:45:02',	'2026-06-20 05:45:02',	'morning',	NULL),
(255,	'-5286210766',	NULL,	'2026-06-20 11:00:02',	240,	'2026-06-20 11:00:02',	'2026-06-20 11:00:02',	'midday',	NULL),
(256,	'-5286210766',	NULL,	'2026-06-20 18:00:01',	240,	'2026-06-20 18:00:01',	'2026-06-20 18:00:01',	'night',	NULL),
(257,	'-5286210766',	NULL,	'2026-06-21 05:45:01',	20,	'2026-06-21 05:45:01',	'2026-06-21 05:45:01',	'morning',	NULL),
(258,	'-5286210766',	NULL,	'2026-06-21 11:00:01',	240,	'2026-06-21 11:00:01',	'2026-06-21 11:00:01',	'midday',	NULL),
(259,	'-5286210766',	NULL,	'2026-06-21 18:00:01',	240,	'2026-06-21 18:00:01',	'2026-06-21 18:00:01',	'night',	NULL),
(260,	'-5286210766',	NULL,	'2026-06-22 05:45:01',	20,	'2026-06-22 05:45:01',	'2026-06-22 05:45:01',	'morning',	NULL),
(261,	'-5286210766',	NULL,	'2026-06-22 11:00:01',	240,	'2026-06-22 11:00:01',	'2026-06-22 11:00:01',	'midday',	NULL),
(262,	'-5286210766',	NULL,	'2026-06-22 18:00:01',	240,	'2026-06-22 18:00:01',	'2026-06-22 18:00:01',	'night',	NULL),
(263,	'-5286210766',	NULL,	'2026-06-23 05:45:02',	20,	'2026-06-23 05:45:02',	'2026-06-23 05:45:02',	'morning',	NULL),
(264,	'-5286210766',	NULL,	'2026-06-23 11:00:01',	240,	'2026-06-23 11:00:01',	'2026-06-23 11:00:01',	'midday',	NULL),
(265,	'-5286210766',	NULL,	'2026-06-23 18:00:01',	240,	'2026-06-23 18:00:01',	'2026-06-23 18:00:01',	'night',	NULL),
(266,	'-5286210766',	NULL,	'2026-06-24 05:45:01',	20,	'2026-06-24 05:45:01',	'2026-06-24 05:45:01',	'morning',	NULL),
(267,	'-5286210766',	NULL,	'2026-06-24 11:00:01',	240,	'2026-06-24 11:00:01',	'2026-06-24 11:00:01',	'midday',	NULL),
(268,	'-5286210766',	NULL,	'2026-06-24 18:00:01',	240,	'2026-06-24 18:00:01',	'2026-06-24 18:00:01',	'night',	NULL),
(269,	'-5286210766',	NULL,	'2026-06-25 05:45:01',	20,	'2026-06-25 05:45:01',	'2026-06-25 05:45:01',	'morning',	NULL),
(270,	'-5286210766',	NULL,	'2026-06-25 11:00:01',	240,	'2026-06-25 11:00:01',	'2026-06-25 11:00:01',	'midday',	NULL),
(271,	'-5286210766',	NULL,	'2026-06-25 18:00:01',	240,	'2026-06-25 18:00:01',	'2026-06-25 18:00:01',	'night',	NULL),
(272,	'-5286210766',	NULL,	'2026-06-26 05:45:01',	20,	'2026-06-26 05:45:01',	'2026-06-26 05:45:01',	'morning',	NULL),
(273,	'-5286210766',	NULL,	'2026-06-26 11:00:01',	240,	'2026-06-26 11:00:01',	'2026-06-26 11:00:01',	'midday',	NULL),
(274,	'-5286210766',	NULL,	'2026-06-26 18:00:01',	240,	'2026-06-26 18:00:01',	'2026-06-26 18:00:01',	'night',	NULL),
(275,	'-5286210766',	NULL,	'2026-06-27 05:45:01',	20,	'2026-06-27 05:45:01',	'2026-06-27 05:45:01',	'morning',	NULL),
(276,	'-5286210766',	NULL,	'2026-06-27 11:00:01',	240,	'2026-06-27 11:00:01',	'2026-06-27 11:00:01',	'midday',	NULL),
(277,	'-5286210766',	NULL,	'2026-06-27 18:00:01',	240,	'2026-06-27 18:00:01',	'2026-06-27 18:00:01',	'night',	NULL),
(278,	'-5286210766',	NULL,	'2026-06-28 05:45:01',	20,	'2026-06-28 05:45:01',	'2026-06-28 05:45:01',	'morning',	NULL),
(279,	'-5286210766',	NULL,	'2026-06-28 11:00:01',	240,	'2026-06-28 11:00:01',	'2026-06-28 11:00:01',	'midday',	NULL),
(280,	'-5286210766',	NULL,	'2026-06-28 18:00:01',	240,	'2026-06-28 18:00:01',	'2026-06-28 18:00:01',	'night',	NULL),
(281,	'-5286210766',	NULL,	'2026-06-29 05:45:01',	20,	'2026-06-29 05:45:01',	'2026-06-29 05:45:01',	'morning',	NULL),
(282,	'-5286210766',	NULL,	'2026-06-29 11:00:01',	240,	'2026-06-29 11:00:01',	'2026-06-29 11:00:01',	'midday',	NULL),
(283,	'-5286210766',	NULL,	'2026-06-29 18:00:01',	240,	'2026-06-29 18:00:01',	'2026-06-29 18:00:01',	'night',	NULL),
(284,	'-5286210766',	NULL,	'2026-06-30 05:45:01',	20,	'2026-06-30 05:45:01',	'2026-06-30 05:45:01',	'morning',	NULL),
(285,	'-5286210766',	NULL,	'2026-06-30 11:00:01',	240,	'2026-06-30 11:00:01',	'2026-06-30 11:00:01',	'midday',	NULL),
(286,	'-5286210766',	NULL,	'2026-06-30 18:00:02',	240,	'2026-06-30 18:00:02',	'2026-06-30 18:00:02',	'night',	NULL),
(287,	'-5286210766',	NULL,	'2026-07-01 05:45:02',	20,	'2026-07-01 05:45:02',	'2026-07-01 05:45:02',	'morning',	NULL),
(288,	'-5286210766',	NULL,	'2026-07-01 11:00:01',	240,	'2026-07-01 11:00:01',	'2026-07-01 11:00:01',	'midday',	NULL),
(289,	'-5286210766',	NULL,	'2026-07-01 18:00:01',	240,	'2026-07-01 18:00:01',	'2026-07-01 18:00:01',	'night',	NULL),
(290,	'-5286210766',	NULL,	'2026-07-02 05:45:01',	20,	'2026-07-02 05:45:01',	'2026-07-02 05:45:01',	'morning',	NULL),
(291,	'-5286210766',	NULL,	'2026-07-02 11:00:01',	240,	'2026-07-02 11:00:01',	'2026-07-02 11:00:01',	'midday',	NULL),
(292,	'-5286210766',	NULL,	'2026-07-02 18:00:01',	240,	'2026-07-02 18:00:01',	'2026-07-02 18:00:01',	'night',	NULL),
(293,	'-5286210766',	NULL,	'2026-07-03 05:45:01',	20,	'2026-07-03 05:45:01',	'2026-07-03 05:45:01',	'morning',	NULL),
(294,	'-5286210766',	NULL,	'2026-07-03 11:00:01',	240,	'2026-07-03 11:00:01',	'2026-07-03 11:00:01',	'midday',	NULL),
(295,	'-5286210766',	NULL,	'2026-07-03 18:00:01',	240,	'2026-07-03 18:00:01',	'2026-07-03 18:00:01',	'night',	NULL),
(296,	'-5286210766',	NULL,	'2026-07-04 05:45:02',	20,	'2026-07-04 05:45:02',	'2026-07-04 05:45:02',	'morning',	NULL),
(297,	'-5286210766',	NULL,	'2026-07-04 11:00:01',	240,	'2026-07-04 11:00:01',	'2026-07-04 11:00:01',	'midday',	NULL),
(298,	'-5286210766',	NULL,	'2026-07-04 18:00:01',	240,	'2026-07-04 18:00:01',	'2026-07-04 18:00:01',	'night',	NULL),
(299,	'-5286210766',	NULL,	'2026-07-05 05:45:01',	20,	'2026-07-05 05:45:01',	'2026-07-05 05:45:01',	'morning',	NULL),
(300,	'-5286210766',	NULL,	'2026-07-05 11:00:01',	240,	'2026-07-05 11:00:01',	'2026-07-05 11:00:01',	'midday',	NULL),
(301,	'-5286210766',	NULL,	'2026-07-05 18:00:01',	240,	'2026-07-05 18:00:01',	'2026-07-05 18:00:01',	'night',	NULL),
(302,	'-5286210766',	NULL,	'2026-07-06 05:45:02',	20,	'2026-07-06 05:45:02',	'2026-07-06 05:45:02',	'morning',	NULL),
(303,	'-5286210766',	NULL,	'2026-07-06 11:00:01',	240,	'2026-07-06 11:00:01',	'2026-07-06 11:00:01',	'midday',	NULL),
(304,	'-5286210766',	NULL,	'2026-07-06 18:00:01',	240,	'2026-07-06 18:00:01',	'2026-07-06 18:00:01',	'night',	NULL),
(305,	'-5286210766',	NULL,	'2026-07-07 05:45:02',	20,	'2026-07-07 05:45:02',	'2026-07-07 05:45:02',	'morning',	NULL),
(306,	'-5286210766',	NULL,	'2026-07-07 11:00:02',	240,	'2026-07-07 11:00:02',	'2026-07-07 11:00:02',	'midday',	NULL),
(307,	'-5286210766',	NULL,	'2026-07-07 18:00:02',	240,	'2026-07-07 18:00:02',	'2026-07-07 18:00:02',	'night',	NULL),
(308,	'-5286210766',	NULL,	'2026-07-08 05:45:01',	20,	'2026-07-08 05:45:01',	'2026-07-08 05:45:01',	'morning',	NULL),
(309,	'-5286210766',	NULL,	'2026-07-08 11:00:01',	240,	'2026-07-08 11:00:01',	'2026-07-08 11:00:01',	'midday',	NULL),
(310,	'-5286210766',	NULL,	'2026-07-08 18:00:02',	240,	'2026-07-08 18:00:02',	'2026-07-08 18:00:02',	'night',	NULL),
(311,	'-5286210766',	NULL,	'2026-07-09 05:45:01',	20,	'2026-07-09 05:45:01',	'2026-07-09 05:45:01',	'morning',	NULL),
(312,	'-5286210766',	NULL,	'2026-07-09 11:00:01',	240,	'2026-07-09 11:00:01',	'2026-07-09 11:00:01',	'midday',	NULL),
(313,	'-5286210766',	NULL,	'2026-07-09 18:00:01',	240,	'2026-07-09 18:00:01',	'2026-07-09 18:00:01',	'night',	NULL),
(314,	'-5286210766',	NULL,	'2026-07-10 05:45:02',	20,	'2026-07-10 05:45:02',	'2026-07-10 05:45:02',	'morning',	NULL),
(315,	'-5286210766',	NULL,	'2026-07-10 11:00:01',	240,	'2026-07-10 11:00:01',	'2026-07-10 11:00:01',	'midday',	NULL),
(316,	'-5286210766',	NULL,	'2026-07-10 18:00:01',	240,	'2026-07-10 18:00:01',	'2026-07-10 18:00:01',	'night',	NULL),
(317,	'-5286210766',	NULL,	'2026-07-11 05:45:01',	20,	'2026-07-11 05:45:01',	'2026-07-11 05:45:01',	'morning',	NULL),
(318,	'-5286210766',	NULL,	'2026-07-15 11:00:01',	240,	'2026-07-15 11:00:01',	'2026-07-15 11:00:01',	'midday',	NULL),
(319,	'-5286210766',	NULL,	'2026-07-15 18:00:01',	240,	'2026-07-15 18:00:01',	'2026-07-15 18:00:01',	'night',	NULL),
(320,	'-5286210766',	NULL,	'2026-07-16 05:45:01',	20,	'2026-07-16 05:45:01',	'2026-07-16 05:45:01',	'morning',	NULL),
(321,	'-5286210766',	NULL,	'2026-07-16 11:00:01',	240,	'2026-07-16 11:00:01',	'2026-07-16 11:00:01',	'midday',	NULL),
(322,	'-5286210766',	NULL,	'2026-07-16 18:00:01',	240,	'2026-07-16 18:00:01',	'2026-07-16 18:00:01',	'night',	NULL),
(323,	'-5286210766',	NULL,	'2026-07-17 05:45:01',	20,	'2026-07-17 05:45:01',	'2026-07-17 05:45:01',	'morning',	NULL),
(324,	'-5286210766',	NULL,	'2026-07-17 11:00:01',	240,	'2026-07-17 11:00:01',	'2026-07-17 11:00:01',	'midday',	NULL),
(325,	'-5286210766',	NULL,	'2026-07-17 18:00:01',	240,	'2026-07-17 18:00:01',	'2026-07-17 18:00:01',	'night',	NULL),
(326,	'-5286210766',	NULL,	'2026-07-18 05:45:01',	20,	'2026-07-18 05:45:01',	'2026-07-18 05:45:01',	'morning',	NULL),
(327,	'-5286210766',	NULL,	'2026-07-18 11:00:01',	240,	'2026-07-18 11:00:01',	'2026-07-18 11:00:01',	'midday',	NULL),
(328,	'-5286210766',	NULL,	'2026-07-18 18:00:02',	240,	'2026-07-18 18:00:02',	'2026-07-18 18:00:02',	'night',	NULL),
(329,	'-5286210766',	NULL,	'2026-07-19 05:45:01',	20,	'2026-07-19 05:45:01',	'2026-07-19 05:45:01',	'morning',	NULL),
(330,	'-5286210766',	NULL,	'2026-07-19 11:00:01',	240,	'2026-07-19 11:00:01',	'2026-07-19 11:00:01',	'midday',	NULL),
(331,	'-5286210766',	NULL,	'2026-07-19 18:00:01',	240,	'2026-07-19 18:00:01',	'2026-07-19 18:00:01',	'night',	NULL),
(332,	'-5286210766',	NULL,	'2026-07-20 05:45:01',	20,	'2026-07-20 05:45:01',	'2026-07-20 05:45:01',	'morning',	NULL),
(333,	'-5286210766',	NULL,	'2026-07-20 11:00:01',	240,	'2026-07-20 11:00:01',	'2026-07-20 11:00:01',	'midday',	NULL),
(334,	'-5286210766',	NULL,	'2026-07-20 18:00:01',	240,	'2026-07-20 18:00:01',	'2026-07-20 18:00:01',	'night',	NULL),
(335,	'-5286210766',	NULL,	'2026-07-21 05:45:01',	20,	'2026-07-21 05:45:01',	'2026-07-21 05:45:01',	'morning',	NULL),
(336,	'-5286210766',	NULL,	'2026-07-21 11:00:01',	240,	'2026-07-21 11:00:01',	'2026-07-21 11:00:01',	'midday',	NULL),
(337,	'-5286210766',	NULL,	'2026-07-21 18:00:02',	240,	'2026-07-21 18:00:02',	'2026-07-21 18:00:02',	'night',	NULL),
(338,	'-5286210766',	NULL,	'2026-07-22 05:45:01',	20,	'2026-07-22 05:45:01',	'2026-07-22 05:45:01',	'morning',	NULL),
(339,	'-5286210766',	NULL,	'2026-07-22 11:00:01',	240,	'2026-07-22 11:00:01',	'2026-07-22 11:00:01',	'midday',	NULL),
(340,	'-5286210766',	NULL,	'2026-07-22 18:00:01',	240,	'2026-07-22 18:00:01',	'2026-07-22 18:00:01',	'night',	NULL),
(341,	'-5286210766',	NULL,	'2026-07-23 05:45:01',	20,	'2026-07-23 05:45:01',	'2026-07-23 05:45:01',	'morning',	NULL),
(342,	'-5286210766',	NULL,	'2026-07-23 11:00:02',	240,	'2026-07-23 11:00:02',	'2026-07-23 11:00:02',	'midday',	NULL),
(343,	'-5286210766',	NULL,	'2026-07-23 18:00:02',	240,	'2026-07-23 18:00:02',	'2026-07-23 18:00:02',	'night',	NULL),
(344,	'-5286210766',	NULL,	'2026-07-24 05:45:01',	20,	'2026-07-24 05:45:01',	'2026-07-24 05:45:01',	'morning',	NULL),
(345,	'-5286210766',	NULL,	'2026-07-24 11:00:02',	240,	'2026-07-24 11:00:02',	'2026-07-24 11:00:02',	'midday',	NULL),
(346,	'-5286210766',	NULL,	'2026-07-24 18:00:01',	240,	'2026-07-24 18:00:01',	'2026-07-24 18:00:01',	'night',	NULL),
(347,	'-5286210766',	NULL,	'2026-07-25 05:45:01',	20,	'2026-07-25 05:45:01',	'2026-07-25 05:45:01',	'morning',	NULL),
(348,	'-5286210766',	NULL,	'2026-07-25 11:00:01',	240,	'2026-07-25 11:00:01',	'2026-07-25 11:00:01',	'midday',	NULL),
(349,	'-5286210766',	NULL,	'2026-07-25 18:00:01',	240,	'2026-07-25 18:00:01',	'2026-07-25 18:00:01',	'night',	NULL),
(350,	'-5286210766',	NULL,	'2026-07-26 05:45:01',	20,	'2026-07-26 05:45:01',	'2026-07-26 05:45:01',	'morning',	NULL),
(351,	'-5286210766',	NULL,	'2026-07-26 11:00:01',	240,	'2026-07-26 11:00:01',	'2026-07-26 11:00:01',	'midday',	NULL),
(352,	'-5286210766',	NULL,	'2026-07-26 18:00:02',	240,	'2026-07-26 18:00:02',	'2026-07-26 18:00:02',	'night',	NULL),
(353,	'-5286210766',	NULL,	'2026-07-27 05:45:01',	20,	'2026-07-27 05:45:01',	'2026-07-27 05:45:01',	'morning',	NULL);

DROP TABLE IF EXISTS "users";
DROP SEQUENCE IF EXISTS users_id_seq;
CREATE SEQUENCE users_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."users" (
    "id" bigint DEFAULT nextval('users_id_seq') NOT NULL,
    "name" character varying(255) NOT NULL,
    "email" character varying(255) NOT NULL,
    "email_verified_at" timestamp(0),
    "password" character varying(255) NOT NULL,
    "remember_token" character varying(100),
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    "google_token" character varying(255),
    "google_refresh_token" character varying(255),
    "google_token_expires_at" timestamp(0),
    CONSTRAINT "users_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE UNIQUE INDEX users_email_unique ON public.users USING btree (email);

INSERT INTO "users" ("id", "name", "email", "email_verified_at", "password", "remember_token", "created_at", "updated_at", "google_token", "google_refresh_token", "google_token_expires_at") VALUES
(1,	'Joan',	'joanpd0@gmail.com',	NULL,	'$2y$12$fJLoZmwT0jBgnsDZtQbbhupQvH9Wj1UvGMU64xR8y/KrVAYCKnpyi',	NULL,	'2026-04-08 21:58:58',	'2026-04-28 21:19:23',	NULL,	NULL,	NULL);

ALTER TABLE ONLY "public"."calendar_chat_messages" ADD CONSTRAINT "calendar_chat_messages_calendar_chat_id_foreign" FOREIGN KEY (calendar_chat_id) REFERENCES calendar_chats(id) ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."calendar_chats" ADD CONSTRAINT "calendar_chats_user_id_foreign" FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."calendar_event_indexes" ADD CONSTRAINT "calendar_event_indexes_user_id_foreign" FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."calendar_message_change_logs" ADD CONSTRAINT "calendar_message_change_logs_calendar_chat_message_id_foreign" FOREIGN KEY (calendar_chat_message_id) REFERENCES calendar_chat_messages(id) ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."instagram_keyword_rule_embeddings" ADD CONSTRAINT "instagram_keyword_rule_embeddings_instagram_keyword_rule_id_for" FOREIGN KEY (instagram_keyword_rule_id) REFERENCES instagram_keyword_rules(id) ON DELETE CASCADE NOT DEFERRABLE;

-- 2026-07-27 10:05:19 UTC
